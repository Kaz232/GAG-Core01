export type ChatHistoryMessage = {
  role: "user" | "assistant";
  content: string;
};

export type KiaLanguage = "pt-PT" | "en-US" | "fr-FR";
export type KiaTaskPriority = "Baixa" | "Média" | "Alta" | "Urgente";

export type AgentFactoryIntent = {
  type: "open_agent_factory";
};

export type KiaTaskDraft = {
  type: "prepare_task";
  title: string;
  description: string;
  periodLabel: string | null;
  timeLabel: string | null;
  priority: KiaTaskPriority;
  requiresConfirmation: true;
};

// A Agent Factory só pode preparar um rascunho após os quatro critérios de
// validação terem sido confirmados explicitamente pelo proprietário.
export const KIA_AGENT_FACTORY_ENABLED = true;

/**
 * Conhecimento institucional nativo. Não é um registo factual do utilizador;
 * define a identidade, os limites e as capacidades gerais da KIA.
 */
export const KIA_CORE_KNOWLEDGE = `
IDENTIDADE
És a KIA — Knowledge Intelligent Agent, a inteligência-mestre e assistente executivo interno do GAG Core.
Na interface podes ser identificada como “KIA”; em resposta falada, a pronúncia natural é “Kia”.

MÓDULOS E CAPACIDADES
- Compreendes linguagem natural, organizas operações, estruturas tarefas, analisas processos, crias planos e explicas como utilizar os módulos do GAG Core.
- O GAG Core inclui Knowledge Base, Backlog e Tarefas, Calendário, Leads e Templates e Agent Factory. Explica o papel de cada módulo sem inventar dados nele existentes.
- A conversa atual é contexto temporário. A memória operacional, o Core Knowledge nativo e a Knowledge Base externa são camadas distintas e não devem ser confundidas.
- A voz funciona por iniciativa explícita do proprietário: ouvir, processar e responder. Não assumes escuta contínua.
- Age como camada de orquestração: interpreta se o pedido é conversa, consulta, análise, preparação, atualização ou ação, e orienta o proprietário para o módulo apropriado.

LIMITES
- Não inventes documentos, números, tarefas, clientes, resultados, histórico ou factos específicos da GAG.
- Quando uma pergunta pedir um facto específico da GAG que não esteja na Knowledge Base externa, explica de forma transparente que esse facto ainda não foi carregado.
- O GAG Core é uma plataforma interna da GAG. Não assumes nem crias clientes, dados demonstrativos ou integrações externas.
- Podes consultar capacidades internas e preparar ações internas allow-listed. Antes de alterar dados, apresenta claramente o que será alterado e pede confirmação explícita; depois da confirmação, a plataforma pode executar apenas o handler interno autorizado e auditado.
- A Agent Factory pode preparar vários rascunhos independentes depois de os quatro critérios de validação terem sido confirmados explicitamente pelo proprietário. Um comando explícito do proprietário pode criar diretamente como RASCUNHO uma especificação autorizada e rastreável; outros agentes exigem recolha e revisão da especificação. Cada agente exige testes e aprovação próprios para ativação. Nunca atives, testes ou simules agentes sem as confirmações visíveis na interface.
`;

// Alias interno transitório; preserva consumidores já existentes sem expor a antiga identidade na interface.
export const GAG_MASTER_CORE_KNOWLEDGE = KIA_CORE_KNOWLEDGE;

export function buildKiaSystemPrompt(externalKnowledge: string, operationalContext = "", language: KiaLanguage = "pt-PT"): string {
  const externalSection = externalKnowledge.trim().length > 0
    ? `CONHECIMENTO EXTERNO CARREGADO (fonte factual adicional)\n${externalKnowledge}`
    : "CONHECIMENTO EXTERNO CARREGADO\nNenhum documento externo foi carregado nesta conversa.";
  const operationalSection = operationalContext.trim().length > 0
    ? `CONTEXTO OPERACIONAL TEMPORÁRIO (dados reais de consulta)\n${operationalContext}`
    : "CONTEXTO OPERACIONAL TEMPORÁRIO\nNenhum dado operacional foi solicitado nesta conversa.";

  return `
${KIA_CORE_KNOWLEDGE}

REGRAS DE RESPOSTA
1. A tua inteligência geral permite responder a perguntas conceituais e explicar as tuas próprias capacidades, mesmo sem documentos externos.
2. A Knowledge Base externa complementa a resposta com factos específicos. Usa apenas os factos realmente presentes nela e não atribuas a ela informações que não contém.
3. Não digas que nada podes responder apenas porque a Knowledge Base externa está vazia. Reserva essa limitação para factos específicos da GAG que não foram carregados.
4. Mantém o histórico da conversa em consideração para interpretar referências como "ele", "isso", "aquilo", "amanhã" ou "depois". Quando existir ambiguidade real, pede clarificação.
5. Quando o pedido envolver uma tarefa, prepara a alteração e aguarda a confirmação explícita apresentada pelo GAG Core antes de a gravar.
6. Se o utilizador pedir criação de agente, exige proprietário autenticado e ciclo controlado. Quando o pedido for uma ordem explícita de criação em RASCUNHO para uma especificação autorizada e rastreável, materializa somente esse rascunho seguro; para agentes sem blueprint autorizado, recolhe os requisitos e exige a aprovação da Agent Factory. Nunca atives um agente por iniciativa própria.
7. Nunca executes ações externas, não atives automações externas e não confirmes tarefas como concluídas sem evidência. Após confirmação explícita, podes concluir apenas uma ação interna allow-listed através do handler persistente da plataforma, com auditoria; se o handler não existir, responde NOT_IMPLEMENTED.
8. Responde no idioma ativo da conversa (${language}). Mantém esse idioma até o proprietário pedir uma mudança. Se a intenção estiver realmente ambígua, faz uma pergunta curta antes de presumir uma ação.
9. Trata correções naturais como "não, às 16", "deixa média" ou "faz isso depois" como ajustes ao rascunho pendente, não como um novo pedido técnico.
10. No início de uma conversa nova, apresenta-te de forma breve e natural. Em pedidos simples, responde de forma direta; em pedidos complexos, organiza a resposta em passos claros.
11. Quando a conversa incluir texto e voz, o conteúdo deve ter o mesmo significado. Não atribuas capacidades, ações ou dados que a interface não pode confirmar.
12. O Execution Router classifica o pedido antes desta resposta. Respeita a rota apresentada: comandos operacionais seguem para o módulo próprio; pedidos de implementação do sistema não são executados pelo chat; ações externas permanecem bloqueadas.

${externalSection}

${operationalSection}`;
}

export const buildGagMasterSystemPrompt = buildKiaSystemPrompt;

export function detectKiaLanguage(message: string, fallback: KiaLanguage = "pt-PT"): KiaLanguage {
  const normalized = message.toLocaleLowerCase();
  const frenchSignals = /\b(bonjour|merci|demain|tâche|tache|créer|creer|aide-moi|aidez-moi|priorité|priorite|semaine)\b/;
  const englishSignals = /\b(hello|thanks|tomorrow|task|create|make|help me|priority|week|schedule)\b/;

  if (frenchSignals.test(normalized)) return "fr-FR";
  if (englishSignals.test(normalized)) return "en-US";
  return fallback;
}

function detectKiaTaskPriority(message: string, fallback: KiaTaskPriority = "Média"): KiaTaskPriority {
  const normalized = message.toLocaleLowerCase();
  if (/\b(urgente|urgent)\b/.test(normalized)) return "Urgente";
  if (/\b(alta|alto|high|haute)\b/.test(normalized)) return "Alta";
  if (/\b(baixa|baixo|low|basse)\b/.test(normalized)) return "Baixa";
  if (/\b(média|media|medium|moyenne)\b/.test(normalized)) return "Média";
  return fallback;
}

function detectKiaPeriod(message: string): string | null {
  const match = message.toLocaleLowerCase().match(/(?:^|[\s,.;!?])((?:amanhã|hoje|próxima semana|esta semana|depois|tomorrow|today|next week|later|demain|aujourd'hui|semaine prochaine|plus tard))(?=$|[\s,.;!?])/i);
  return match?.[1] ?? null;
}

function detectKiaTime(message: string): string | null {
  const match = message.match(/(?:^|[\s,.;!?])(?:às?|at|à)\s*(\d{1,2})(?::(\d{2}))?(?=$|[\s,.;!?])/i) ?? message.match(/(?:^|[\s,.;!?])(\d{1,2})h(?:(\d{2}))?(?=$|[\s,.;!?])/i);
  if (!match) return null;
  return `${match[1].padStart(2, "0")}:${match[2] ?? "00"}`;
}

function buildKiaTaskDescription(periodLabel: string | null, timeLabel: string | null, priority: KiaTaskPriority): string {
  const schedule = [periodLabel, timeLabel].filter(Boolean).join(" · ");
  return `Pedido preparado pela KIA. ${schedule ? `Referência temporal: ${schedule}. ` : "Prazo a confirmar. "}Prioridade: ${priority}.`;
}

export function detectAgentFactoryIntent(message: string): AgentFactoryIntent | null {
  const normalized = message.toLocaleLowerCase("pt-PT");
  const mentionsAgent = /\bagente\b/.test(normalized);
  const requestsCreation = /\b(cria|criar|gere|gerar|monta|montar|configura|configurar)\b/.test(normalized);

  if (!mentionsAgent || !requestsCreation) return null;

  return {
    type: "open_agent_factory",
  };
}

export function detectKiaTaskIntent(message: string): KiaTaskDraft | null {
  const normalized = message.trim();
  const lower = normalized.toLocaleLowerCase("pt-PT");
  const requestsAction = /\b(cria|criar|adiciona|adicionar|regista|registar|prepara|preparar|faz|fazer|marca|marcar|create|make|add|schedule|crée|creer|ajoute|planifie)\b/.test(lower);
  const requestsTask = /\b(tarefas?|task|tasks|tâche|tache|isto|isso|this|that|cela|ça)\b/.test(lower);

  if (!requestsAction || !requestsTask) return null;

  const periodLabel = detectKiaPeriod(lower);
  const timeLabel = detectKiaTime(normalized);
  const priority = detectKiaTaskPriority(lower);
  const withoutPrefix = normalized
    .replace(/^(kia\s*,?\s*)?(cria|criar|adiciona|adicionar|regista|registar|prepara|preparar|faz|fazer|marca|marcar|create|make|add|schedule|crée|creer|ajoute|planifie)\s+(uma\s+)?(tarefa|task|tâche|tache)?\s*(para\s*)?(eu\s*)?/i, "")
    .replace(/(amanhã|hoje|próxima semana|esta semana|depois|tomorrow|today|next week|later|demain|aujourd'hui|semaine prochaine|plus tard)(?=\s|$|[.!?,])/gi, "")
    .replace(/[.?!]+$/g, "")
    .trim();
  const title = withoutPrefix ? `${withoutPrefix.charAt(0).toUpperCase()}${withoutPrefix.slice(1)}` : "Nova tarefa operacional";

  return {
    type: "prepare_task",
    title,
    description: buildKiaTaskDescription(periodLabel, timeLabel, priority),
    periodLabel,
    timeLabel,
    priority,
    requiresConfirmation: true,
  };
}

export function refineKiaTaskDraft(draft: KiaTaskDraft, correction: string): KiaTaskDraft {
  const periodLabel = detectKiaPeriod(correction) ?? draft.periodLabel;
  const timeLabel = detectKiaTime(correction) ?? draft.timeLabel;
  const priority = detectKiaTaskPriority(correction, draft.priority);

  return {
    ...draft,
    periodLabel,
    timeLabel,
    priority,
    description: buildKiaTaskDescription(periodLabel, timeLabel, priority),
  };
}

export function isKiaTaskCancellation(message: string): boolean {
  return /\b(cancela|cancelar|não criar|nao criar|desfaz|desfazer|cancel|annule|annuler)\b/i.test(message);
}

export function isKiaBacklogQuery(message: string): boolean {
  const normalized = message.toLocaleLowerCase("pt-PT");
  const mentionsTasks = /\b(tarefa|tarefas|backlog|pendente|pendentes)\b/.test(normalized);
  const asksOrganisation = /\b(organiza|organizar|mostra|mostrar|tenho|listar|lista|qual|quais)\b/.test(normalized);
  return mentionsTasks && asksOrganisation;
}
