CREATE TABLE `internal_execution_actions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`planId` int NOT NULL,
	`actionType` enum('TASK_CREATE','TASK_UPDATE_PRIORITY') NOT NULL,
	`actionJson` text NOT NULL,
	`status` enum('PENDING','EXECUTED','FAILED') NOT NULL DEFAULT 'PENDING',
	`resultJson` text,
	`startedAt` timestamp,
	`completedAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `internal_execution_actions_id` PRIMARY KEY(`id`),
	CONSTRAINT `internal_execution_actions_planId_unique` UNIQUE(`planId`)
);
--> statement-breakpoint
CREATE TABLE `internal_execution_events` (
	`id` int AUTO_INCREMENT NOT NULL,
	`ownerId` int NOT NULL,
	`planId` int NOT NULL,
	`actionId` int,
	`eventType` varchar(64) NOT NULL,
	`payloadJson` text NOT NULL,
	`previousHash` varchar(64) NOT NULL,
	`eventHash` varchar(64) NOT NULL,
	`hmac` varchar(64) NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `internal_execution_events_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `internal_execution_plans` (
	`id` int AUTO_INCREMENT NOT NULL,
	`ownerId` int NOT NULL,
	`brandId` int NOT NULL,
	`source` enum('KIA','KAZ') NOT NULL,
	`actionType` enum('TASK_CREATE','TASK_UPDATE_PRIORITY') NOT NULL,
	`planJson` text NOT NULL,
	`planHash` varchar(64) NOT NULL,
	`status` enum('PROPOSED','CONFIRMED','EXECUTED','CANCELLED','EXPIRED','FAILED') NOT NULL DEFAULT 'PROPOSED',
	`confirmationNonce` varchar(96) NOT NULL,
	`expiresAt` timestamp NOT NULL,
	`confirmedAt` timestamp,
	`executedAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `internal_execution_plans_id` PRIMARY KEY(`id`),
	CONSTRAINT `internal_execution_plans_confirmationNonce_unique` UNIQUE(`confirmationNonce`)
);
