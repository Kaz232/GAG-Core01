CREATE TABLE `document_analysis_exports` (
	`id` int AUTO_INCREMENT NOT NULL,
	`ownerId` int NOT NULL,
	`analysisId` int NOT NULL,
	`format` enum('MARKDOWN') NOT NULL DEFAULT 'MARKDOWN',
	`reportContent` text NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `document_analysis_exports_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `document_analyses` ADD `reviewDecision` enum('PENDING','APPROVED','CHANGES_REQUESTED','REJECTED') DEFAULT 'PENDING' NOT NULL;--> statement-breakpoint
ALTER TABLE `document_analyses` ADD `reviewedBy` int;--> statement-breakpoint
ALTER TABLE `document_analyses` ADD `reviewedAt` timestamp;--> statement-breakpoint
ALTER TABLE `document_analyses` ADD `reviewNote` text;