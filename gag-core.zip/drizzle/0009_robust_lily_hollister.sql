CREATE TABLE `document_analyses` (
	`id` int AUTO_INCREMENT NOT NULL,
	`ownerId` int NOT NULL,
	`documentId` int NOT NULL,
	`operation` enum('ANALYZE','SUMMARIZE','EXTRACT_VALUES','COMPARE','ORGANIZE','REPORT') NOT NULL DEFAULT 'ANALYZE',
	`requestedIntent` text NOT NULL,
	`analysisStatus` enum('COMPLETED','REVIEW_REQUIRED','FAILED') NOT NULL DEFAULT 'REVIEW_REQUIRED',
	`analysisJson` text NOT NULL,
	`summary` text NOT NULL,
	`professionalReviewRequired` int NOT NULL DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `document_analyses_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `document_records` (
	`id` int AUTO_INCREMENT NOT NULL,
	`ownerId` int NOT NULL,
	`brandId` int NOT NULL,
	`filename` varchar(255) NOT NULL,
	`documentType` enum('PDF','DOCX','XLSX','CSV','IMAGE','TEXT','OTHER') NOT NULL,
	`mimeType` varchar(128) NOT NULL,
	`storageKey` varchar(512) NOT NULL,
	`storageUrl` text NOT NULL,
	`contentHash` varchar(64) NOT NULL,
	`sourceOrigin` enum('OWNER_UPLOAD','GAG_INTERNAL','CLIENT_ISOLATED','EXTERNAL_REFERENCE') NOT NULL DEFAULT 'OWNER_UPLOAD',
	`extractionStatus` enum('PROCESSING','COMPLETED','REVIEW_REQUIRED','FAILED','DUPLICATE_REFERENCE') NOT NULL DEFAULT 'PROCESSING',
	`extractedContent` text,
	`reviewReason` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `document_records_id` PRIMARY KEY(`id`)
);
