CREATE TABLE `kia_orchestration_audit_events` (
	`id` int AUTO_INCREMENT NOT NULL,
	`ownerId` int NOT NULL,
	`intent` varchar(64) NOT NULL,
	`agentId` int,
	`skillId` varchar(128),
	`toolId` varchar(128),
	`status` enum('SUCCESS','FAILED','BLOCKED','NOT_IMPLEMENTED','REVIEW_REQUIRED') NOT NULL,
	`resultCode` varchar(128) NOT NULL,
	`artifactId` int,
	`exportStatus` enum('NOT_REQUESTED','REVIEW_REQUIRED','AVAILABLE','NOT_IMPLEMENTED') NOT NULL DEFAULT 'NOT_REQUESTED',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `kia_orchestration_audit_events_id` PRIMARY KEY(`id`)
);
