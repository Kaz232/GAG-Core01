CREATE TABLE `scanner_economic_audit_events` (
	`id` int AUTO_INCREMENT NOT NULL,
	`ownerId` int NOT NULL,
	`agentId` int NOT NULL,
	`documentId` int,
	`analysisId` int,
	`reportId` int,
	`operation` varchar(64) NOT NULL,
	`result` enum('CREATED','REVIEW_REQUIRED','FAILED','BLOCKED') NOT NULL,
	`eventCode` varchar(96) NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `scanner_economic_audit_events_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `scanner_economic_reports` (
	`id` int AUTO_INCREMENT NOT NULL,
	`ownerId` int NOT NULL,
	`agentId` int NOT NULL,
	`documentId` int NOT NULL,
	`analysisId` int NOT NULL,
	`question` text NOT NULL,
	`period` varchar(255) NOT NULL,
	`geography` varchar(255) NOT NULL,
	`intendedDecision` text NOT NULL,
	`status` enum('DRAFT','REVIEW_REQUIRED') NOT NULL DEFAULT 'REVIEW_REQUIRED',
	`reportJson` text NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `scanner_economic_reports_id` PRIMARY KEY(`id`)
);
