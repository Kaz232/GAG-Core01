CREATE TABLE `agent_factory_audit_events` (
	`id` int AUTO_INCREMENT NOT NULL,
	`ownerId` int NOT NULL,
	`operation` varchar(64) NOT NULL,
	`intent` varchar(64) NOT NULL,
	`capabilityId` varchar(128) NOT NULL,
	`targetSlug` varchar(160),
	`result` enum('CREATED','ALREADY_EXISTS','BLOCKED','REJECTED','FAILED') NOT NULL,
	`eventCode` varchar(96) NOT NULL,
	`agentId` int,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `agent_factory_audit_events_id` PRIMARY KEY(`id`)
);
