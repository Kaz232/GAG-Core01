ALTER TABLE `specialized_agents` ADD COLUMN IF NOT EXISTS `autonomyLevel` enum('Supervisionado','Assistido') DEFAULT 'Assistido' NOT NULL;--> statement-breakpoint
ALTER TABLE `specialized_agents` ADD COLUMN IF NOT EXISTS `permissionSet` varchar(512) NOT NULL DEFAULT '["READ"]';--> statement-breakpoint
ALTER TABLE `specialized_agents` ADD COLUMN IF NOT EXISTS `externalActionPolicy` enum('Bloqueadas') DEFAULT 'Bloqueadas' NOT NULL;
