ALTER TABLE `specialized_agents` MODIFY COLUMN `status` enum('Rascunho','Em Teste','Ativo','Rejeitado','Inativo') NOT NULL DEFAULT 'Rascunho';--> statement-breakpoint
ALTER TABLE `specialized_agents` ADD `specification` text NOT NULL;--> statement-breakpoint
ALTER TABLE `specialized_agents` ADD `testNotes` text;--> statement-breakpoint
ALTER TABLE `specialized_agents` ADD `draftCreatedAt` timestamp DEFAULT (now()) NOT NULL;--> statement-breakpoint
ALTER TABLE `specialized_agents` ADD `testStartedAt` timestamp;--> statement-breakpoint
ALTER TABLE `specialized_agents` ADD `activationApprovedAt` timestamp;--> statement-breakpoint
ALTER TABLE `specialized_agents` ADD `activationApprovedBy` int;