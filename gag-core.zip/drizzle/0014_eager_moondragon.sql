ALTER TABLE `specialized_agents` ADD `slug` varchar(160);--> statement-breakpoint
UPDATE `specialized_agents`
SET `slug` = LOWER(TRIM(BOTH '-' FROM REGEXP_REPLACE(REGEXP_REPLACE(`name`, '[^[:alnum:]]+', '-'), '(^-+|-+$)', '')))
WHERE `slug` IS NULL;--> statement-breakpoint
ALTER TABLE `specialized_agents` MODIFY COLUMN `slug` varchar(160) NOT NULL;--> statement-breakpoint
ALTER TABLE `specialized_agents` ADD CONSTRAINT `specialized_agents_slug_unique` UNIQUE(`slug`);
