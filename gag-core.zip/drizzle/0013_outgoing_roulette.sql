CREATE TABLE `corpus_review_decisions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`ownerId` int NOT NULL,
	`artifactId` varchar(128) NOT NULL,
	`decision` enum('APPROVED','REJECTED') NOT NULL,
	`decisionNote` text NOT NULL,
	`artifactSnapshot` text NOT NULL,
	`decidedAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `corpus_review_decisions_id` PRIMARY KEY(`id`)
);
