import { int, mysqlEnum, mysqlTable, text, timestamp, varchar } from "drizzle-orm/mysql-core";

export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

export const brands = mysqlTable("brands", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 128 }).notNull().unique(), // GAG Visual (Interno) ou Clientes (PCA, Angel Brindes, etc.)
  entityType: mysqlEnum("entityType", ["internal_operation", "client"]).default("client").notNull(),
  description: text("description"),
  logoUrl: text("logoUrl"),
  colorTheme: varchar("colorTheme", { length: 64 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const knowledgeItems = mysqlTable("knowledge_items", {
  id: int("id").autoincrement().primaryKey(),
  brandId: int("brandId").notNull(),
  title: varchar("title", { length: 255 }).notNull(),
  category: varchar("category", { length: 64 }).notNull(), // Estratégia, Produto, FAQ, Processo, etc.
  content: text("content").notNull(),
  status: mysqlEnum("status", ["rascunho", "aprovado", "arquivado"]).default("aprovado").notNull(),
  sourceFilename: varchar("sourceFilename", { length: 255 }),
  sourceUrl: text("sourceUrl"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const documentRecords = mysqlTable("document_records", {
  id: int("id").autoincrement().primaryKey(),
  ownerId: int("ownerId").notNull(),
  brandId: int("brandId").notNull(),
  filename: varchar("filename", { length: 255 }).notNull(),
  documentType: mysqlEnum("documentType", ["PDF", "DOCX", "XLSX", "CSV", "IMAGE", "TEXT", "OTHER"]).notNull(),
  mimeType: varchar("mimeType", { length: 128 }).notNull(),
  storageKey: varchar("storageKey", { length: 512 }).notNull(),
  storageUrl: text("storageUrl").notNull(),
  contentHash: varchar("contentHash", { length: 64 }).notNull(),
  sourceOrigin: mysqlEnum("sourceOrigin", ["OWNER_UPLOAD", "GAG_INTERNAL", "CLIENT_ISOLATED", "EXTERNAL_REFERENCE"]).default("OWNER_UPLOAD").notNull(),
  extractionStatus: mysqlEnum("extractionStatus", ["PROCESSING", "COMPLETED", "REVIEW_REQUIRED", "FAILED", "DUPLICATE_REFERENCE"]).default("PROCESSING").notNull(),
  extractedContent: text("extractedContent"),
  reviewReason: text("reviewReason"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const documentAnalyses = mysqlTable("document_analyses", {
  id: int("id").autoincrement().primaryKey(),
  ownerId: int("ownerId").notNull(),
  documentId: int("documentId").notNull(),
  operation: mysqlEnum("operation", ["ANALYZE", "SUMMARIZE", "EXTRACT_VALUES", "COMPARE", "ORGANIZE", "REPORT"]).default("ANALYZE").notNull(),
  requestedIntent: text("requestedIntent").notNull(),
  analysisStatus: mysqlEnum("analysisStatus", ["COMPLETED", "REVIEW_REQUIRED", "FAILED"]).default("REVIEW_REQUIRED").notNull(),
  analysisJson: text("analysisJson").notNull(),
  summary: text("summary").notNull(),
  professionalReviewRequired: int("professionalReviewRequired").default(0).notNull(),
  reviewDecision: mysqlEnum("reviewDecision", ["PENDING", "APPROVED", "CHANGES_REQUESTED", "REJECTED"]).default("PENDING").notNull(),
  reviewedBy: int("reviewedBy"),
  reviewedAt: timestamp("reviewedAt"),
  reviewNote: text("reviewNote"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const documentAnalysisExports = mysqlTable("document_analysis_exports", {
  id: int("id").autoincrement().primaryKey(),
  ownerId: int("ownerId").notNull(),
  analysisId: int("analysisId").notNull(),
  format: mysqlEnum("format", ["PDF"]).default("PDF").notNull(),
  reportContent: text("reportContent").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

// Rascunhos produzidos pelo Scanner de Economia Real a partir de documentos
// internos autorizados. A fonte e a análise subjacente permanecem separadas.
export const scannerEconomicReports = mysqlTable("scanner_economic_reports", {
  id: int("id").autoincrement().primaryKey(),
  ownerId: int("ownerId").notNull(),
  agentId: int("agentId").notNull(),
  documentId: int("documentId").notNull(),
  analysisId: int("analysisId").notNull(),
  question: text("question").notNull(),
  period: varchar("period", { length: 255 }).notNull(),
  geography: varchar("geography", { length: 255 }).notNull(),
  intendedDecision: text("intendedDecision").notNull(),
  status: mysqlEnum("status", ["DRAFT", "REVIEW_REQUIRED"]).default("REVIEW_REQUIRED").notNull(),
  reportJson: text("reportJson").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

// Auditoria sanitizada, append-only, de processamento do Scanner. Nunca contém
// texto do documento, mensagem do chat, URLs de armazenamento ou credenciais.
export const scannerEconomicAuditEvents = mysqlTable("scanner_economic_audit_events", {
  id: int("id").autoincrement().primaryKey(),
  ownerId: int("ownerId").notNull(),
  agentId: int("agentId").notNull(),
  documentId: int("documentId"),
  analysisId: int("analysisId"),
  reportId: int("reportId"),
  operation: varchar("operation", { length: 64 }).notNull(),
  result: mysqlEnum("result", ["CREATED", "REVIEW_REQUIRED", "FAILED", "BLOCKED"]).notNull(),
  eventCode: varchar("eventCode", { length: 96 }).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const kiaApproval = mysqlTable("kia_approval", {
  id: int("id").autoincrement().primaryKey(),
  ownerId: int("ownerId").notNull().unique(),
  textValidated: int("textValidated").default(0).notNull(),
  voiceValidated: int("voiceValidated").default(0).notNull(),
  contextValidated: int("contextValidated").default(0).notNull(),
  safetyConfirmed: int("safetyConfirmed").default(0).notNull(),
  agentFactoryUnlocked: int("agentFactoryUnlocked").default(0).notNull(),
  approvedAt: timestamp("approvedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const kiaConversationMessages = mysqlTable("kia_conversation_messages", {
  id: int("id").autoincrement().primaryKey(),
  ownerId: int("ownerId").notNull(),
  role: mysqlEnum("role", ["user", "assistant"]).notNull(),
  content: text("content").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const tasks = mysqlTable("tasks", {
  id: int("id").autoincrement().primaryKey(),
  brandId: int("brandId").notNull(),
  title: varchar("title", { length: 255 }).notNull(),
  description: text("description"),
  status: mysqlEnum("status", ["Pendente", "Em Curso", "Concluído"]).default("Pendente").notNull(),
  priority: mysqlEnum("priority", ["Baixa", "Média", "Alta", "Urgente"]).default("Média").notNull(),
  quarter: varchar("quarter", { length: 16 }).notNull(), // Q1, Q2, Q3, Q4
  dueDate: varchar("dueDate", { length: 10 }), // YYYY-MM-DD, opcional
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

// Kernel de execução interna: mantém plano, confirmação e evidência separados das tarefas.
// Não representa nem permite ação externa, publicação, envio ou transação.
export const internalExecutionPlans = mysqlTable("internal_execution_plans", {
  id: int("id").autoincrement().primaryKey(),
  ownerId: int("ownerId").notNull(),
  brandId: int("brandId").notNull(),
  source: mysqlEnum("source", ["KIA", "KAZ"]).notNull(),
  actionType: mysqlEnum("actionType", ["TASK_CREATE", "TASK_UPDATE_PRIORITY"]).notNull(),
  planJson: text("planJson").notNull(),
  planHash: varchar("planHash", { length: 64 }).notNull(),
  status: mysqlEnum("status", ["PROPOSED", "CONFIRMED", "EXECUTED", "CANCELLED", "EXPIRED", "FAILED"]).default("PROPOSED").notNull(),
  confirmationNonce: varchar("confirmationNonce", { length: 96 }).notNull().unique(),
  expiresAt: timestamp("expiresAt").notNull(),
  confirmedAt: timestamp("confirmedAt"),
  executedAt: timestamp("executedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const internalExecutionActions = mysqlTable("internal_execution_actions", {
  id: int("id").autoincrement().primaryKey(),
  planId: int("planId").notNull().unique(),
  actionType: mysqlEnum("actionType", ["TASK_CREATE", "TASK_UPDATE_PRIORITY"]).notNull(),
  actionJson: text("actionJson").notNull(),
  status: mysqlEnum("status", ["PENDING", "EXECUTED", "FAILED"]).default("PENDING").notNull(),
  resultJson: text("resultJson"),
  startedAt: timestamp("startedAt"),
  completedAt: timestamp("completedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const internalExecutionEvents = mysqlTable("internal_execution_events", {
  id: int("id").autoincrement().primaryKey(),
  ownerId: int("ownerId").notNull(),
  planId: int("planId").notNull(),
  actionId: int("actionId"),
  eventType: varchar("eventType", { length: 64 }).notNull(),
  payloadJson: text("payloadJson").notNull(),
  previousHash: varchar("previousHash", { length: 64 }).notNull(),
  eventHash: varchar("eventHash", { length: 64 }).notNull(),
  hmac: varchar("hmac", { length: 64 }).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const calendarEvents = mysqlTable("calendar_events", {
  id: int("id").autoincrement().primaryKey(),
  brandId: int("brandId").notNull(),
  title: varchar("title", { length: 255 }).notNull(),
  description: text("description"),
  eventType: varchar("eventType", { length: 64 }).notNull(), // Gestão Redes, Produção Vídeo, Lançamento
  scheduledDate: varchar("scheduledDate", { length: 64 }).notNull(), // YYYY-MM-DD
  status: mysqlEnum("status", ["Agendado", "Em Produção", "Concluído"]).default("Agendado").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const leads = mysqlTable("leads", {
  id: int("id").autoincrement().primaryKey(),
  brandId: int("brandId").notNull(),
  name: varchar("name", { length: 255 }).notNull(),
  contact: varchar("contact", { length: 128 }).notNull(),
  service: varchar("service", { length: 255 }),
  status: mysqlEnum("status", ["Novo Lead", "Em Qualificação", "Proposta Enviada", "Fechado", "Perdido"]).default("Novo Lead").notNull(),
  source: varchar("source", { length: 64 }).default("Meta Ads").notNull(),
  notes: text("notes"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const messageTemplates = mysqlTable("message_templates", {
  id: int("id").autoincrement().primaryKey(),
  brandId: int("brandId").notNull(),
  funnelStage: varchar("funnelStage", { length: 64 }).notNull(), // Boas-vindas, Follow-up, Proposta, Fecho
  title: varchar("title", { length: 255 }).notNull(),
  content: text("content").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const specializedAgents = mysqlTable("specialized_agents", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 128 }).notNull(),
  slug: varchar("slug", { length: 160 }).notNull().unique(),
  objective: text("objective").notNull(),
  instructions: text("instructions").notNull(),
  specification: text("specification").notNull(),
  testNotes: text("testNotes"),
  autonomyLevel: mysqlEnum("autonomyLevel", ["Supervisionado", "Assistido"]).default("Assistido").notNull(),
  permissionSet: varchar("permissionSet", { length: 512 }).notNull().default('["READ"]'),
  externalActionPolicy: mysqlEnum("externalActionPolicy", ["Bloqueadas"]).default("Bloqueadas").notNull(),
  brandId: int("brandId"),
  status: mysqlEnum("status", ["Rascunho", "Em Teste", "Ativo", "Rejeitado", "Inativo"]).default("Rascunho").notNull(),
  draftCreatedAt: timestamp("draftCreatedAt").defaultNow().notNull(),
  testStartedAt: timestamp("testStartedAt"),
  activationApprovedAt: timestamp("activationApprovedAt"),
  activationApprovedBy: int("activationApprovedBy"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

// Auditoria interna sanitizada da Agent Factory. Não armazena mensagem de chat,
// instruções, cookies, credenciais ou outro conteúdo operacional sensível.
export const agentFactoryAuditEvents = mysqlTable("agent_factory_audit_events", {
  id: int("id").autoincrement().primaryKey(),
  ownerId: int("ownerId").notNull(),
  operation: varchar("operation", { length: 64 }).notNull(),
  intent: varchar("intent", { length: 64 }).notNull(),
  capabilityId: varchar("capabilityId", { length: 128 }).notNull(),
  targetSlug: varchar("targetSlug", { length: 160 }),
  result: mysqlEnum("result", ["CREATED", "ALREADY_EXISTS", "BLOCKED", "REJECTED", "FAILED"]).notNull(),
  eventCode: varchar("eventCode", { length: 96 }).notNull(),
  agentId: int("agentId"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

// Auditoria append-only e sanitizada da orquestração KIA. Não armazena texto
// de conversas, conteúdo documental, URLs de storage, stack traces ou segredos.
export const kiaOrchestrationAuditEvents = mysqlTable("kia_orchestration_audit_events", {
  id: int("id").autoincrement().primaryKey(),
  ownerId: int("ownerId").notNull(),
  intent: varchar("intent", { length: 64 }).notNull(),
  agentId: int("agentId"),
  skillId: varchar("skillId", { length: 128 }),
  toolId: varchar("toolId", { length: 128 }),
  status: mysqlEnum("status", ["SUCCESS", "FAILED", "BLOCKED", "NOT_IMPLEMENTED", "REVIEW_REQUIRED"]).notNull(),
  resultCode: varchar("resultCode", { length: 128 }).notNull(),
  artifactId: int("artifactId"),
  exportStatus: mysqlEnum("exportStatus", ["NOT_REQUESTED", "REVIEW_REQUIRED", "AVAILABLE", "NOT_IMPLEMENTED"]).default("NOT_REQUESTED").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

// Decisões explícitas do proprietário sobre workflows e templates internos.
// Mantém histórico append-only: a decisão efetiva é o registo mais recente por artefacto.
export const corpusReviewDecisions = mysqlTable("corpus_review_decisions", {
  id: int("id").autoincrement().primaryKey(),
  ownerId: int("ownerId").notNull(),
  artifactId: varchar("artifactId", { length: 128 }).notNull(),
  decision: mysqlEnum("decision", ["APPROVED", "REJECTED"]).notNull(),
  decisionNote: text("decisionNote").notNull(),
  artifactSnapshot: text("artifactSnapshot").notNull(),
  decidedAt: timestamp("decidedAt").defaultNow().notNull(),
});
