CREATE TABLE `kia_approval` (
	`id` int AUTO_INCREMENT NOT NULL,
	`ownerId` int NOT NULL,
	`textValidated` int NOT NULL DEFAULT 0,
	`voiceValidated` int NOT NULL DEFAULT 0,
	`contextValidated` int NOT NULL DEFAULT 0,
	`safetyConfirmed` int NOT NULL DEFAULT 0,
	`agentFactoryUnlocked` int NOT NULL DEFAULT 0,
	`approvedAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `kia_approval_id` PRIMARY KEY(`id`),
	CONSTRAINT `kia_approval_ownerId_unique` UNIQUE(`ownerId`)
);
--> statement-breakpoint
ALTER TABLE `knowledge_items` ADD `sourceFilename` varchar(255);--> statement-breakpoint
ALTER TABLE `knowledge_items` ADD `sourceUrl` text;