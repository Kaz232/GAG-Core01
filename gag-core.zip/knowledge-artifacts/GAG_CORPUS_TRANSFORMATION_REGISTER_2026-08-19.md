# Registo de transformação controlada do acervo GAG

**Data:** 2026-08-19  
**Base de decisão:** `GAG_PROMPT_TRIAGE_REPORT_2026-08-19.md`  
**Regra permanente:** fontes originais permanecem em `/home/ubuntu/upload`; hashes e duplicações mantêm-se em `PROMPT_LIBRARY_INVENTORY_2026-08-19.tsv`.

> Este registo transforma a classificação aprovada em artefactos controlados. Não cria agentes, integrações, permissões, ações externas ou conhecimento de clientes.

## Knowledge estruturado — Operação e identidade institucional da GAG

| Campo | Registo |
|---|---|
| Destino | Knowledge Base interna existente: `Perfil institucional confirmado da GAG Visual` |
| Estado | `APPROVED_KNOWLEDGE` apenas para dados institucionais já confirmados pelo proprietário; conflitos de identidade permanecem em `REVIEW_REQUIRED` |
| Escopo | GAG — Operação Interna; sem dados de clientes, contas externas ou automações |
| Fontes | `Instrucoes_Projeto_GAG_Visual-1.md`; `Manual_de_Identidade_Visual_-_GAG_Visual.md`; `Manual_de_Identidade_Visual_—_GAG_Visual_(2026).md` |
| Proveniência | Ficheiros originais preservados e registados no inventário; nenhuma fonte foi apagada ou sobrescrita |

### Estrutura operacional inserida

- Identidade legal e comercial apenas conforme confirmação prévia do proprietário.
- Limite de operação: o GAG Core coordena somente a operação interna GAG.
- Regra de comunicação: não apresentar projeções, resultados ou capacidades como factos sem fonte verificável.
- Regra de segurança: sinalizar riscos, credenciais expostas, pedidos de ação externa e informação sensível antes de propor execução.
- Regra de fronteira: não introduzir dados, tarefas, agentes ou conhecimento de clientes no núcleo interno.

## Skill criada — `gag-prompt-engineering`

| Campo | Registo |
|---|---|
| Destino | `/home/ubuntu/skills/gag-prompt-engineering/` |
| Estado | Criada como competência reutilizável com validação e limites explícitos |
| Finalidade | Preparar prompts auditáveis com contexto, restrições, fontes, lacunas e critérios de saída |
| Fontes | Grupo “Engenharia de prompts e metodologia de contexto” (5 fontes) da triagem |
| Limites | Não executa pedidos, não cria agentes/tools, não acede a contas, não autoriza integrações nem ações externas |

## Workflows criados

| Workflow | Ficheiro | Fontes preservadas | Estado |
|---|---|---|---|
| gag-assisted-knowledge-infographic-scripting | `workflows/gag-assisted-knowledge-infographic-scripting.md` | Grupo “Conhecimento assistido, infografia e roteiros” (6 fontes) | `APPROVED_INTERNAL_WORKFLOW` — limitado a rascunhos internos, com proveniência e aprovação humana |
| Arquitetura curricular e formação GAG Labs | `workflows/gag-labs-learning-architecture.md` | Grupo “Arquitetura curricular e formação GAG Labs” (2 fontes) | `REVIEW_REQUIRED` — exige confirmação de programa, público e materiais atuais |
| Produção de conteúdo, design e marca com IA | `workflows/content-design-and-brand-ai.md` | Grupo “Produção de conteúdo, design e marca com IA” (2 fontes) | `REVIEW_REQUIRED` — exige briefing, regras de marca e direitos de uso |

## Templates criados

| Template | Ficheiro | Fonte-grupo | Estado |
|---|---|---|---|
| Formação IA — fundamentos e prompting | `templates/ai-foundations-prompting.md` | Aula 1 (12 fontes) | `REVIEW_REQUIRED` |
| Formação IA — produção de conteúdo | `templates/ai-content-production.md` | Aula 2 (14 fontes) | `REVIEW_REQUIRED` |
| Formação IA — design com IA | `templates/ai-design.md` | Aula 3 (11 fontes) | `REVIEW_REQUIRED` |
| Formação IA — vídeo com IA | `templates/ai-video.md` | Aula 4 (11 fontes) | `REVIEW_REQUIRED` |
| Formação IA — projeto de marca e facilitação | `templates/brand-project-facilitation.md` | Aula 5 (10 fontes) | `REVIEW_REQUIRED` |

## Reference preservada sem oficialização

| Grupo | Quantidade | Estado | Regra |
|---|---:|---|---|
| Especificações de automação e ecossistemas externos | 12 | `REFERENCE_ONLY` | Não usar como integração, conta configurada ou autorização operacional. |
| Análise de negócio, risco, CRM e segurança | 3 | `REFERENCE_ONLY` | Não tratar como conselho profissional, decisão financeira/legal ou automação. |
| Coleções genéricas de prompts e produtividade | 3 | `REFERENCE_ONLY` | Usar apenas como comparação; não sustenta factos institucionais. |

## Itens em `REVIEW_REQUIRED`

1. **Conflito de identidade visual:** os manuais institucionais divergentes indicam paletas diferentes. Valores de cor, tipografia, lema e versão de logótipo não são reconciliados por esta transformação; aplicar a regra `BLOQUEADA_POR_CONFLITO` até confirmação humana.
2. **Dependência de ferramenta externa:** nenhuma menção a NotebookLM, Canva, Gemini, ChatGPT, Apps Script ou outra ferramenta foi convertida em integração do GAG Core. O workflow aprovado opera apenas como rascunho interno.
3. **Dois workflows ainda candidatos:** exigem as respetivas confirmações de programa, briefing, regras de marca, direitos de uso e fontes antes de uso operacional.
4. **Cinco templates de formação:** são estruturas candidatas para reutilização; exigem confirmação de objetivo, público, versão do conteúdo e fonte antes de uso operacional.
5. **Conteúdo de cliente, financeiro, jurídico, conta externa ou dados pessoais** encontrado no acervo permanece fora deste núcleo e não foi importado.
