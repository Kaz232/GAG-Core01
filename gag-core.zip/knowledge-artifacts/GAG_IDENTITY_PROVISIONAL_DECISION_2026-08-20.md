# Decisão provisória de identidade — 2026-08-20

**Decisor:** Proprietário da GAG Visual  
**Âmbito:** `content-design-and-brand-ai`  
**Estado:** `APROVADA_COM_LIMITES`

## Decisão registada

Para o workflow interno `content-design-and-brand-ai`, a tipografia provisória autorizada é **Roboto**. A autorização aplica-se apenas a rascunhos internos produzidos no âmbito deste workflow.

## Limites que permanecem em vigor

- Não aplicar Roboto no Brand Kit, na interface do GAG Core, noutros workflows ou em material externo.
- Não publicar, enviar, contactar terceiros, usar ferramentas externas, criar agentes ou alterar permissões.
- Não considerar resolvidos os conflitos sobre azul principal, prata/cinza, cores de apoio, Poppins, slogan/assinatura, cartão, redes sociais ou versão vigente do manual.
- Rever a decisão quando o proprietário confirmar a fonte de marca vigente e os direitos das fontes do workflow.

## Proveniência

- Pedido explícito do proprietário: 2026-08-20.
- Workflow: `knowledge-artifacts/workflows/content-design-and-brand-ai.md`.
- Intake de identidade: `knowledge-artifacts/GAG_IDENTITY_GUIDELINES_2026_INTAKE_2026-08-19.md`.

