# Intake — Diretrizes de Identidade Visual 2026

**Origem preservada:** `/home/ubuntu/upload/GAGVisual_DiretrizesdeIdentidadeVisual2026.json`.

**Natureza observada:** o ficheiro contém fontes HTML de uma apresentação de estratégia/identidade, incluindo referências a `REV.01`; não constitui, por si só, uma substituição aprovada do manual institucional carregado anteriormente.

## Estado

`REVIEW_REQUIRED` — nenhuma regra abaixo foi aplicada ao GAG Core, à Knowledge Base oficial ou à identidade em uso.

## Divergências observadas

| Área | Diretrizes 2026 observadas | Regra institucional vigente conhecida | Estado |
|---|---|---|---|
| Paleta principal | Preto `#000000` e dourado `#DAA520` | Azul `#003FD3`, prata/cinza `#A0A2AB`, dourado `#DAA520` | REVIEW_REQUIRED |
| Paleta de apoio | Cinza-carvão `#262626`, vinho `#800020`, branco-gelo `#F8F9FA` e proporção 60–30–10 | Branco, dourado e azul-escuro; demais conflitos já pendentes | REVIEW_REQUIRED |
| Tipografia | Neue Montreal, Inter e Space Mono | Montserrat Bold, Poppins SemiBold e Open Sans Regular | REVIEW_REQUIRED |
| Slogan | “Inovar Angola, construir o futuro.” | “Soluções com propósito, inovação com raízes.” / assinatura “Gerar, acolher e gerir.” | REVIEW_REQUIRED |
| Posicionamento | “motor da inovação digital em Luanda” e “estética premium” | Perfil institucional oficialmente aprovado deve prevalecer | REVIEW_REQUIRED |

## Limites de utilização

Utilizar este ficheiro apenas como referência de revisão de identidade. Não gerar publicação, comunicação externa, alteração automática de cores, fontes, slogan ou identidade. Preservar a separação entre GAG institucional e conteúdos de clientes.
