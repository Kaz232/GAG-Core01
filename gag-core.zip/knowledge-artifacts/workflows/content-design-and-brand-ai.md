# Workflow aprovado — Produção de conteúdo, design e marca com IA

**Estado:** `APPROVED_INTERNAL_WORKFLOW`  
**Âmbito aprovado:** rascunhos internos apenas.  
**Decisão humana:** proprietário, 2026-08-20.  
**Tipografia provisória autorizada:** `Roboto`, exclusivamente neste workflow e sem alterar a identidade visual aplicada no GAG Core.

**Limites permanentes:** não gera nem publica material final, não envia, não contacta terceiros, não usa ferramentas externas, não cria agentes, não altera permissões e não fixa regras de marca fora deste âmbito. Os restantes conflitos de identidade continuam `REVIEW_REQUIRED`.

1. Recolher briefing, objetivo, público, formato, canais, restrições e fontes de marca autorizadas.
2. Verificar direitos do material, informação factual e requisitos de continuidade visual/audiovisual.
3. Preparar rascunhos de copy, direção visual ou roteiro em formato de proposta.
4. Executar checklist de coerência, legibilidade, marca e fontes.
5. Submeter para aprovação humana antes de qualquer produção, publicação, contacto externo ou aplicação fora de rascunhos internos.

**Proveniência:** `Guia_Roteiros_e_Prompts_Cinematograficos.docx`; `PodesusarestepromptdiretamentenoCanva(MagicWrite_CanvaDocs)parag_20260725_150701_0000.jpg`.
**Revisão futura obrigatória:** confirmar a fonte de marca vigente e os direitos das fontes antes de autorizar qualquer uso externo.
