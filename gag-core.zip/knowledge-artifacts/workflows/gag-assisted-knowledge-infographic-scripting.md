# Workflow operacional — gag-assisted-knowledge-infographic-scripting

**Estado:** `APPROVED_INTERNAL_WORKFLOW`

**Autorização do proprietário:** rascunhos internos de conhecimento, roteiros e infografias, sujeitos a revisão humana obrigatória.

**Limite inegociável:** este workflow não publica, não envia, não contacta terceiros, não invoca ferramentas externas, não executa ações externas, não cria agentes e não altera permissões. Não ultrapassa qualquer estado `REVIEW_REQUIRED`.

## Entradas obrigatórias

| Campo | Regra de controlo |
|---|---|
| Briefing | Deve indicar objetivo, formato de rascunho e finalidade interna. |
| Fontes | Apenas fontes autorizadas e identificadas. |
| Idioma | Deve ser declarado antes da preparação do rascunho. |
| Proveniência | Deve manter a lista de fontes consultadas ligada à saída. |

## Fluxo autorizado

1. Receber e verificar briefing, fontes autorizadas, formato e idioma.
2. Separar `FACTOS_CONFIRMADOS` de `LACUNAS` sem preencher informação por inferência.
3. Se houver dados de cliente, direitos ou autoria incertos, conflito de marca, fonte não autorizada ou informação insuficiente, interromper o fluxo e marcar `REVIEW_REQUIRED`.
4. Produzir apenas um rascunho interno de conhecimento, roteiro ou infografia conforme o briefing validado.
5. Executar a verificação interna de clareza, fontes, continuidade, idioma e restrições de marca aplicáveis.
6. Apresentar a saída, a proveniência, os factos confirmados e as lacunas para aprovação humana. Sem essa aprovação, a saída permanece um rascunho interno.

## Dados obrigatórios na saída

`briefing`; `fontes`; `idioma`; `proveniência`; `factos_confirmados`; `lacunas`; `REVIEW_REQUIRED` quando aplicável; `aprovação_humana`.

## Proveniência preservada

`1783952239798prompts_notebooklm_invente_com_ia.docx`; `40PromptsExistentesAprimorados(ParaNotebookLM).pdf`; `PROMPTNOTEBOOKLM.pdf`; `PromptAtualização(1).pdf`; `Promptparainfográfico.pdf`; `PromptsVídeoNotebookLM.pdf`.

## Separação institucional

Qualquer conteúdo relacionado com PCA ou outro cliente/projeto permanece fora do conhecimento institucional GAG e exige tratamento isolado.
