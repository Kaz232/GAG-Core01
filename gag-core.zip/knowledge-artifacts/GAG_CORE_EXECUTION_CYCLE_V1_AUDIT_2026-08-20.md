# GAG Core — Auditoria Factual do Execution Cycle V1

**Data:** 20 de agosto de 2026  
**Escopo:** correção do Execution Router da KIA, capacidade interna comprovada, segurança, UX e validação técnica.  
**Regra de leitura:** este documento regista somente comportamentos verificados no código, na persistência e na validação automatizada. Não transforma gaps em funcionalidades nem oficializa conteúdo.

## Resultado executivo

O GAG Core possui um **router de execução da KIA** que classifica a mensagem antes da consulta ao modelo. Comandos operacionais, pedidos documentais, consultas de conhecimento, criação de tarefas e gestão da Agent Factory já não são tratados como a mesma intenção. A KIA não executa código, deploy, ações externas, pagamentos, contactos ou publicação a partir do chat.

## Capacidades e limites verificados

| Área | Estado factual | Limite ou percurso obrigatório |
|---|---|---|
| Conversa e orientação | READY | Resposta contextual, sem alteração operacional. |
| Consulta de conhecimento | READY | Usa conhecimento e contexto disponíveis; não oficializa novo conteúdo. |
| Consulta de backlog/tarefas | READY | Leitura interna sem alteração. |
| Preparação de tarefa | CONFIRMATION_REQUIRED | O Kernel permite apenas `TASK_CREATE` e `TASK_UPDATE_PRIORITY`, com plano, nonce, confirmação humana, transação e auditoria HMAC. |
| Agent Factory | CONFIRMATION_REQUIRED | Especificação, revisão e aprovação por ciclo de vida; múltiplos agentes por nome/slug único. |
| Document Intelligence | CONFIRMATION_REQUIRED | A análise inicia no painel próprio com ficheiro e objetivo explícitos; resultados `REVIEW_REQUIRED` não são exportáveis. |
| Exportação documental | CONFIRMATION_REQUIRED | Apenas PDF aprovado, com proveniência e trilho de auditoria. |
| Scanner de Economia Real | NOT_IMPLEMENTED | Não há fonte de dados verificada nem ferramenta registada; a KIA informa o limite. |
| Colaboração de equipa | NOT_IMPLEMENTED | Não existem utilizadores de equipa, atribuições ou notificações implementadas. |
| Implementação do sistema via chat | NOT_IMPLEMENTED | A KIA não altera código, executa testes, build, deploy ou configurações a partir do chat. |
| Ações externas | BLOCKED | Envios, contactos, publicação, pagamentos, transferências e integrações externas permanecem bloqueados. |

## Correção do Execution Router

O módulo `shared/kiaExecutionRouter.ts` define as intenções canónicas, o registry das capacidades permitidas, o respetivo estado, necessidade de confirmação e handler factual. A prioridade de classificação é: ação externa bloqueada; ciclo de vida de agente; alteração do sistema; ferramenta interna; colaboração de equipa; documento; tarefa/backlog; conhecimento; conversa.

O router devolve uma rota estruturada ao chat. A interface apresenta a intenção, a capacidade, o estado e a necessidade de confirmação, em vez de apresentar uma capacidade ausente como disponível. Pedidos de análise/exportação documental são encaminhados para o painel Document Intelligence; pedidos de scanner económico ou colaboração não são simulados.

## Segurança preservada

| Controlo | Estado |
|---|---|
| Kaz | Preservado; não recebeu permissões novas. |
| Consultor GAG | Preservado; nenhum agente novo foi criado neste ciclo. |
| Agent Factory | Mantém revisão humana, validação de especificação e unicidade de ID/slug. |
| Internal Execution Kernel | Allow-list limitada a `TASK_CREATE` e `TASK_UPDATE_PRIORITY`; segredos não expostos. |
| Documentos | Exportação PDF apenas após aprovação; estados `REVIEW_REQUIRED` preservados. |
| Pacotes externos recebidos | Mantidos isolados; não foram integrados nem executados. |

## UX e acessibilidade validadas

O tema escuro recebeu reforço de contraste para texto contextual e de cartões. No formato móvel, a navegação horizontal das secções continua rolável e agora informa explicitamente como aceder às restantes áreas. A leitura foi confirmada em desktop e em largura móvel.

## Evidência de validação

| Verificação | Resultado |
|---|---|
| TypeScript | `pnpm check` aprovado. |
| Testes Vitest | 34 ficheiros e 128 testes aprovados. |
| Router da KIA | 9 testes específicos aprovados, incluindo intenção operacional, documento, tarefa, Agent Factory, ferramenta ausente e ação externa bloqueada. |
| Build | Build de produção concluído. Existe apenas aviso de tamanho de chunk acima de 500 kB; não bloqueou a compilação. |
| Interface | Dashboard e navegação validados em desktop e móvel. |
| Registos recentes | Nenhum erro novo do router encontrado; o registo de limite de 6.000 caracteres é anterior à correção já publicada. |

## Gaps reais para decisão futura

1. O Scanner de Economia Real exige fontes autorizadas, critérios de proveniência e um plano específico antes de existir como ferramenta.
2. Colaboração de equipa, atribuições por membro e notificações não estão implementadas.
3. A validação da ação operacional real no domínio publicado requer sessão privada do proprietário; o ambiente automatizado confirmou somente entrada pública protegida.
4. O aviso de chunk do build sugere futura divisão de código, mas não é falha funcional ou de segurança.
