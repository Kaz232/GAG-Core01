# Auditoria multiagente — achados pré-correção

**Data:** 20 de agosto de 2026  
**Âmbito:** Agent Factory, KIA conversacional e persistência de agentes especializados.

## Factos confirmados

1. A tabela `specialized_agents` não tem restrição de agente único e já suporta vários registos com ciclos de vida independentes.
2. A criação estava bloqueada na rota `createAgent`: qualquer registo existente causava erro de conflito, mesmo quando o novo nome era diferente.
3. A conversa da KIA repetia o mesmo bloqueio, devolvendo `existing_agent` quando existia pelo menos um agente.
4. A interface já possui uma lista de agentes e ações por linha, pelo que não exige redesenho para suportar múltiplos rascunhos.
5. O controlo correto deve ser a unicidade normalizada de nome e não a existência de qualquer agente.

## Limites preservados

- O Kaz continua inalterado e ativo.
- A criação exige desbloqueio da Agent Factory e confirmação humana da especificação.
- Todo novo agente inicia em `Rascunho`.
- SEND, PUBLISH e EXECUTE continuam bloqueadas.
- A ativação continua a exigir o ciclo `Rascunho → Em Teste → Ativo` e autorização humana.

## Correção planeada

Substituir a condição global de agente existente por verificação de nome normalizado e alinhar a resposta da KIA e a cópia da interface com a capacidade multiagente controlada.
