# Auditoria de capacidades — GAG Core MVP

**Data:** 2026-08-20  
**Método:** inspeção estática do código, schema, testes, artefactos e interface pública. Nenhuma integração externa, credencial ou pacote não verificado foi executado.

## Matriz de capacidades verificadas

| Capacidade | Estado | Implementação real | Testes/evidência | Gap factual |
|---|---|---|---|---|
| KIA | IMPLEMENTADO | Chat, contexto, memória, RAG e propostas condicionadas a confirmação. | `gagMasterCore`, `kiaProcedure`, `kiaConversation`. | Não executa ações externas. |
| KIA Voice | PARCIAL | Web Speech com turn-taking e controlo de interrupção. | Testes de voz e UI. | Depende do navegador; não há voz em servidor. |
| Knowledge Base | IMPLEMENTADO | Base interna, proveniência, estados de revisão e conhecimento aprovado. | Intake, corpus e RAG. | Conteúdo pendente não é oficial. |
| Skills | PARCIAL | Skills reutilizáveis existem no ambiente de trabalho. | Inventário de SKILL.md. | Não existe runtime genérico que carregue/executa cada skill como ferramenta. |
| Tools | PARCIAL | Ferramentas internas de tarefas, documentos e Kernel. | Routers e testes. | Sem catálogo universal de ferramentas nem execução externa. |
| Kaz | IMPLEMENTADO | Coordenação executiva para pedidos internos elegíveis. | `kazExecutiveCoordination`. | Só propõe ações no Kernel. |
| Agent Factory | IMPLEMENTADO | Ciclo independente de rascunho, teste, aprovação e ativação. | Fluxo e testes de unicidade/multiagente. | Criação do Consultor GAG exige sessão autenticada. |
| Execution Kernel | IMPLEMENTADO | `TASK_CREATE` e `TASK_UPDATE_PRIORITY`, HMAC, nonce, expiração e auditoria. | 12 testes do Kernel. | Nenhuma outra ação é permitida. |
| Upload | IMPLEMENTADO | Receção isolada de PDF, DOCX, XLSX, CSV, texto e imagem. | Document Intelligence. | Limite de tamanho e extração dependem do tipo. |
| Processamento documental | IMPLEMENTADO | Extração, análise, lacunas, conflitos e revisão humana. | Testes Document Intelligence. | Resultados não aprovados não são oficiais. |
| Exportação/download | PARCIAL | Relatórios de análise exportados em PDF após aprovação. | PDF e regras de aprovação. | DOCX/CSV/XLSX/IMG não são exportações implementadas. |
| PDF | IMPLEMENTADO | Relatório com capa, hash, decisão, revisor e selo. | `documentReportPdf.test`. | Apenas depois de `APPROVED`. |
| Imagem | PARCIAL | Upload/extração de imagem e aplicação de ativos institucionais. | Document Intelligence e marca. | Não há gerador de imagem operacional próprio. |
| Infografia | NÃO IMPLEMENTADO | Existe workflow de rascunho interno. | Workflow/skill. | Não existe gerador/exportador de infografias no produto. |
| Vídeo | NÃO IMPLEMENTADO | Não existe módulo de produção de vídeo no Core. | Inventário de módulos. | Skill/procedimento não equivale a geração real. |
| Reporting | IMPLEMENTADO | Relatórios internos de documentos e resultados operacionais auditáveis. | PDF e Kaz/Kernel. | Sem pacote genérico de BI. |
| Análise de dados | PARCIAL | Análises de documentos e conhecimento por LLM. | Document Intelligence. | Sem pipeline tabular/estatístico dedicado no produto. |
| Scanner da economia real | NÃO IMPLEMENTADO | Skill atualizada como procedimento de pesquisa verificável. | `gag-economic-scanner/SKILL.md`. | Não existe tela, fonte integrada, pipeline ou exportação de scanner. |
| CRM | NÃO IMPLEMENTADO | Não existe conector ou modelo CRM ativo no Core. | Auditoria estática. | Pacotes recebidos permanecem isolados. |
| Workflows | IMPLEMENTADO | Biblioteca com estados e decisões humanas; um workflow aprovado apenas para rascunhos internos. | Corpus/revisão. | Seis artefactos ainda exigem decisão. |
| Autenticação | IMPLEMENTADO | Manus OAuth, rotas protegidas e feedback de login. | Auth gate/feedback/simulação. | Teste real de criação exige sessão privada. |
| Permissões | IMPLEMENTADO | Owner-only, decisões auditáveis e políticas de agente. | Routers, schema e testes. | Não há papéis de equipa além dos limites atuais. |
| Audit log | IMPLEMENTADO | Decisões de revisão e Kernel append-only selado por HMAC. | Kernel/audit e decisões. | Histórico não substitui monitorização externa. |
| Persistência | IMPLEMENTADO | MySQL/TiDB via Drizzle e migrações. | Schema e migrações 0000–0013. | Não valida dados fora do modelo definido. |
| Mobile | IMPLEMENTADO | Interface responsiva e PWA. | Captura móvel de 375px. | Fluxo autenticado completo ainda requer validação manual. |
| Desktop | IMPLEMENTADO | Dashboard e painéis responsivos. | Captura de 1280px. | Fluxo autenticado completo ainda requer validação manual. |
| Build | IMPLEMENTADO | Build Vite/esbuild concluído. | `pnpm build`. | Bundle principal excede 500 kB; é aviso de otimização, não falha. |
| Deploy/produção | PARCIAL | Domínio publicado e checkpoint anterior disponível. | Domínio público configurado. | A versão multiagente aguarda checkpoint e teste autenticado após publicação. |

## Limites confirmados

| Área | Estado factual | Limite atual |
|---|---|---|
| Ações externas | Bloqueadas | Não existe envio WhatsApp/e-mail, publicação social, webhook externo, transação ou contacto automatizado. |
| Scanner económico | Não integrado | Existia apenas uma skill incompleta; foi atualizada para procedimento interno baseado em fontes verificáveis, ainda sem módulo de aplicação ou feeds. |
| CRM e canais comerciais | Não integrados | Não existe conector real para Meta, WhatsApp, Google Sheets ou CRM externo no GAG Core. |
| Geração de imagem | Infraestrutura disponível, fluxo GAG não confirmado | Não há módulo próprio de produção visual integrado ao painel operacional. |
| Dados económicos em tempo real | Não implementados | Requer fontes identificadas e revisão humana; nenhum dado é inventado ou puxado automaticamente. |

## Regras preservadas

- Não foram criados clientes nem inseridos dados fictícios.
- A criação de agentes permanece sujeita a confirmação e o agente solicitado só pode existir em `DRAFT`.
- A ativação, autonomia e ações externas permanecem bloqueadas até autorização humana e validação própria.
- A decisão provisória de Roboto não resolve os restantes conflitos de identidade.

## Próximas validações necessárias

1. Criar o rascunho `Consultor GAG` através de sessão autenticada do proprietário.
2. Executar testes completos, build e verificação do domínio depois da correção multiagente.
3. Consolidar matriz de skills e recomendar apenas integrações comprovadas e necessárias.
