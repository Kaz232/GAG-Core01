# Documento interno de exemplo — teste controlado

> **Não oficial. Não contém dados de clientes, contratos, preços, faturas ou pessoas reais.**

## Finalidade

Validar a extração de texto e o ciclo de revisão humana do GAG Core Document Intelligence.

## Briefing de teste

- Objetivo: organizar um pequeno conteúdo interno para revisão.
- Idioma: português.
- Saída permitida: rascunho interno e relatório exportável somente após aprovação humana.

## Factos do teste

1. O documento foi criado exclusivamente para teste técnico.
2. Não autoriza publicação, contacto, envio ou ação externa.
3. Qualquer lacuna deve continuar em `REVIEW_REQUIRED`.

