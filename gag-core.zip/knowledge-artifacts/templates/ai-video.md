# Template candidato — Formação IA: vídeo com IA

**Estado:** `REVIEW_REQUIRED`

- Mensagem, público e duração: [preencher]
- Idioma e tom: [preencher]
- Fontes e direitos de uso: [preencher]
- Cenas, continuidade e restrições: [preencher]
- Critérios de qualidade: [preencher]
- Aprovação antes de produção/publicação: [preencher]

**Proveniência:** Grupo “Formação IA — vídeo com IA (Aula 4)” da triagem, 11 fontes. Ver `GAG_PROMPT_TRIAGE_REPORT_2026-08-19.md`.

