# Template candidato — Formação IA: design com IA

**Estado:** `REVIEW_REQUIRED`

- Objetivo visual: [preencher]
- Fonte de marca vigente: [preencher]
- Público, formato e dimensões: [preencher]
- Restrições e elementos proibidos: [preencher]
- Referências autorizadas: [preencher]
- Checklist e aprovação humana: [preencher]

**Proveniência:** Grupo “Formação IA — design com IA (Aula 3)” da triagem, 11 fontes. Ver `GAG_PROMPT_TRIAGE_REPORT_2026-08-19.md`.

