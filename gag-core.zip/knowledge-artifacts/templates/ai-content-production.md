# Template candidato — Formação IA: produção de conteúdo

**Estado:** `REVIEW_REQUIRED`

- Objetivo e resultado: [preencher]
- Público, canal e formato: [preencher]
- Factos e fontes autorizadas: [preencher]
- Estrutura de conteúdo: [preencher]
- Critérios de qualidade: [preencher]
- Aprovação necessária: [preencher]

**Proveniência:** Grupo “Formação IA — produção de conteúdo (Aula 2)” da triagem, 14 fontes. Ver `GAG_PROMPT_TRIAGE_REPORT_2026-08-19.md`.

