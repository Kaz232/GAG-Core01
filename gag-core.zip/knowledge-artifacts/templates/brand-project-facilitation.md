# Template candidato — Formação IA: projeto de marca e facilitação

**Estado:** `REVIEW_REQUIRED`

- Objetivo do projeto: [preencher]
- Escopo interno/cliente isolado: [preencher]
- Evidência e fonte de marca: [preencher]
- Atividades e entrega proposta: [preencher]
- Critérios de avaliação: [preencher]
- Confirmação humana necessária: [preencher]

**Proveniência:** Grupo “Formação IA — projeto de marca e facilitação (Aula 5)” da triagem, 10 fontes. Ver `GAG_PROMPT_TRIAGE_REPORT_2026-08-19.md`.

