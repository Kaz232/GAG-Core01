import { describe, expect, it } from "vitest";
import { decideKnowledgeIntake } from "./knowledgeIntakeProtocol";

describe("knowledge intake protocol", () => {
  it("accepts verified internal GAG methodology as retrievable knowledge", () => {
    expect(
      decideKnowledgeIntake({
        origin: "GAG_INTERNAL",
        materialType: "METHODOLOGY",
        verified: true,
      })
    ).toMatchObject({
      decision: "APPROVED_KNOWLEDGE",
      mayEnterKiaOperationalContext: true,
      mayCreateSkillOrTool: false,
    });
  });

  it("keeps a prompt as reference without owner approval", () => {
    expect(
      decideKnowledgeIntake({
        origin: "EXTERNAL_REFERENCE",
        materialType: "PROMPT",
        verified: true,
      })
    ).toMatchObject({
      decision: "REFERENCE_ONLY",
      mayEnterKiaOperationalContext: false,
      mayCreateSkillOrTool: false,
    });
  });

  it("keeps an owner-approved prompt as a candidate rather than creating a skill", () => {
    expect(
      decideKnowledgeIntake({
        origin: "GAG_INTERNAL",
        materialType: "SKILL_SPECIFICATION",
        verified: true,
        hasExplicitOwnerApproval: true,
      })
    ).toMatchObject({
      decision: "CANDIDATE_REQUIRES_OWNER_APPROVAL",
      mayEnterKiaOperationalContext: false,
      mayCreateSkillOrTool: false,
    });
  });

  it("quarantines client material from the GAG internal core", () => {
    expect(
      decideKnowledgeIntake({
        origin: "CLIENT",
        materialType: "OPERATIONAL_PROCEDURE",
        verified: true,
      })
    ).toMatchObject({ decision: "QUARANTINE_CLIENT_SCOPE", mayEnterKiaOperationalContext: false });
  });

  it("quarantines invoices and sensitive financial material", () => {
    expect(
      decideKnowledgeIntake({
        origin: "GAG_INTERNAL",
        materialType: "INVOICE",
        verified: true,
      })
    ).toMatchObject({ decision: "QUARANTINE_SENSITIVE_REVIEW", mayEnterKiaOperationalContext: false });
  });

  it("preserves exact duplicates only as provenance references", () => {
    expect(
      decideKnowledgeIntake({
        origin: "GAG_INTERNAL",
        materialType: "METHODOLOGY",
        verified: true,
        isDuplicateExact: true,
      })
    ).toMatchObject({ decision: "DUPLICATE_REFERENCE", mayEnterKiaOperationalContext: false });
  });
});
