import { describe, expect, it } from "vitest";
import { buildInternalDocumentReport, getDocumentExportBlockReason, isDocumentExportAllowed } from "./documentApprovalExport";

describe("aprovação e exportação de Document Intelligence", () => {
  it("bloqueia exportação enquanto a revisão não estiver aprovada", () => {
    expect(isDocumentExportAllowed("PENDING")).toBe(false);
    expect(isDocumentExportAllowed("CHANGES_REQUESTED")).toBe(false);
    expect(getDocumentExportBlockReason("REJECTED")).toContain("bloqueada");
  });

  it("autoriza somente a decisão explícita APPROVED", () => {
    expect(isDocumentExportAllowed("APPROVED")).toBe(true);
    expect(getDocumentExportBlockReason("APPROVED")).toBeNull();
  });

  it("inclui proveniência e fronteira interna no relatório exportado", () => {
    const report = buildInternalDocumentReport({
      analysisId: 3, filename: "teste.md", contentHash: "abc123", requestedIntent: "Resumir", summary: "Resumo validado.",
      analysisJson: JSON.stringify({ keyInformation: [{ fact: "Facto confirmado" }], missingInformation: ["Lacuna"], reviewReasons: ["Revisão" ] }),
      approvedAt: new Date("2026-08-19T10:00:00Z"), reviewNote: "Aprovação de teste.",
    });
    expect(report).toContain("abc123");
    expect(report).toContain("Facto confirmado");
    expect(report).toContain("Uso interno");
  });
});
