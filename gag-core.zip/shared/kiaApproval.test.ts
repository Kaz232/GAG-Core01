import { describe, expect, it } from "vitest";
import { isKiaApprovalEligible } from "./kiaApproval";

describe("Kia Agent Factory approval", () => {
  const approved = {
    textValidated: true,
    voiceValidated: true,
    contextValidated: true,
    safetyConfirmed: true,
  };

  it("only unlocks draft preparation when every owner criterion is confirmed", () => {
    expect(isKiaApprovalEligible(approved)).toBe(true);
    expect(isKiaApprovalEligible({ ...approved, voiceValidated: false })).toBe(false);
  });
});
