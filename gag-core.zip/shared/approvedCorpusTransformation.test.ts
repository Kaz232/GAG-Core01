import { describe, expect, it } from "vitest";
import {
  APPROVED_CORPUS_TRANSFORMATION,
  hasForbiddenCorpusSideEffect,
  summarizeApprovedCorpusTransformation,
} from "./approvedCorpusTransformation";

describe("approved corpus transformation", () => {
  it("maps exactly the owner-approved transformation scope", () => {
    expect(summarizeApprovedCorpusTransformation()).toEqual({
      KNOWLEDGE: 1,
      SKILL: 1,
      WORKFLOW: 3,
      TEMPLATE: 5,
      REFERENCE: 3,
    });
  });

  it("keeps the remaining workflows and templates that need review out of official knowledge", () => {
    const reviewRequired = APPROVED_CORPUS_TRANSFORMATION.filter((artifact) => artifact.status === "REVIEW_REQUIRED");
    expect(reviewRequired).toHaveLength(6);
    expect(reviewRequired.every((artifact) => artifact.kind === "WORKFLOW" || artifact.kind === "TEMPLATE")).toBe(true);
    expect(reviewRequired.some((artifact) => artifact.id === "content-design-and-brand-ai")).toBe(false);
  });

  it("approves only the named workflow for internal drafts without external side effects", () => {
    const workflow = APPROVED_CORPUS_TRANSFORMATION.find(
      (artifact) => artifact.id === "gag-assisted-knowledge-infographic-scripting",
    );

    expect(workflow).toMatchObject({
      kind: "WORKFLOW",
      status: "APPROVED_INTERNAL_WORKFLOW",
      sourceGroup: "Conhecimento assistido, infografia e roteiros",
      sourceCount: 6,
      createsAgent: false,
      enablesExternalAction: false,
    });
  });

  it("keeps the three reference groups reference-only", () => {
    const references = APPROVED_CORPUS_TRANSFORMATION.filter((artifact) => artifact.kind === "REFERENCE");
    expect(references).toHaveLength(3);
    expect(references.every((artifact) => artifact.status === "REFERENCE_ONLY")).toBe(true);
  });

  it("does not create agents or enable external actions", () => {
    expect(APPROVED_CORPUS_TRANSFORMATION.some(hasForbiddenCorpusSideEffect)).toBe(false);
  });
});
