export const DOCUMENT_INTELLIGENCE_MAX_BYTES = 6 * 1024 * 1024;
export const DOCUMENT_INTELLIGENCE_MAX_EXTRACTED_CHARS = 55_000;

export const DOCUMENT_TYPES = ["PDF", "DOCX", "XLSX", "CSV", "IMAGE", "TEXT", "OTHER"] as const;
export type DocumentType = (typeof DOCUMENT_TYPES)[number];

export const DOCUMENT_OPERATIONS = ["ANALYZE", "SUMMARIZE", "EXTRACT_VALUES", "COMPARE", "ORGANIZE", "REPORT"] as const;
export type DocumentOperation = (typeof DOCUMENT_OPERATIONS)[number];

export type ReviewStatus = "COMPLETED" | "REVIEW_REQUIRED" | "FAILED";

export type DocumentAnalysisResult = {
  documentSummary: string;
  documentType: string;
  keyInformation: Array<{ fact: string; sourceReference: string }>;
  detectedValues: Array<{ label: string; value: string; sourceReference: string }>;
  organization: Array<{ section: string; content: string; sourceReference: string }>;
  insights: string[];
  missingInformation: string[];
  conflictsOrInconsistencies: string[];
  risks: string[];
  suggestedActions: string[];
  sources: Array<{ sourceReference: string; excerpt: string }>;
  requiresHumanReview: boolean;
  professionalReviewRequired: boolean;
  reviewReasons: string[];
};

export function detectDocumentType(filename: string, mimeType = ""): DocumentType {
  const lower = filename.toLowerCase();
  const mime = mimeType.toLowerCase();
  if (lower.endsWith(".pdf") || mime === "application/pdf") return "PDF";
  if (lower.endsWith(".docx") || mime.includes("wordprocessingml")) return "DOCX";
  if (lower.endsWith(".xlsx") || mime.includes("spreadsheetml")) return "XLSX";
  if (lower.endsWith(".csv") || mime === "text/csv") return "CSV";
  if (/\.(png|jpe?g|webp)$/i.test(lower) || mime.startsWith("image/")) return "IMAGE";
  if (/\.(txt|md|json)$/i.test(lower) || mime.startsWith("text/")) return "TEXT";
  return "OTHER";
}

export function isDocumentFileAllowed(filename: string, mimeType = ""): boolean {
  return detectDocumentType(filename, mimeType) !== "OTHER";
}

export function normalizeDocumentOperation(intent: string): DocumentOperation {
  const value = intent.toLocaleLowerCase("pt-PT");
  if (/compar|diferen|vers(ã|a)o/.test(value)) return "COMPARE";
  if (/extrai|extraia|valor|número|numero|campo|fatura|invoice/.test(value)) return "EXTRACT_VALUES";
  if (/organiza|classifica|estrutura/.test(value)) return "ORGANIZE";
  if (/relatório|relatorio|report/.test(value)) return "REPORT";
  if (/resume|resumo|sumari/.test(value)) return "SUMMARIZE";
  return "ANALYZE";
}

export function isFinancialOrLegalDocumentIntent(intent: string): boolean {
  return /fatura|invoice|pagamento|financeir|contabil|imposto|contrato|legal|juríd|jurid|recibo/.test(intent.toLocaleLowerCase("pt-PT"));
}

export function sanitizeExtractedContent(content: string): string {
  return content.replace(/\u0000/g, "").trim().slice(0, DOCUMENT_INTELLIGENCE_MAX_EXTRACTED_CHARS);
}

export function createSafeFallbackAnalysis(params: {
  documentType: DocumentType;
  reason: string;
  professionalReviewRequired?: boolean;
}): DocumentAnalysisResult {
  return {
    documentSummary: "A análise automática não produziu evidência suficiente para um resumo confiável.",
    documentType: params.documentType,
    keyInformation: [],
    detectedValues: [],
    organization: [],
    insights: [],
    missingInformation: ["Conteúdo verificável insuficiente para concluir a análise."],
    conflictsOrInconsistencies: [],
    risks: ["Não utilizar este resultado como decisão operacional sem revisão humana."],
    suggestedActions: ["Rever o documento original e reenviar uma fonte legível, completa e autorizada."],
    sources: [],
    requiresHumanReview: true,
    professionalReviewRequired: Boolean(params.professionalReviewRequired),
    reviewReasons: [params.reason],
  };
}

export function validateDocumentAnalysisResult(value: unknown): DocumentAnalysisResult {
  const fallback = createSafeFallbackAnalysis({ documentType: "OTHER", reason: "A resposta analítica não estava estruturada de forma verificável." });
  if (!value || typeof value !== "object") return fallback;
  const candidate = value as Partial<DocumentAnalysisResult>;
  const text = (item: unknown, max = 2_000) => typeof item === "string" ? item.slice(0, max) : "";
  const stringList = (item: unknown) => Array.isArray(item) ? item.filter((entry): entry is string => typeof entry === "string").map((entry) => entry.slice(0, 1_000)).slice(0, 20) : [];
  const records = (item: unknown, keys: string[]) => Array.isArray(item) ? item.slice(0, 30).flatMap((entry) => {
    if (!entry || typeof entry !== "object") return [];
    const record = entry as Record<string, unknown>;
    const normalized: Record<string, string> = {};
    for (const key of keys) normalized[key] = text(record[key], 2_000);
    return keys.every((key) => normalized[key]) ? [normalized] : [];
  }) : [];

  return {
    documentSummary: text(candidate.documentSummary) || fallback.documentSummary,
    documentType: text(candidate.documentType, 160) || "Documento fornecido",
    keyInformation: records(candidate.keyInformation, ["fact", "sourceReference"]) as DocumentAnalysisResult["keyInformation"],
    detectedValues: records(candidate.detectedValues, ["label", "value", "sourceReference"]) as DocumentAnalysisResult["detectedValues"],
    organization: records(candidate.organization, ["section", "content", "sourceReference"]) as DocumentAnalysisResult["organization"],
    insights: stringList(candidate.insights),
    missingInformation: stringList(candidate.missingInformation),
    conflictsOrInconsistencies: stringList(candidate.conflictsOrInconsistencies),
    risks: stringList(candidate.risks),
    suggestedActions: stringList(candidate.suggestedActions),
    sources: records(candidate.sources, ["sourceReference", "excerpt"]) as DocumentAnalysisResult["sources"],
    requiresHumanReview: true,
    professionalReviewRequired: Boolean(candidate.professionalReviewRequired),
    reviewReasons: stringList(candidate.reviewReasons),
  };
}

export function isDocumentAnalysisIntent(message: string): boolean {
  const normalized = message.toLocaleLowerCase("pt-PT");
  return /\b(documento|pdf|docx|xlsx|ficheiro|arquivo|fatura|invoice|recibo|contrato|extrai|resum|analis|compar|organiza)\b/.test(normalized);
}
