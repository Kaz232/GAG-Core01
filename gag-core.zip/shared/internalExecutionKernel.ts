import { createHash } from "node:crypto";
import { z } from "zod";

export const INTERNAL_EXECUTION_ACTION_TYPES = ["TASK_CREATE", "TASK_UPDATE_PRIORITY"] as const;
export type InternalExecutionActionType = (typeof INTERNAL_EXECUTION_ACTION_TYPES)[number];
export const INTERNAL_EXECUTION_SOURCES = ["KIA", "KAZ"] as const;
export type InternalExecutionSource = (typeof INTERNAL_EXECUTION_SOURCES)[number];
export const INTERNAL_EXECUTION_TTL_MS = 10 * 60 * 1000;
export const INTERNAL_EXECUTION_MAX_ACTIONS = 1;

const taskPrioritySchema = z.enum(["Baixa", "Média", "Alta", "Urgente"]);

export const internalExecutionActionSchema = z.discriminatedUnion("type", [
  z.object({
    type: z.literal("TASK_CREATE"),
    brandId: z.number().int().positive(),
    title: z.string().trim().min(1).max(255),
    description: z.string().trim().max(6000).default(""),
    priority: taskPrioritySchema.default("Média"),
    quarter: z.string().trim().min(1).max(16).default("Operação atual"),
    dueDate: z.string().regex(/^\d{4}-\d{2}-\d{2}$/).nullable().optional(),
  }),
  z.object({
    type: z.literal("TASK_UPDATE_PRIORITY"),
    brandId: z.number().int().positive(),
    taskId: z.number().int().positive(),
    priority: taskPrioritySchema,
  }),
]);

export type InternalExecutionAction = z.infer<typeof internalExecutionActionSchema>;

export const internalExecutionPlanInputSchema = z.object({
  source: z.enum(INTERNAL_EXECUTION_SOURCES),
  action: internalExecutionActionSchema,
});

export type InternalExecutionPlanInput = z.infer<typeof internalExecutionPlanInputSchema>;

function canonicalizeValue(value: unknown): unknown {
  if (Array.isArray(value)) return value.map(canonicalizeValue);
  if (value && typeof value === "object") {
    return Object.fromEntries(Object.entries(value as Record<string, unknown>)
      .filter(([, child]) => child !== undefined)
      .sort(([left], [right]) => left.localeCompare(right))
      .map(([key, child]) => [key, canonicalizeValue(child)]));
  }
  return value;
}

export function canonicalizeExecutionPayload(value: unknown): string {
  return JSON.stringify(canonicalizeValue(value));
}

export function calculateExecutionPlanHash(input: InternalExecutionPlanInput): string {
  return createHash("sha256").update(canonicalizeExecutionPayload(input)).digest("hex");
}

export function isInternalExecutionActionAllowed(action: { type: string }): action is InternalExecutionAction {
  return INTERNAL_EXECUTION_ACTION_TYPES.includes(action.type as InternalExecutionActionType);
}

export function isExecutionPlanExpired(expiresAt: Date, now = new Date()): boolean {
  return expiresAt.getTime() <= now.getTime();
}

export function summarizeInternalExecutionAction(action: InternalExecutionAction): string {
  if (action.type === "TASK_CREATE") {
    return `Criar tarefa interna “${action.title}” com prioridade ${action.priority}.`;
  }
  return `Alterar a prioridade da tarefa #${action.taskId} para ${action.priority}.`;
}
