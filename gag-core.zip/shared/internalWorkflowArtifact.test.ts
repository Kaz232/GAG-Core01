import { readFileSync } from "node:fs";
import { describe, expect, it } from "vitest";

const workflowPath = new URL("../knowledge-artifacts/workflows/gag-assisted-knowledge-infographic-scripting.md", import.meta.url);
const testPath = new URL("../knowledge-artifacts/workflow-tests/2026-08-19-gag-assisted-knowledge-infographic-scripting.md", import.meta.url);

describe("gag-assisted-knowledge-infographic-scripting", () => {
  it("preserves mandatory inputs, review gates and prohibited actions", () => {
    const workflow = readFileSync(workflowPath, "utf8");

    ["Briefing", "Fontes", "Idioma", "Proveniência", "FACTOS_CONFIRMADOS", "LACUNAS", "REVIEW_REQUIRED", "aprovação humana"].forEach(
      (requiredField) => expect(workflow).toContain(requiredField),
    );
    ["não publica", "não envia", "não contacta terceiros", "não invoca ferramentas externas", "não cria agentes", "não altera permissões"].forEach(
      (prohibitedAction) => expect(workflow).toContain(prohibitedAction),
    );
  });

  it("records the practical run as an internal draft awaiting human review", () => {
    const testRecord = readFileSync(testPath, "utf8");

    expect(testRecord).toContain("**Estado:** `REVIEW_REQUIRED`");
    expect(testRecord).toContain("**Aprovação humana:** `PENDENTE`");
    expect(testRecord).toContain("Nenhuma ação externa, cliente, agente ou alteração de permissões");
    expect(testRecord).toContain("Rascunho gerado");
  });
});
