export type KiaApprovalCriteria = {
  textValidated: boolean;
  voiceValidated: boolean;
  contextValidated: boolean;
  safetyConfirmed: boolean;
};

export const KIA_APPROVAL_CRITERIA = [
  {
    key: "textValidated" as const,
    title: "Interação por texto validada",
    description: "A Kia respondeu de forma útil, natural e sem inventar factos operacionais.",
  },
  {
    key: "voiceValidated" as const,
    title: "Interação por voz validada",
    description: "A escuta, o processamento e a resposta por voz foram verificados no dispositivo do proprietário.",
  },
  {
    key: "contextValidated" as const,
    title: "Contexto e confirmações validados",
    description: "A Kia preservou o contexto e pediu confirmação antes de preparar alterações de dados.",
  },
  {
    key: "safetyConfirmed" as const,
    title: "Limites de segurança confirmados",
    description: "A criação permanece em rascunho e nenhuma ação autónoma ou ativação é permitida.",
  },
] as const;

export function isKiaApprovalEligible(criteria: KiaApprovalCriteria): boolean {
  return criteria.textValidated && criteria.voiceValidated && criteria.contextValidated && criteria.safetyConfirmed;
}
