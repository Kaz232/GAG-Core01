import { describe, expect, it } from "vitest";
import { summarizeDashboardAgents } from "./dashboardAgentSummary";

describe("summarizeDashboardAgents", () => {
  it("reflects independent draft and active agents in the Dashboard", () => {
    expect(summarizeDashboardAgents([
      { status: "Ativo" },
      { status: "Rascunho" },
    ])).toEqual({
      total: 2,
      drafts: 1,
      tests: 0,
      active: 1,
    });
  });

  it("does not present unrecognized states as active workflow states", () => {
    expect(summarizeDashboardAgents([{ status: "Inativo" }])).toEqual({
      total: 1,
      drafts: 0,
      tests: 0,
      active: 0,
    });
  });
});
