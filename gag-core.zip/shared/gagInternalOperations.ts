import { z } from "zod";
import type { KiaExecutionRoute } from "./kiaExecutionRouter";

export const GAG_INTERNAL_OPERATION_REGISTRY = {
  "scanner.document.analyze": {
    id: "scanner.document.analyze",
    label: "Analisar documento com Scanner",
    description: "Processa um ficheiro interno autorizado, preserva proveniência e gera um relatório REVIEW_REQUIRED.",
    capabilityId: "economic.scanner",
    targetTab: "knowledge",
    inputSchema: z.object({
      documentId: z.number().int().positive().optional(),
      question: z.string().min(8).max(1200),
      period: z.string().min(2).max(120),
      geography: z.string().min(2).max(120),
      decisionContext: z.string().min(8).max(1200),
    }),
    authorization: "OWNER_ONLY",
    confirmation: "EXPLICIT",
    auditEvent: "SCANNER_REPORT_CREATED",
    availability: "AVAILABLE",
  },
  "document.analysis": {
    id: "document.analysis",
    label: "Analisar documento interno",
    description: "Extrai e organiza conteúdo de um documento autorizado para revisão humana.",
    capabilityId: "document.intelligence",
    targetTab: "knowledge",
    inputSchema: z.object({ documentId: z.number().int().positive().optional(), objective: z.string().min(3).max(1200) }),
    authorization: "OWNER_ONLY",
    confirmation: "EXPLICIT",
    auditEvent: "DOCUMENT_ANALYSIS_CREATED",
    availability: "AVAILABLE",
  },
  "document.pdf.export": {
    id: "document.pdf.export",
    label: "Exportar relatório PDF aprovado",
    description: "Exporta apenas análises documentais aprovadas, com proveniência e auditoria.",
    capabilityId: "document.export",
    targetTab: "knowledge",
    inputSchema: z.object({ analysisId: z.number().int().positive() }),
    authorization: "OWNER_ONLY",
    confirmation: "APPROVAL_REQUIRED",
    auditEvent: "DOCUMENT_PDF_EXPORTED",
    availability: "AVAILABLE",
  },
  "agent.factory.open": {
    id: "agent.factory.open",
    label: "Gerir Agent Factory",
    description: "Abre o ciclo persistente de especificação, rascunho, teste e aprovação de agentes.",
    capabilityId: "agent.factory",
    targetTab: "agents",
    inputSchema: z.object({}),
    authorization: "OWNER_ONLY",
    confirmation: "APPROVAL_REQUIRED",
    auditEvent: "AGENT_FACTORY_EVENT",
    availability: "AVAILABLE",
  },
  "kernel.task.prepare": {
    id: "kernel.task.prepare",
    label: "Preparar tarefa interna",
    description: "Prepara uma alteração permitida para confirmação assinada pelo Execution Kernel.",
    capabilityId: "kernel.task.prepare",
    targetTab: "tasks",
    inputSchema: z.object({ title: z.string().min(1).max(240), description: z.string().min(1).max(4000) }),
    authorization: "OWNER_ONLY",
    confirmation: "EXPLICIT",
    auditEvent: "KERNEL_PLAN_PREPARED",
    availability: "AVAILABLE",
  },
} as const;

export type GagInternalOperationId = keyof typeof GAG_INTERNAL_OPERATION_REGISTRY;
export type GagInternalOperation = (typeof GAG_INTERNAL_OPERATION_REGISTRY)[GagInternalOperationId];

/** Resolve apenas operações existentes; capacidades ausentes ficam explícitas no router da KIA. */
export function resolveGagInternalOperation(route: Pick<KiaExecutionRoute, "capabilityId">): GagInternalOperation | null {
  const operation = Object.values(GAG_INTERNAL_OPERATION_REGISTRY).find((candidate) => candidate.capabilityId === route.capabilityId);
  return operation ?? null;
}

export const GAG_INTERNAL_OPERATION_SHORTCUTS = [
  GAG_INTERNAL_OPERATION_REGISTRY["scanner.document.analyze"],
  GAG_INTERNAL_OPERATION_REGISTRY["document.analysis"],
  GAG_INTERNAL_OPERATION_REGISTRY["kernel.task.prepare"],
  GAG_INTERNAL_OPERATION_REGISTRY["agent.factory.open"],
] as const;
