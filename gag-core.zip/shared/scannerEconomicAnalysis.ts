import type { DocumentAnalysisResult } from "./documentIntelligence";

export const SCANNER_ECONOMIC_REPORT_STATUS = ["DRAFT", "REVIEW_REQUIRED"] as const;
export type ScannerEconomicReportStatus = (typeof SCANNER_ECONOMIC_REPORT_STATUS)[number];

export type ScannerEconomicScope = {
  question: string;
  period: string;
  geography: string;
  intendedDecision: string;
};

export type ScannerEconomicReportDraft = {
  reportType: "GAG_INTERNAL_ECONOMIC_REVIEW_DRAFT";
  status: "REVIEW_REQUIRED";
  scope: ScannerEconomicScope;
  provenance: {
    documentId: number;
    filename: string;
    contentHash: string;
    sourceOrigin: "OWNER_UPLOAD";
  };
  documentSummary: string;
  confirmedFacts: DocumentAnalysisResult["keyInformation"];
  detectedValues: DocumentAnalysisResult["detectedValues"];
  conditionalConsiderations: string[];
  risks: string[];
  gaps: string[];
  internalOptionsForReview: string[];
  reviewRequired: {
    humanReview: true;
    professionalReview: boolean;
    reasons: string[];
  };
  boundaries: string[];
};

/**
 * Compõe um rascunho interno exclusivamente a partir da análise documental
 * existente. Não calcula indicadores, não recomenda investimentos e não
 * introduz quaisquer factos fora da fonte carregada pelo proprietário.
 */
export function buildScannerEconomicReportDraft(params: {
  scope: ScannerEconomicScope;
  document: { id: number; filename: string; contentHash: string };
  analysis: DocumentAnalysisResult;
}): ScannerEconomicReportDraft {
  const reviewReasons = Array.from(new Set([
    ...params.analysis.reviewReasons,
    "Análise do Scanner limitada a rascunho interno com revisão humana obrigatória.",
  ]));

  return {
    reportType: "GAG_INTERNAL_ECONOMIC_REVIEW_DRAFT",
    status: "REVIEW_REQUIRED",
    scope: params.scope,
    provenance: {
      documentId: params.document.id,
      filename: params.document.filename,
      contentHash: params.document.contentHash,
      sourceOrigin: "OWNER_UPLOAD",
    },
    documentSummary: params.analysis.documentSummary,
    confirmedFacts: params.analysis.keyInformation,
    detectedValues: params.analysis.detectedValues,
    conditionalConsiderations: params.analysis.insights.map((insight) => `Consideração condicional — requer revisão: ${insight}`),
    risks: params.analysis.risks,
    gaps: Array.from(new Set([
      ...params.analysis.missingInformation,
      ...params.analysis.conflictsOrInconsistencies,
    ])),
    internalOptionsForReview: params.analysis.suggestedActions,
    reviewRequired: {
      humanReview: true,
      professionalReview: params.analysis.professionalReviewRequired,
      reasons: reviewReasons,
    },
    boundaries: [
      "Uso exclusivamente interno da GAG.",
      "Não constitui recomendação financeira, fiscal, legal, de investimento ou de pagamento.",
      "Não autoriza publicação, contacto, contratação, transação, integração externa ou ação operacional.",
      "As considerações são condicionais e não substituem a revisão humana das fontes originais.",
    ],
  };
}
