import { describe, expect, it } from "vitest";
import { KIA_PROCEDURE_MAX_BYTES, isKiaProcedureFilenameAllowed, validateKiaProcedure } from "./kiaProcedure";

describe("validação de procedimentos reais da Kia", () => {
  it("aceita apenas formatos pesquisáveis e conteúdo não vazio", () => {
    expect(isKiaProcedureFilenameAllowed("operacao.md")).toBe(true);
    expect(isKiaProcedureFilenameAllowed("operacao.pdf")).toBe(false);
    expect(validateKiaProcedure("operacao.txt", "Passo 1: validar o pedido.")).toEqual({ valid: true });
    expect(validateKiaProcedure("operacao.txt", "   ")).toEqual({ valid: false, message: "O procedimento não pode estar vazio." });
  });

  it("rejeita conteúdo acima do limite operacional", () => {
    const oversized = "a".repeat(KIA_PROCEDURE_MAX_BYTES + 1);
    expect(validateKiaProcedure("operacao.json", oversized)).toEqual({ valid: false, message: "O procedimento deve ter no máximo 700 KB." });
  });
});
