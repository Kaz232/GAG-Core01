export const AGENT_SPEC_FIELD_KEYS = [
  "name",
  "objective",
  "function",
  "tasks",
  "knowledge",
  "tools",
  "permissions",
  "limitations",
  "successCriteria",
  "tests",
] as const;

export type AgentSpecField = (typeof AGENT_SPEC_FIELD_KEYS)[number];

export type AgentSpecification = Record<AgentSpecField, string>;

export type KiaAgentDraft = {
  type: "prepare_agent";
  values: AgentSpecification;
  currentField: AgentSpecField | null;
  stage: "collecting" | "ready";
  requiresExplicitCreationConfirmation: true;
};

export type SpecializedAgentStatus = "Rascunho" | "Em Teste" | "Ativo" | "Rejeitado" | "Inativo";

export const AGENT_AUTONOMY_LEVELS = ["Supervisionado", "Assistido"] as const;
export type AgentAutonomyLevel = (typeof AGENT_AUTONOMY_LEVELS)[number];

export const AGENT_PERMISSION_CAPABILITIES = ["READ", "CREATE", "EDIT", "DELETE"] as const;
export type AgentPermissionCapability = (typeof AGENT_PERMISSION_CAPABILITIES)[number];

export const EXTERNAL_ACTION_CAPABILITIES = ["EXECUTE", "SEND", "PUBLISH"] as const;

export function normalizeSpecializedAgentName(value: string): string {
  return value.trim().replace(/\s+/g, " ").toLocaleLowerCase("pt-PT");
}

export function buildSpecializedAgentSlug(value: string): string {
  return normalizeSpecializedAgentName(value)
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 160);
}

export function isSpecializedAgentNameValid(value: string): boolean {
  const name = value.trim().replace(/\s+/g, " ");
  return name.length > 0 && name.length <= 128 && buildSpecializedAgentSlug(name).length > 0;
}

export function hasSpecializedAgentNameConflict(
  candidate: string,
  existingAgents: readonly { name: string }[],
): boolean {
  const normalizedCandidate = normalizeSpecializedAgentName(candidate);
  return existingAgents.some((agent) => normalizeSpecializedAgentName(agent.name) === normalizedCandidate);
}

export function hasSpecializedAgentSlugConflict(
  candidate: string,
  existingAgents: readonly { name: string; slug?: string | null }[],
): boolean {
  const candidateSlug = buildSpecializedAgentSlug(candidate);
  return existingAgents.some((agent) => (agent.slug ?? buildSpecializedAgentSlug(agent.name)) === candidateSlug);
}

export function findMentionedSpecializedAgent<T extends { name: string }>(
  message: string,
  existingAgents: readonly T[],
): T | null {
  const normalizedMessage = normalizeSpecializedAgentName(message);
  return [...existingAgents]
    .sort((left, right) => normalizeSpecializedAgentName(right.name).length - normalizeSpecializedAgentName(left.name).length)
    .find((agent) => normalizedMessage.includes(normalizeSpecializedAgentName(agent.name))) ?? null;
}

export function normalizeAgentPermissions(values: readonly string[]): AgentPermissionCapability[] {
  return AGENT_PERMISSION_CAPABILITIES.filter((capability) => values.includes(capability));
}

export function areExternalAgentActionsBlocked(values: readonly string[]): boolean {
  return !values.some((value) => EXTERNAL_ACTION_CAPABILITIES.includes(value as (typeof EXTERNAL_ACTION_CAPABILITIES)[number]));
}

export function getIsolatedAgentTestBlock(message: string): string | null {
  const normalized = message.trim().toLocaleLowerCase("pt-PT");
  const requestsExternalAction = /\b(enviar|envia|contactar|contacta|publicar|publica|postar|poste|integrar|integra|executar|executa)\b/.test(normalized)
    && /\b(whatsapp|email|e-mail|cliente|contacto|contato|instagram|facebook|linkedin|tiktok|youtube|api|webhook)\b|\bredes?\s+sociais?\b/.test(normalized);
  const requestsDataMutation = /\b(atualizar|atualiza|alterar|altera|eliminar|elimina|apagar|apaga|remover|remove)\b/.test(normalized)
    && /\b(tarefa|tarefas|backlog|registo|registos|dados|documento|documentos)\b/.test(normalized);

  if (requestsExternalAction) {
    return "Bloqueio: este pedido exige uma ação externa. SEND, PUBLISH e EXECUTE permanecem bloqueadas pela política do Kaz; neste teste isolado não foi enviada mensagem, publicado conteúdo, contactada pessoa nem integrada qualquer ferramenta. Posso apenas preparar uma proposta para revisão humana.";
  }

  if (requestsDataMutation) {
    return "Bloqueio de teste: este pedido alteraria dados operacionais. O ambiente isolado do Kaz não cria, edita nem elimina registos; posso apenas preparar uma proposta sujeita à confirmação humana no GAG Core.";
  }

  return null;
}

export type KazInternalTaskProposal = {
  title: string;
  description: string;
  priority: "Baixa" | "Média" | "Alta" | "Urgente";
};

export function getKazInternalTaskProposal(message: string): KazInternalTaskProposal | null {
  const normalized = message.trim().toLocaleLowerCase("pt-PT");
  if (!/\b(criar|cria|adicionar|adiciona|transformar|transforma)\b/.test(normalized)
    || !/\b(tarefa|tarefas|etapa)\b/.test(normalized)) {
    return null;
  }
  if (/\b(todas|sem me perguntar|automaticamente)\b/.test(normalized)) return null;

  const afterColon = message.split(":").slice(1).join(":").trim().replace(/[.]+$/, "");
  const title = afterColon
    || (/primeira etapa/i.test(message) ? "Definir a primeira etapa do novo projeto" : "Tarefa interna proposta pelo proprietário");
  const priority = /\b(urgente|crítico|critico)\b/i.test(message)
    ? "Urgente"
    : /\b(prioridade alta|alta prioridade)\b/i.test(message)
      ? "Alta"
      : "Média";

  return {
    title,
    description: "Tarefa interna proposta pelo Kaz durante uma validação autorizada. Requer confirmação humana antes de ser registada.",
    priority,
  };
}

export function isKazExplicitTaskConfirmation(message: string): boolean {
  return /^(confirmo|confirmar|confirmo a criação|confirmo a criacao|aprovo a criação|aprovo a criacao)\b/i.test(message.trim());
}

export function isKazActivitySummaryRequest(message: string): boolean {
  return /\b(o que fizeste|resume as ações|resume as acoes|resumo das ações|resumo das acoes)\b/i.test(message.trim().toLocaleLowerCase("pt-PT"));
}

export const AGENT_SPEC_FIELDS: ReadonlyArray<{
  key: AgentSpecField;
  label: string;
  question: string;
}> = [
  { key: "name", label: "Nome", question: "Qual deve ser o nome deste agente especializado?" },
  { key: "objective", label: "Objetivo", question: "Qual é o objetivo concreto deste agente?" },
  { key: "function", label: "Função", question: "Que função deve desempenhar dentro da operação interna da GAG?" },
  { key: "tasks", label: "Tarefas", question: "Quais tarefas específicas deve preparar ou apoiar?" },
  { key: "knowledge", label: "Conhecimento", question: "Que procedimentos ou conhecimento real da GAG este agente pode utilizar?" },
  { key: "tools", label: "Ferramentas", question: "Que ferramentas internas pode utilizar, sem integrações externas nem execução autónoma?" },
  { key: "permissions", label: "Permissões", question: "Que permissões explícitas deve ter?" },
  { key: "limitations", label: "Limitações", question: "Que limites e proibições devem impedir ações não autorizadas?" },
  { key: "successCriteria", label: "Critérios de sucesso", question: "Como vai avaliar que este agente está a cumprir bem a função?" },
  { key: "tests", label: "Testes", question: "Que testes controlados deve passar antes de poder ser aprovado?" },
];

function createEmptySpecification(): AgentSpecification {
  return {
    name: "",
    objective: "",
    function: "",
    tasks: "",
    knowledge: "",
    tools: "",
    permissions: "",
    limitations: "",
    successCriteria: "",
    tests: "",
  };
}

function getFirstMissingField(values: AgentSpecification): AgentSpecField | null {
  return AGENT_SPEC_FIELD_KEYS.find((key) => !values[key].trim()) ?? null;
}

export function createKiaAgentDraft(): KiaAgentDraft {
  const values = createEmptySpecification();
  return {
    type: "prepare_agent",
    values,
    currentField: "name",
    stage: "collecting",
    requiresExplicitCreationConfirmation: true,
  };
}

export function isKiaAgentDraftComplete(draft: KiaAgentDraft): boolean {
  return AGENT_SPEC_FIELD_KEYS.every((key) => draft.values[key].trim().length > 0);
}

export function advanceKiaAgentDraft(draft: KiaAgentDraft, answer: string): KiaAgentDraft {
  if (draft.stage === "ready" || !draft.currentField) return draft;

  const values: AgentSpecification = {
    ...draft.values,
    [draft.currentField]: answer.trim(),
  };
  const currentField = getFirstMissingField(values);

  return {
    ...draft,
    values,
    currentField,
    stage: currentField ? "collecting" : "ready",
  };
}

export function getKiaAgentDraftPrompt(draft: KiaAgentDraft): string {
  if (draft.stage === "ready") {
    return "Recolhi exclusivamente as informações que indicou. A especificação está pronta para revisão visual. Pode editar, aprovar para pedir a confirmação final de criação como RASCUNHO ou cancelar. Nenhum agente será criado sem essa confirmação.";
  }

  const field = AGENT_SPEC_FIELDS.find((item) => item.key === draft.currentField);
  return `Vamos definir este agente passo a passo, sem assumir informações. ${field?.question ?? "Indique o próximo requisito necessário."}`;
}

export function buildAgentInstructions(specification: AgentSpecification): string {
  return AGENT_SPEC_FIELDS
    .filter((field) => field.key !== "name" && field.key !== "objective")
    .map((field) => `${field.label}:\n${specification[field.key].trim()}`)
    .join("\n\n");
}

export function buildAgentSafetyBoundary(autonomyLevel: AgentAutonomyLevel, permissions: readonly AgentPermissionCapability[]): string {
  return [
    `Nível de autonomia: ${autonomyLevel}.`,
    `Permissões internas declaradas: ${permissions.join(", ") || "nenhuma"}.`,
    "Ações externas bloqueadas: EXECUTE, SEND e PUBLISH.",
    "O agente não pode contactar pessoas, publicar, enviar mensagens, integrar serviços externos, alterar dados ou afirmar execução real sem uma aprovação humana específica no fluxo da plataforma.",
  ].join("\n");
}

export function canTransitionSpecializedAgentStatus(
  from: SpecializedAgentStatus,
  to: SpecializedAgentStatus,
): boolean {
  if (from === "Rascunho") return to === "Em Teste" || to === "Rejeitado";
  if (from === "Em Teste") return to === "Ativo" || to === "Rejeitado";
  return false;
}
