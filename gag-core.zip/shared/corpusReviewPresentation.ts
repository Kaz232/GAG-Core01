import { APPROVED_CORPUS_TRANSFORMATION, type CorpusTransformArtifact } from "./approvedCorpusTransformation";

const REVIEW_FOCUS: Record<string, string> = {
  "gag-labs-learning-architecture": "Confirmar objetivo de aprendizagem, público, duração, materiais autorizados, lacunas e requisitos técnicos antes de aprovar.",
  "content-design-and-brand-ai": "Confirmar briefing, fontes de marca autorizadas, direitos do material e limites de produção antes de aprovar.",
  "ai-foundations-prompting": "Preencher objetivo de aprendizagem, contexto, fontes, conceitos, exercício, critérios de verificação e lacunas.",
  "ai-content-production": "Preencher objetivo, público, canal, formato, factos autorizados, estrutura, critérios de qualidade e aprovação necessária.",
  "ai-design": "Preencher objetivo visual, fonte de marca vigente, público, formato, restrições, referências e checklist de aprovação.",
  "ai-video": "Confirmar mensagem, público, duração, idioma, direitos de uso, cenas, restrições e aprovação antes de qualquer produção ou publicação.",
  "brand-project-facilitation": "Definir objetivo, âmbito interno ou de cliente isolado, evidências, fontes de marca, entregáveis, critérios e confirmação humana.",
};

export type PendingCorpusReviewArtifact = CorpusTransformArtifact & {
  reviewFocus: string;
};

export const PENDING_CORPUS_REVIEW_ARTIFACTS: readonly PendingCorpusReviewArtifact[] = APPROVED_CORPUS_TRANSFORMATION
  .filter((artifact) => artifact.status === "REVIEW_REQUIRED" && (artifact.kind === "WORKFLOW" || artifact.kind === "TEMPLATE"))
  .map((artifact) => ({
    ...artifact,
    reviewFocus: REVIEW_FOCUS[artifact.id] ?? "Rever a fonte, os limites operacionais e a aprovação humana antes de oficializar.",
  }));

export function getPendingCorpusReviewSummary() {
  const workflows = PENDING_CORPUS_REVIEW_ARTIFACTS.filter((artifact) => artifact.kind === "WORKFLOW").length;
  const templates = PENDING_CORPUS_REVIEW_ARTIFACTS.filter((artifact) => artifact.kind === "TEMPLATE").length;
  const sourceCount = PENDING_CORPUS_REVIEW_ARTIFACTS.reduce((total, artifact) => total + artifact.sourceCount, 0);

  return { total: PENDING_CORPUS_REVIEW_ARTIFACTS.length, workflows, templates, sourceCount };
}
