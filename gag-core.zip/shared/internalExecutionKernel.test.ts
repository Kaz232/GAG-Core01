import { describe, expect, it } from "vitest";
import {
  INTERNAL_EXECUTION_ACTION_TYPES,
  INTERNAL_EXECUTION_MAX_ACTIONS,
  INTERNAL_EXECUTION_TTL_MS,
  calculateExecutionPlanHash,
  canonicalizeExecutionPayload,
  internalExecutionActionSchema,
  internalExecutionPlanInputSchema,
  isExecutionPlanExpired,
  isInternalExecutionActionAllowed,
  summarizeInternalExecutionAction,
} from "./internalExecutionKernel";

const taskCreatePlan = {
  source: "KIA" as const,
  action: {
    type: "TASK_CREATE" as const,
    brandId: 1,
    title: "Rever operação interna",
    description: "Preparar revisão restrita.",
    priority: "Alta" as const,
    quarter: "Operação atual",
    dueDate: null,
  },
};

describe("Internal Execution Kernel — contrato restrito", () => {
  it("limita a allow-list a duas ações internas", () => {
    expect(INTERNAL_EXECUTION_ACTION_TYPES).toEqual(["TASK_CREATE", "TASK_UPDATE_PRIORITY"]);
    expect(INTERNAL_EXECUTION_MAX_ACTIONS).toBe(1);
  });

  it("aceita apenas uma criação de tarefa interna válida", () => {
    expect(internalExecutionPlanInputSchema.parse(taskCreatePlan)).toEqual(taskCreatePlan);
  });

  it("aceita atualização de prioridade apenas com identificadores positivos", () => {
    expect(internalExecutionActionSchema.parse({ type: "TASK_UPDATE_PRIORITY", brandId: 1, taskId: 9, priority: "Urgente" })).toMatchObject({ taskId: 9, priority: "Urgente" });
  });

  it("rejeita ação externa fora da allow-list", () => {
    expect(() => internalExecutionActionSchema.parse({ type: "SEND_WHATSAPP", brandId: 1, recipient: "x" })).toThrow();
    expect(isInternalExecutionActionAllowed({ type: "SEND_WHATSAPP" })).toBe(false);
  });

  it("rejeita múltiplas ações embrulhadas no mesmo plano", () => {
    expect(() => internalExecutionPlanInputSchema.parse({ source: "KIA", action: [taskCreatePlan.action] })).toThrow();
  });

  it("rejeita fontes que não sejam KIA ou Kaz", () => {
    expect(() => internalExecutionPlanInputSchema.parse({ ...taskCreatePlan, source: "OUTRO" })).toThrow();
  });

  it("normaliza o payload independentemente da ordem das propriedades", () => {
    expect(canonicalizeExecutionPayload({ z: 1, a: { b: 2, a: 3 } })).toBe(canonicalizeExecutionPayload({ a: { a: 3, b: 2 }, z: 1 }));
  });

  it("produz o mesmo hash para o mesmo plano canónico", () => {
    const reordered = { action: { ...taskCreatePlan.action }, source: "KIA" as const };
    expect(calculateExecutionPlanHash(taskCreatePlan)).toBe(calculateExecutionPlanHash(reordered));
  });

  it("altera o hash quando a prioridade do plano muda", () => {
    const changed = { ...taskCreatePlan, action: { ...taskCreatePlan.action, priority: "Urgente" as const } };
    expect(calculateExecutionPlanHash(taskCreatePlan)).not.toBe(calculateExecutionPlanHash(changed));
  });

  it("marca como expirado um plano no instante de expiração", () => {
    const now = new Date("2026-08-19T12:00:00.000Z");
    expect(isExecutionPlanExpired(now, now)).toBe(true);
    expect(isExecutionPlanExpired(new Date(now.getTime() + 1), now)).toBe(false);
  });

  it("fixa uma TTL de dez minutos", () => {
    expect(INTERNAL_EXECUTION_TTL_MS).toBe(600_000);
  });

  it("resume as duas ações sem inventar efeitos externos", () => {
    expect(summarizeInternalExecutionAction(taskCreatePlan.action)).toContain("Criar tarefa interna");
    expect(summarizeInternalExecutionAction({ type: "TASK_UPDATE_PRIORITY", brandId: 1, taskId: 4, priority: "Média" })).toBe("Alterar a prioridade da tarefa #4 para Média.");
  });
});
