export type InternalExecutionAuditEventLike = {
  eventType: string;
  createdAt: Date | string;
  planId: number;
};

export type InternalExecutionAuditDateOrder = "newest" | "oldest";

export function getInternalExecutionEventLabel(eventType: string): string {
  const labels: Record<string, string> = {
    PLAN_PROPOSED: "Plano proposto",
    PLAN_CONFIRMED: "Plano confirmado",
    ACTION_EXECUTED: "Ação interna executada",
    ACTION_FAILED: "Ação interna falhou",
    PLAN_EXPIRED: "Plano expirado",
    PLAN_CANCELLED: "Plano cancelado",
  };
  return labels[eventType] ?? eventType;
}

export function getInternalExecutionEventTagClass(eventType: string): string {
  if (eventType === "ACTION_EXECUTED" || eventType === "PLAN_CONFIRMED") return "border border-emerald-700 bg-emerald-950 text-emerald-200";
  if (eventType === "ACTION_FAILED") return "border border-rose-700 bg-rose-950 text-rose-200";
  if (eventType === "PLAN_EXPIRED" || eventType === "PLAN_CANCELLED") return "border border-slate-600 bg-slate-800 text-slate-300";
  return "border border-amber-700 bg-amber-950 text-amber-200";
}

export function filterAndSortInternalExecutionEvents<T extends InternalExecutionAuditEventLike>(events: T[], search: string, order: InternalExecutionAuditDateOrder): T[] {
  const normalizedSearch = search.trim().toLocaleLowerCase("pt-PT");
  return [...events]
    .filter((event) => !normalizedSearch || `${event.eventType} ${getInternalExecutionEventLabel(event.eventType)} Plano ${event.planId}`.toLocaleLowerCase("pt-PT").includes(normalizedSearch))
    .sort((a, b) => order === "newest"
      ? new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
      : new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime());
}
