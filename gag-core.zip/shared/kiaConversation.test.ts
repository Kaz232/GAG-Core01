import { describe, expect, it } from "vitest";
import { KIA_CONVERSATION_MESSAGE_MAX_LENGTH, KIA_RAG_MEMORY_WINDOW, normalizeKiaConversationEntry, selectKiaRagMemory } from "./kiaConversation";

describe("KIA conversation memory", () => {
  it("removes empty entries and normalizes whitespace without changing the speaker", () => {
    expect(normalizeKiaConversationEntry({ role: "user", content: "  organizar tarefas  " })).toEqual({
      role: "user",
      content: "organizar tarefas",
    });
    expect(normalizeKiaConversationEntry({ role: "assistant", content: "   " })).toBeNull();
  });

  it("keeps only the bounded most recent context for a model request", () => {
    const entries = Array.from({ length: KIA_RAG_MEMORY_WINDOW + 3 }, (_, index) => ({
      role: index % 2 === 0 ? "user" as const : "assistant" as const,
      content: `mensagem ${index + 1}`,
    }));

    const memory = selectKiaRagMemory(entries);
    expect(memory).toHaveLength(KIA_RAG_MEMORY_WINDOW);
    expect(memory[0]?.content).toBe("mensagem 4");
    expect(memory.at(-1)?.content).toBe(`mensagem ${KIA_RAG_MEMORY_WINDOW + 3}`);
  });

  it("limits oversized content before it is persisted or used as context", () => {
    const normalized = normalizeKiaConversationEntry({ role: "assistant", content: "x".repeat(KIA_CONVERSATION_MESSAGE_MAX_LENGTH + 10) });
    expect(normalized?.content).toHaveLength(KIA_CONVERSATION_MESSAGE_MAX_LENGTH);
  });
});
