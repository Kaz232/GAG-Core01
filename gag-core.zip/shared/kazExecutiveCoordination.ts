import { getKazInternalTaskProposal, isKazActivitySummaryRequest, isKazExplicitTaskConfirmation } from "./agentFactoryFlow";

export type KazOperationalTask = {
  id: number;
  title: string;
  status: "Pendente" | "Em Curso" | "Concluído";
  priority: "Baixa" | "Média" | "Alta" | "Urgente";
};

export type KazAuthorizedKnowledge = {
  title: string;
  category: string;
};

export type KazExecutiveDecision = {
  reply: string;
  action?:
    | { type: "TASK_CREATE"; title: string; description: string; priority: "Baixa" | "Média" | "Alta" | "Urgente"; quarter: string }
    | { type: "TASK_UPDATE_PRIORITY"; taskId: number; priority: "Baixa" | "Média" | "Alta" | "Urgente" };
  report?: {
    total: number;
    pending: number;
    inProgress: number;
    completed: number;
    urgent: number;
    approvedKnowledgeCount: number;
  };
};

const PRIORITIES = ["Baixa", "Média", "Alta", "Urgente"] as const;

function detectPriority(message: string): KazOperationalTask["priority"] | null {
  const found = PRIORITIES.find((priority) => new RegExp(`\\b${priority}\\b`, "i").test(message));
  return found ?? null;
}

function taskReport(tasks: KazOperationalTask[], approvedKnowledge: KazAuthorizedKnowledge[]) {
  return {
    total: tasks.length,
    pending: tasks.filter((task) => task.status === "Pendente").length,
    inProgress: tasks.filter((task) => task.status === "Em Curso").length,
    completed: tasks.filter((task) => task.status === "Concluído").length,
    urgent: tasks.filter((task) => task.priority === "Urgente" && task.status !== "Concluído").length,
    approvedKnowledgeCount: approvedKnowledge.length,
  };
}

function getKazPriorityUpdateRequest(message: string, tasks: KazOperationalTask[]) {
  const explicitTaskId = message.match(/#(\d+)\b/);
  const priority = detectPriority(message);
  if (!/\b(altera|alterar|atualiza|atualizar|prioriza|priorizar)\b/i.test(message) || !explicitTaskId || !priority) {
    return null;
  }
  const task = tasks.find((item) => item.id === Number(explicitTaskId[1]));
  return task ? { task, priority } : null;
}

export function isKazExecutiveDelegation(message: string): boolean {
  return /\b(kaz|agente executivo)\b/i.test(message);
}

function withoutKazPrefix(message: string): string {
  return message.replace(/^\s*(kaz|agente executivo)\s*[,:\-]?\s*/i, "");
}

export function resolveKazExecutiveRequest(input: {
  message: string;
  priorOwnerMessages: string[];
  tasks: KazOperationalTask[];
  approvedKnowledge: KazAuthorizedKnowledge[];
  quarter: string;
}): KazExecutiveDecision {
  const { message, priorOwnerMessages, tasks, approvedKnowledge, quarter } = input;
  const command = withoutKazPrefix(message);
  const currentTaskProposal = getKazInternalTaskProposal(command);
  const priorTaskProposal = [...priorOwnerMessages]
    .reverse()
    .map((entry) => getKazInternalTaskProposal(withoutKazPrefix(entry)))
    .find((proposal): proposal is NonNullable<typeof proposal> => Boolean(proposal));
  const priorPriorityUpdate = [...priorOwnerMessages]
    .reverse()
    .map((entry) => getKazPriorityUpdateRequest(withoutKazPrefix(entry), tasks))
    .find((request): request is NonNullable<typeof request> => Boolean(request));

  if (/\b(whatsapp|e-?mail|cliente|contacto|contato|instagram|facebook|linkedin|tiktok|youtube|api|webhook|pagamento|transfer[eê]ncia|transa[cç][aã]o)\b/i.test(command)) {
    return { reply: "KIA → Kaz: bloqueio de segurança. O pedido envolve comunicação, integração, transação ou outro efeito externo. O Kaz não preparou nem executou qualquer ação fora da operação interna GAG." };
  }

  if (isKazActivitySummaryRequest(message) || /\b(relat[oó]rio|estado).*(opera[cç][aã]o|tarefa|backlog|kaz)\b/i.test(message)) {
    const report = taskReport(tasks, approvedKnowledge);
    const next = [...tasks]
      .filter((task) => task.status !== "Concluído")
      .sort((left, right) => (PRIORITIES.indexOf(right.priority) - PRIORITIES.indexOf(left.priority)))[0];
    return {
      report,
      reply: `KIA recebeu o relatório do Kaz. Operação interna: ${report.total} tarefa(s), ${report.pending} pendente(s), ${report.inProgress} em curso, ${report.completed} concluída(s) e ${report.urgent} urgente(s) não concluída(s). Base autorizada consultada: ${report.approvedKnowledgeCount} item(ns). ${next ? `Próxima atenção: “${next.title}” — ${next.priority}.` : "Não há pendências prioritárias."} Nenhuma ação foi executada.`,
    };
  }

  if (/\b(conhecimento|knowledge base|procedimento|skill|workflow|fonte)\b/i.test(message)) {
    const sources = approvedKnowledge.map((item) => `${item.title} (${item.category})`);
    return {
      reply: sources.length
        ? `KIA → Kaz: foram consultadas apenas fontes internas aprovadas: ${sources.join("; ")}. Conteúdos em rascunho, arquivados ou REVIEW_REQUIRED permanecem excluídos. Nenhuma ação foi executada.`
        : "KIA → Kaz: não há conhecimento interno aprovado disponível para esta consulta. Nenhuma informação ambígua foi assumida.",
    };
  }

  if (isKazExplicitTaskConfirmation(command)) {
    if (!priorTaskProposal && !priorPriorityUpdate) {
      return { reply: "KIA → Kaz: não existe uma proposta de tarefa pendente neste contexto. Nenhuma ação foi preparada." };
    }
    if (priorPriorityUpdate) {
      if (priorPriorityUpdate.task.priority === priorPriorityUpdate.priority) {
        return { reply: `KIA → Kaz: “${priorPriorityUpdate.task.title}” já tem prioridade ${priorPriorityUpdate.priority}. Nenhuma alteração foi preparada.` };
      }
      return {
        action: { type: "TASK_UPDATE_PRIORITY", taskId: priorPriorityUpdate.task.id, priority: priorPriorityUpdate.priority },
        reply: `KIA → Kaz: plano interno preparado para alterar “${priorPriorityUpdate.task.title}” para prioridade ${priorPriorityUpdate.priority}. Reveja o plano e confirme uma única vez no Kernel; nenhuma alteração foi executada ainda.`,
      };
    }
    if (!priorTaskProposal) {
      return { reply: "KIA → Kaz: não existe uma proposta de tarefa pendente neste contexto. Nenhuma ação foi preparada." };
    }
    const existing = tasks.find((task) => task.title === priorTaskProposal.title);
    if (!existing) {
      return {
        action: { type: "TASK_CREATE", title: priorTaskProposal.title, description: priorTaskProposal.description, priority: priorTaskProposal.priority, quarter },
        reply: `KIA → Kaz: plano interno preparado para criar “${priorTaskProposal.title}” com prioridade ${priorTaskProposal.priority}. Reveja o plano e confirme uma única vez no Kernel; nenhuma tarefa foi criada ainda.`,
      };
    }
    if (existing.priority === priorTaskProposal.priority) {
      return { reply: `KIA → Kaz: “${existing.title}” já existe com prioridade ${existing.priority}. Não foi preparado um duplicado.` };
    }
    return {
      action: { type: "TASK_UPDATE_PRIORITY", taskId: existing.id, priority: priorTaskProposal.priority },
      reply: `KIA → Kaz: plano interno preparado para alterar “${existing.title}” para prioridade ${priorTaskProposal.priority}. Reveja o plano e confirme uma única vez no Kernel; nenhuma alteração foi executada ainda.`,
    };
  }

  if (currentTaskProposal) {
    return {
      reply: `KIA → Kaz: proposta para revisão humana — título: “${currentTaskProposal.title}”; prioridade: ${currentTaskProposal.priority}; estado inicial: Pendente. Nenhuma tarefa foi criada. Diga “Kaz, confirmo a criação” para preparar o plano auditável.`,
    };
  }

  const explicitTaskId = message.match(/#(\d+)\b/);
  const priorityUpdateRequest = getKazPriorityUpdateRequest(message, tasks);
  if (/\b(altera|alterar|atualiza|atualizar|prioriza|priorizar)\b/i.test(message) && explicitTaskId) {
    const task = tasks.find((item) => item.id === Number(explicitTaskId[1]));
    if (!task) return { reply: `KIA → Kaz: a tarefa #${explicitTaskId[1]} não existe na operação interna. Nenhuma alteração foi preparada.` };
    if (!priorityUpdateRequest) return { reply: `KIA → Kaz: indique a prioridade desejada para a tarefa #${task.id}: Baixa, Média, Alta ou Urgente. Nenhuma alteração foi preparada.` };
    return { reply: `KIA → Kaz: proposta de alteração para “${task.title}” — prioridade ${priorityUpdateRequest.priority}. Diga “Kaz, confirmo a criação” para preparar o plano auditável; nenhuma alteração foi executada.` };
  }

  if (/\b(plano|organiza|organizar|prioriza|priorizar|acompanha|acompanhar|coordena|coordenar|checklist|briefing|pend[eê]ncia)\b/i.test(message)) {
    const report = taskReport(tasks, approvedKnowledge);
    return {
      report,
      reply: `KIA → Kaz: plano interno proposto com base em ${report.total} tarefa(s) reais e ${report.approvedKnowledgeCount} fonte(s) aprovadas: 1) clarificar o resultado; 2) ordenar dependências e urgência; 3) preparar apenas a próxima tarefa; 4) submeter o plano à confirmação no Kernel; 5) acompanhar estado e pendências. Não foram criadas tarefas, alteradas prioridades nem efetuadas ações externas.`,
    };
  }

  return { reply: "KIA → Kaz: indique se pretende plano, relatório, consulta de conhecimento, proposta de tarefa ou alteração de prioridade com o identificador `#ID`. O Kaz não executa ações externas e só prepara tarefas internas após pedido claro." };
}
