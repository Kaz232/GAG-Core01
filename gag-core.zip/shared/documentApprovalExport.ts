export const DOCUMENT_REVIEW_DECISIONS = ["APPROVED", "CHANGES_REQUESTED", "REJECTED"] as const;
export type DocumentReviewDecision = (typeof DOCUMENT_REVIEW_DECISIONS)[number];

export function isDocumentExportAllowed(decision: string | null | undefined): boolean {
  return decision === "APPROVED";
}

export function getDocumentExportBlockReason(decision: string | null | undefined): string | null {
  if (isDocumentExportAllowed(decision)) return null;
  return "A exportação está bloqueada até o proprietário aprovar explicitamente o resultado da análise documental.";
}

export function buildInternalDocumentReport(input: {
  analysisId: number;
  filename: string;
  contentHash: string;
  requestedIntent: string;
  summary: string;
  analysisJson: string;
  approvedAt: Date | null;
  reviewNote: string | null;
}): string {
  let parsed: Record<string, unknown> = {};
  try { parsed = JSON.parse(input.analysisJson) as Record<string, unknown>; } catch { parsed = {}; }
  const list = (value: unknown) => Array.isArray(value) && value.length
    ? value.map((item) => `- ${typeof item === "string" ? item : JSON.stringify(item)}`).join("\n")
    : "- Não registado.";
  return [
    "# Relatório interno — Document Intelligence",
    "",
    `- Análise: #${input.analysisId}`,
    `- Documento: ${input.filename}`,
    `- Hash de proveniência: ${input.contentHash}`,
    `- Objetivo: ${input.requestedIntent}`,
    `- Aprovado em: ${input.approvedAt?.toISOString() ?? "Não registado"}`,
    "",
    "## Resumo", input.summary,
    "",
    "## Factos confirmados", list(parsed.keyInformation),
    "",
    "## Lacunas", list(parsed.missingInformation),
    "",
    "## Motivos de revisão", list(parsed.reviewReasons),
    "",
    "## Decisão humana", input.reviewNote || "Aprovado para exportação interna pelo proprietário.",
    "",
    "> Uso interno. Este relatório não autoriza publicação, envio, contacto externo ou oficialização automática do conteúdo.",
  ].join("\n");
}
