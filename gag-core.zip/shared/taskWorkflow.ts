export const TASK_STATUSES = ["Pendente", "Em Curso", "Concluído"] as const;
export const TASK_PRIORITIES = ["Baixa", "Média", "Alta", "Urgente"] as const;

export type TaskStatus = (typeof TASK_STATUSES)[number];
export type TaskPriority = (typeof TASK_PRIORITIES)[number];

export type OperationalTask = {
  status: TaskStatus;
  priority: TaskPriority;
  dueDate: string | null;
};

const PRIORITY_ORDER: Record<TaskPriority, number> = {
  Urgente: 0,
  Alta: 1,
  Média: 2,
  Baixa: 3,
};

export function filterAndSortOperationalTasks<T extends OperationalTask>(
  tasks: T[],
  status: TaskStatus | "Todas",
  priority: TaskPriority | "Todas",
): T[] {
  return tasks
    .filter((task) => (status === "Todas" || task.status === status) && (priority === "Todas" || task.priority === priority))
    .sort((left, right) => {
      const byPriority = PRIORITY_ORDER[left.priority] - PRIORITY_ORDER[right.priority];
      if (byPriority !== 0) return byPriority;
      const leftDue = left.dueDate ?? "9999-12-31";
      const rightDue = right.dueDate ?? "9999-12-31";
      return leftDue.localeCompare(rightDue);
    });
}
