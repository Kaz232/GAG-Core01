import { describe, expect, it } from "vitest";
import { getAuthorizedAgentBlueprintForMessage, isExplicitAuthorizedDraftCreationCommand } from "./authorizedAgentBlueprints";

describe("especificações autorizadas para Agent Factory", () => {
  const command = "KIA, cria o agente Scanner de Economia Real GAG como DRAFT na Agent Factory. Não o atives.";

  it("resolve apenas a especificação autorizada pelo proprietário", () => {
    const blueprint = getAuthorizedAgentBlueprintForMessage(command);

    expect(blueprint?.id).toBe("gag-real-economy-scanner");
    expect(blueprint?.specification.name).toBe("Scanner de Economia Real GAG");
    expect(blueprint?.permissions).toEqual(["READ"]);
    expect(blueprint?.autonomyLevel).toBe("Assistido");
  });

  it("exige comando explícito de criação em rascunho", () => {
    expect(isExplicitAuthorizedDraftCreationCommand(command)).toBe(true);
    expect(isExplicitAuthorizedDraftCreationCommand("KIA, cria o Scanner de Economia Real GAG.")).toBe(false);
    expect(isExplicitAuthorizedDraftCreationCommand("KIA, não criar o Scanner de Economia Real GAG como DRAFT.")).toBe(false);
  });

  it("não associa nomes de agentes não autorizados a esta especificação", () => {
    expect(getAuthorizedAgentBlueprintForMessage("Cria o agente Consultor GAG como DRAFT.")).toBeNull();
  });
});
