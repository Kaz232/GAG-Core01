export type CorpusTransformStatus =
  | "APPROVED_KNOWLEDGE"
  | "APPROVED_INTERNAL_WORKFLOW"
  | "CANDIDATE_CAPABILITY"
  | "REFERENCE_ONLY"
  | "REVIEW_REQUIRED";

export interface CorpusTransformArtifact {
  id: string;
  kind: "KNOWLEDGE" | "SKILL" | "WORKFLOW" | "TEMPLATE" | "REFERENCE";
  status: CorpusTransformStatus;
  sourceGroup: string;
  sourceCount: number;
  createsAgent: false;
  enablesExternalAction: false;
}

export const APPROVED_CORPUS_TRANSFORMATION: readonly CorpusTransformArtifact[] = [
  {
    id: "gag-institutional-knowledge",
    kind: "KNOWLEDGE",
    status: "APPROVED_KNOWLEDGE",
    sourceGroup: "Operação e identidade institucional da GAG",
    sourceCount: 3,
    createsAgent: false,
    enablesExternalAction: false,
  },
  {
    id: "gag-prompt-engineering",
    kind: "SKILL",
    status: "CANDIDATE_CAPABILITY",
    sourceGroup: "Engenharia de prompts e metodologia de contexto",
    sourceCount: 5,
    createsAgent: false,
    enablesExternalAction: false,
  },
  {
    id: "gag-assisted-knowledge-infographic-scripting",
    kind: "WORKFLOW",
    status: "APPROVED_INTERNAL_WORKFLOW",
    sourceGroup: "Conhecimento assistido, infografia e roteiros",
    sourceCount: 6,
    createsAgent: false,
    enablesExternalAction: false,
  },
  {
    id: "gag-labs-learning-architecture",
    kind: "WORKFLOW",
    status: "REVIEW_REQUIRED",
    sourceGroup: "Arquitetura curricular e formação GAG Labs",
    sourceCount: 2,
    createsAgent: false,
    enablesExternalAction: false,
  },
  {
    id: "content-design-and-brand-ai",
    kind: "WORKFLOW",
    status: "APPROVED_INTERNAL_WORKFLOW",
    sourceGroup: "Produção de conteúdo, design e marca com IA",
    sourceCount: 2,
    createsAgent: false,
    enablesExternalAction: false,
  },
  ...([
    ["ai-foundations-prompting", "Formação IA — fundamentos e prompting (Aula 1)", 12],
    ["ai-content-production", "Formação IA — produção de conteúdo (Aula 2)", 14],
    ["ai-design", "Formação IA — design com IA (Aula 3)", 11],
    ["ai-video", "Formação IA — vídeo com IA (Aula 4)", 11],
    ["brand-project-facilitation", "Formação IA — projeto de marca e facilitação (Aula 5)", 10],
  ] as [string, string, number][]).map(([id, sourceGroup, sourceCount]) => ({
    id,
    kind: "TEMPLATE" as const,
    status: "REVIEW_REQUIRED" as const,
    sourceGroup,
    sourceCount,
    createsAgent: false as const,
    enablesExternalAction: false as const,
  })),
  ...([
    ["external-automation-ecosystems", "Especificações de automação e ecossistemas externos", 12],
    ["business-risk-crm-security", "Análise de negócio, risco, CRM e segurança", 3],
    ["generic-prompts-productivity", "Coleções genéricas de prompts e produtividade", 3],
  ] as [string, string, number][]).map(([id, sourceGroup, sourceCount]) => ({
    id,
    kind: "REFERENCE" as const,
    status: "REFERENCE_ONLY" as const,
    sourceGroup,
    sourceCount,
    createsAgent: false as const,
    enablesExternalAction: false as const,
  })),
];

export function summarizeApprovedCorpusTransformation() {
  return APPROVED_CORPUS_TRANSFORMATION.reduce<Record<CorpusTransformArtifact["kind"], number>>(
    (summary, artifact) => ({ ...summary, [artifact.kind]: summary[artifact.kind] + 1 }),
    { KNOWLEDGE: 0, SKILL: 0, WORKFLOW: 0, TEMPLATE: 0, REFERENCE: 0 },
  );
}

export function hasForbiddenCorpusSideEffect(artifact: CorpusTransformArtifact): boolean {
  return artifact.createsAgent || artifact.enablesExternalAction;
}
