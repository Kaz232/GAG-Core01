export const KIA_EXECUTION_INTENTS = [
  "CONVERSATION",
  "KNOWLEDGE_QUERY",
  "DOCUMENT_INTELLIGENCE",
  "TASKS_BACKLOG",
  "AGENT_FACTORY",
  "INTERNAL_TOOL",
  "TEAM_COLLABORATION",
  "SYSTEM_IMPLEMENTATION",
  "EXTERNAL_ACTION",
] as const;

export type KiaExecutionIntent = (typeof KIA_EXECUTION_INTENTS)[number];
export type KiaCapabilityStatus = "READY" | "CONFIRMATION_REQUIRED" | "NOT_IMPLEMENTED" | "BLOCKED";

export type KiaExecutionRoute = {
  intent: KiaExecutionIntent;
  capabilityId: string;
  capabilityLabel: string;
  status: KiaCapabilityStatus;
  requiresConfirmation: boolean;
  summary: string;
};

export type KiaCapabilityDefinition = {
  id: string;
  label: string;
  status: KiaCapabilityStatus;
  requiresConfirmation: boolean;
  handler: "rag_llm" | "task_preparation" | "agent_factory_ui" | "document_intelligence_ui" | "kernel" | "none";
  inputSchemaId: string;
  authorization: "OWNER_ONLY";
  confirmation: "NONE" | "EXPLICIT" | "APPROVAL_REQUIRED";
  auditEvent: string | null;
};

/** Apenas as capacidades listadas aqui podem ser apresentadas pelo router como existentes. */
export const KIA_CAPABILITY_REGISTRY = {
  "conversation.general": { id: "conversation.general", label: "Conversa e orientação", status: "READY", requiresConfirmation: false, handler: "rag_llm", inputSchemaId: "kia.chat.message.v1", authorization: "OWNER_ONLY", confirmation: "NONE", auditEvent: null },
  "knowledge.query": { id: "knowledge.query", label: "Consulta de conhecimento", status: "READY", requiresConfirmation: false, handler: "rag_llm", inputSchemaId: "kia.knowledge.query.v1", authorization: "OWNER_ONLY", confirmation: "NONE", auditEvent: "KIA_KNOWLEDGE_QUERY" },
  "tasks.backlog.read": { id: "tasks.backlog.read", label: "Consulta de tarefas e backlog", status: "READY", requiresConfirmation: false, handler: "rag_llm", inputSchemaId: "tasks.backlog.read.v1", authorization: "OWNER_ONLY", confirmation: "NONE", auditEvent: "TASK_BACKLOG_READ" },
  "kernel.task.prepare": { id: "kernel.task.prepare", label: "Preparação de tarefa interna", status: "CONFIRMATION_REQUIRED", requiresConfirmation: true, handler: "task_preparation", inputSchemaId: "kernel.task.prepare.v1", authorization: "OWNER_ONLY", confirmation: "EXPLICIT", auditEvent: "KERNEL_PLAN_PREPARED" },
  "agent.factory": { id: "agent.factory", label: "Agent Factory", status: "CONFIRMATION_REQUIRED", requiresConfirmation: true, handler: "agent_factory_ui", inputSchemaId: "agent.factory.specification.v1", authorization: "OWNER_ONLY", confirmation: "APPROVAL_REQUIRED", auditEvent: "AGENT_FACTORY_EVENT" },
  "document.intelligence": { id: "document.intelligence", label: "Document Intelligence", status: "CONFIRMATION_REQUIRED", requiresConfirmation: true, handler: "document_intelligence_ui", inputSchemaId: "document.analysis.request.v1", authorization: "OWNER_ONLY", confirmation: "EXPLICIT", auditEvent: "DOCUMENT_ANALYSIS_CREATED" },
  "document.export": { id: "document.export", label: "Relatório documental em PDF", status: "CONFIRMATION_REQUIRED", requiresConfirmation: true, handler: "document_intelligence_ui", inputSchemaId: "document.export.request.v1", authorization: "OWNER_ONLY", confirmation: "APPROVAL_REQUIRED", auditEvent: "DOCUMENT_PDF_EXPORTED" },
  "economic.scanner": { id: "economic.scanner", label: "Scanner de Economia Real", status: "CONFIRMATION_REQUIRED", requiresConfirmation: true, handler: "document_intelligence_ui", inputSchemaId: "scanner.document.analysis.v1", authorization: "OWNER_ONLY", confirmation: "EXPLICIT", auditEvent: "SCANNER_REPORT_CREATED" },
  "team.collaboration": { id: "team.collaboration", label: "Colaboração de equipa", status: "NOT_IMPLEMENTED", requiresConfirmation: false, handler: "none", inputSchemaId: "team.collaboration.v1", authorization: "OWNER_ONLY", confirmation: "NONE", auditEvent: null },
  "system.implementation": { id: "system.implementation", label: "Implementação do sistema", status: "NOT_IMPLEMENTED", requiresConfirmation: false, handler: "none", inputSchemaId: "system.implementation.v1", authorization: "OWNER_ONLY", confirmation: "NONE", auditEvent: null },
  "external.actions": { id: "external.actions", label: "Ações externas", status: "BLOCKED", requiresConfirmation: false, handler: "none", inputSchemaId: "external.action.v1", authorization: "OWNER_ONLY", confirmation: "NONE", auditEvent: "EXTERNAL_ACTION_BLOCKED" },
} as const satisfies Record<string, KiaCapabilityDefinition>;

const EXTERNAL_ACTION_PATTERN = /\b(enviar|envia|publicar|publica|publicação|publicacao|contactar|contacta|ligar|ligue|whatsapp|e-?mail|email|sms|mensagem\s+(?:ao|à|para)\s+(?:cliente|terceiro)|pagar|pagamento|transferir|transferência|comprar|vender)\b/i;
const AGENT_FACTORY_PATTERN = /\b(agente|agent factory|kaz|consultor gag)\b/i;
const AUTHORIZED_AGENT_BLUEPRINT_PATTERN = /\b(scanner\s+de\s+economia\s+real|gag-real-economy-scanner)\b/i;
const AGENT_CHANGE_PATTERN = /\b(cria|criar|prepara|preparar|edita|editar|ativa|ativar|desativa|desativar|testa|testar|configura|configurar)\b/i;
const DOCUMENT_PATTERN = /\b(documento|ficheiro|arquivo|pdf|fatura|factura|analisar\s+(?:este|um|o)|extrair\s+(?:dados|texto)|digitalizar)\b/i;
const DOCUMENT_OPERATION_PATTERN = /\b(analisa|analisar|extrai|extrair|lê|ler|processa|processar|digitaliza|digitalizar|revê|rever|revisa|revisar|exporta(?:r)?\s+(?:relatório|pdf))\b/i;
const TASK_PATTERN = /\b(tarefa|tarefas|backlog|pendente|pendentes|prioridade|prazo)\b/i;
const TASK_CHANGE_PATTERN = /\b(cria|criar|adiciona|adicionar|regista|registar|prepara|preparar|faz|fazer|marca|marcar|atualiza|atualizar|altera|alterar)\b/i;
const KNOWLEDGE_PATTERN = /\b(knowledge base|base de conhecimento|conhecimento|procedimento|policy|política|referência|referencias)\b/i;
const INTERNAL_TOOL_PATTERN = /\b(gerar\s+(?:relatório|pdf)|exportar\s+(?:relatório|pdf)|scanner|scanear|escanear|upload|carregar\s+(?:ficheiro|documento)|importar)\b/i;
const ECONOMIC_SCANNER_PATTERN = /\b(scanner|scanear|escanear)\b.*\b(economia|mercado|preços|precos|concorrência|concorrencia)\b|\b(economia|mercado|preços|precos|concorrência|concorrencia)\b.*\b(scanner|scanear|escanear)\b/i;
const TEAM_COLLABORATION_PATTERN = /\b(equipa|equipe|colaborador(?:es)?|membro(?:s)?\s+da\s+equipa|atribuir\s+(?:a|para)\s+(?:a\s+)?equipa)\b/i;
const SYSTEM_IMPLEMENTATION_PATTERN = /\b(corrige|corrigir|implementa|implementar|altera\s+(?:o|a)\s+(?:código|codigo|sistema)|deploy|publicar\s+(?:a\s+)?versão|publicar\s+(?:a\s+)?versao|build|testes?\s+(?:do\s+)?sistema|configura\s+(?:o\s+)?sistema)\b/i;

export function getKiaCapability(capabilityId: keyof typeof KIA_CAPABILITY_REGISTRY): KiaCapabilityDefinition {
  return KIA_CAPABILITY_REGISTRY[capabilityId];
}

function route(input: Pick<KiaExecutionRoute, "intent" | "capabilityId" | "summary">): KiaExecutionRoute {
  const capability = getKiaCapability(input.capabilityId as keyof typeof KIA_CAPABILITY_REGISTRY);
  return { ...input, capabilityLabel: capability.label, status: capability.status, requiresConfirmation: capability.requiresConfirmation };
}

/**
 * Classifica um pedido antes da consulta ao modelo. A ordem protege pedidos
 * operacionais de serem confundidos com intenções documentais ou conversação.
 */
export function classifyKiaExecutionIntent(message: string): KiaExecutionRoute {
  const text = message.trim();

  if (EXTERNAL_ACTION_PATTERN.test(text)) {
    return route({
      intent: "EXTERNAL_ACTION",
      capabilityId: "external.actions",
      summary: "Ações externas permanecem bloqueadas no GAG Core.",
    });
  }

  if ((AGENT_FACTORY_PATTERN.test(text) || AUTHORIZED_AGENT_BLUEPRINT_PATTERN.test(text)) && AGENT_CHANGE_PATTERN.test(text)) {
    return route({
      intent: "AGENT_FACTORY",
      capabilityId: "agent.factory",
      summary: "A gestão de agentes exige especificação, revisão e aprovação humana por ciclo de vida.",
    });
  }

  if (SYSTEM_IMPLEMENTATION_PATTERN.test(text)) {
    return route({
      intent: "SYSTEM_IMPLEMENTATION",
      capabilityId: "system.implementation",
      summary: "A KIA não altera código, executa deploy nem configura o sistema a partir do chat.",
    });
  }

  if (INTERNAL_TOOL_PATTERN.test(text)) {
    if (ECONOMIC_SCANNER_PATTERN.test(text)) {
      return route({
        intent: "INTERNAL_TOOL",
        capabilityId: "economic.scanner",
        summary: "O Scanner pode analisar documentos internos autorizados com proveniência e revisão humana; não consulta fontes externas nem executa ações externas.",
      });
    }
    return route({
      intent: "INTERNAL_TOOL",
      capabilityId: "document.export",
      summary: "Relatórios, exportações e carga documental são iniciados apenas na área Document Intelligence e exigem aprovação humana.",
    });
  }

  if (TEAM_COLLABORATION_PATTERN.test(text)) {
    return route({
      intent: "TEAM_COLLABORATION",
      capabilityId: "team.collaboration",
      summary: "A colaboração de equipa não está implementada como capacidade interna do GAG Core.",
    });
  }

  if (DOCUMENT_PATTERN.test(text) && DOCUMENT_OPERATION_PATTERN.test(text)) {
    return route({
      intent: "DOCUMENT_INTELLIGENCE",
      capabilityId: "document.intelligence",
      summary: "A análise documental requer ficheiro selecionado, objetivo explícito e revisão humana.",
    });
  }

  if (TASK_PATTERN.test(text)) {
    const requiresConfirmation = TASK_CHANGE_PATTERN.test(text);
    return route({
      intent: "TASKS_BACKLOG",
      capabilityId: requiresConfirmation ? "kernel.task.prepare" : "tasks.backlog.read",
      summary: requiresConfirmation
        ? "A KIA pode preparar uma ação interna, mas o Kernel exige confirmação humana antes de gravar."
        : "Consulta interna de tarefas e backlog disponível.",
    });
  }

  if (KNOWLEDGE_PATTERN.test(text)) {
    return route({
      intent: "KNOWLEDGE_QUERY",
      capabilityId: "knowledge.query",
      summary: "A KIA responderá apenas com conhecimento carregado e contexto disponível.",
    });
  }

  return route({
    intent: "CONVERSATION",
    capabilityId: "conversation.general",
    summary: "Conversa informativa sem alteração operacional.",
  });
}

export function getKiaExecutionRouteReply(route: KiaExecutionRoute): string | null {
  if (route.intent === "EXTERNAL_ACTION") {
    return "Esse pedido envolve uma ação externa. O GAG Core mantém envios, contactos, publicações, pagamentos e integrações externas bloqueados. Posso apenas ajudar a preparar um rascunho interno para a sua revisão.";
  }

  if (route.intent === "SYSTEM_IMPLEMENTATION") {
    return "A KIA não altera código, executa testes, build, deploy ou configuração do sistema a partir do chat. Essa capacidade não está implementada como ferramenta interna da KIA.";
  }

  if (route.intent === "INTERNAL_TOOL") {
    if (route.capabilityId === "economic.scanner") {
      return "O Scanner de Economia Real pode processar um documento interno autorizado. Abra Knowledge Base > Document Intelligence, escolha o modo Scanner, declare pergunta, período, geografia e decisão interna pretendida, e envie o ficheiro. O resultado ficará em RASCUNHO com proveniência, REVIEW_REQUIRED e sem consulta a fontes externas, recomendação financeira ou ação externa.";
    }
    return "A exportação ou análise documental não é iniciada pelo chat. Abra Knowledge Base > Document Intelligence, selecione o documento e defina o objetivo. A exportação continua limitada a PDF aprovado, com proveniência e auditoria.";
  }

  if (route.intent === "TEAM_COLLABORATION") {
    return "A colaboração de equipa ainda não está implementada no GAG Core. Não vou simular utilizadores, atribuições ou notificações que o sistema não possui.";
  }

  return null;
}
