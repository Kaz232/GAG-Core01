import { describe, expect, it } from "vitest";
import { buildCorpusDecisionNote, getCorpusReviewArtifactsByIds, getEffectiveCorpusReviewDecisions } from "./corpusReviewDecisions";

describe("corpusReviewDecisions", () => {
  it("aceita apenas artefactos que permanecem pendentes na fonte canónica", () => {
    const artifacts = getCorpusReviewArtifactsByIds(["ai-design", "inexistente"]);
    expect(artifacts.map((artifact) => artifact.id)).toEqual(["ai-design"]);
  });

  it("mantém a decisão mais recente por artefacto sem apagar o histórico", () => {
    const effective = getEffectiveCorpusReviewDecisions([
      { id: 1, ownerId: 1, artifactId: "ai-design", decision: "REJECTED", decisionNote: "x", artifactSnapshot: "{}", decidedAt: "2026-08-19T12:00:00.000Z" },
      { id: 2, ownerId: 1, artifactId: "ai-design", decision: "APPROVED", decisionNote: "y", artifactSnapshot: "{}", decidedAt: "2026-08-19T13:00:00.000Z" },
    ]);
    expect(effective["ai-design"]?.decision).toBe("APPROVED");
  });

  it("cria uma nota auditável quando o proprietário não escreve comentário", () => {
    expect(buildCorpusDecisionNote({ artifactIds: ["ai-design"], decision: "APPROVED" })).toContain("Decisão humana confirmada");
  });
});
