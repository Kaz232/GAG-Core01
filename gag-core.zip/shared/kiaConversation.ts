export const KIA_CONVERSATION_HISTORY_LIMIT = 40;
export const KIA_RAG_MEMORY_WINDOW = 12;
export const KIA_CONVERSATION_MESSAGE_MAX_LENGTH = 6000;

export type KiaConversationRole = "user" | "assistant";

export type KiaConversationEntry = {
  role: KiaConversationRole;
  content: string;
};

export function normalizeKiaConversationEntry(entry: KiaConversationEntry): KiaConversationEntry | null {
  const content = entry.content.trim().slice(0, KIA_CONVERSATION_MESSAGE_MAX_LENGTH);
  if (!content) return null;
  return { role: entry.role, content };
}

export function selectKiaRagMemory(entries: KiaConversationEntry[]): KiaConversationEntry[] {
  return entries
    .map(normalizeKiaConversationEntry)
    .filter((entry): entry is KiaConversationEntry => Boolean(entry))
    .slice(-KIA_RAG_MEMORY_WINDOW);
}
