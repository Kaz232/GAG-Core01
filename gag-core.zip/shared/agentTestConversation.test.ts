import { describe, expect, it } from "vitest";
import { AGENT_TEST_HISTORY_LIMIT, AGENT_TEST_MESSAGE_MAX_LENGTH, normalizeAgentTestContent, prepareAgentTestRequest } from "./agentTestConversation";

describe("agent test conversation preparation", () => {
  it("limits a long message and every history entry to the API contract", () => {
    const prepared = prepareAgentTestRequest({
      message: `  ${"m".repeat(AGENT_TEST_MESSAGE_MAX_LENGTH + 40)}  `,
      history: [
        { role: "owner", content: "pedido anterior" },
        { role: "agent", content: "a".repeat(AGENT_TEST_MESSAGE_MAX_LENGTH + 40) },
      ],
    });

    expect(prepared).not.toBeNull();
    expect(prepared?.message).toHaveLength(AGENT_TEST_MESSAGE_MAX_LENGTH);
    expect(prepared?.history[1].content).toHaveLength(AGENT_TEST_MESSAGE_MAX_LENGTH);
    expect(prepared?.wasTruncated).toBe(true);
  });

  it("preserves only the most recent valid history entries", () => {
    const history = Array.from({ length: AGENT_TEST_HISTORY_LIMIT + 3 }, (_, index) => ({
      role: index % 2 === 0 ? "owner" as const : "agent" as const,
      content: `entrada ${index}`,
    }));
    const prepared = prepareAgentTestRequest({ message: "nova instrução", history });

    expect(prepared?.history).toHaveLength(AGENT_TEST_HISTORY_LIMIT);
    expect(prepared?.history[0].content).toBe("entrada 3");
    expect(normalizeAgentTestContent("   ")).toBe("");
  });
});
