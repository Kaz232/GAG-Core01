import { PENDING_CORPUS_REVIEW_ARTIFACTS, type PendingCorpusReviewArtifact } from "./corpusReviewPresentation";

export const CORPUS_REVIEW_DECISIONS = ["APPROVED", "REJECTED"] as const;
export type CorpusReviewDecision = (typeof CORPUS_REVIEW_DECISIONS)[number];

export type CorpusReviewDecisionRecord = {
  id: number;
  ownerId: number;
  artifactId: string;
  decision: CorpusReviewDecision;
  decisionNote: string;
  artifactSnapshot: string;
  decidedAt: Date | string;
};

export type CorpusReviewDecisionInput = {
  artifactIds: string[];
  decision: CorpusReviewDecision;
  decisionNote?: string;
};

export function getCorpusReviewArtifactsByIds(artifactIds: string[]): PendingCorpusReviewArtifact[] {
  const allowed = new Set(artifactIds);
  return PENDING_CORPUS_REVIEW_ARTIFACTS.filter((artifact) => allowed.has(artifact.id));
}

export function getEffectiveCorpusReviewDecisions(records: CorpusReviewDecisionRecord[]) {
  const ordered = [...records].sort((left, right) => {
    const timeDifference = new Date(left.decidedAt).getTime() - new Date(right.decidedAt).getTime();
    return timeDifference || left.id - right.id;
  });

  return ordered.reduce<Record<string, CorpusReviewDecisionRecord>>((effective, record) => {
    effective[record.artifactId] = record;
    return effective;
  }, {});
}

export function buildCorpusDecisionNote(input: CorpusReviewDecisionInput) {
  const trimmed = input.decisionNote?.trim();
  return trimmed || `Decisão humana confirmada no painel interno: ${input.decision === "APPROVED" ? "aprovar" : "rejeitar"} artefacto(s) selecionado(s).`;
}
