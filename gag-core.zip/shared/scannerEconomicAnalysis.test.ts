import { describe, expect, it } from "vitest";
import { buildScannerEconomicReportDraft } from "./scannerEconomicAnalysis";

describe("Scanner de Economia Real — relatório interno", () => {
  it("preserva somente factos e proveniência da análise documental e mantém revisão humana", () => {
    const report = buildScannerEconomicReportDraft({
      scope: {
        question: "Que factos confirmados constam neste documento?",
        period: "Janeiro de 2026",
        geography: "Angola",
        intendedDecision: "Preparar briefing interno para revisão.",
      },
      document: { id: 44, filename: "registo-interno.csv", contentHash: "hash-autorizado" },
      analysis: {
        documentSummary: "O documento identifica um valor e uma data declarados na fonte.",
        documentType: "CSV",
        keyInformation: [{ fact: "O documento contém um registo datado.", sourceReference: "Linha 2" }],
        detectedValues: [{ label: "Valor declarado", value: "100", sourceReference: "Linha 2" }],
        organization: [],
        insights: ["Existe um valor declarado que exige conferência humana."],
        missingInformation: ["Não foi anexada evidência de liquidação."],
        conflictsOrInconsistencies: [],
        risks: ["A fonte precisa de revisão do proprietário."],
        suggestedActions: ["Conferir o original autorizado antes de qualquer decisão."],
        sources: [{ sourceReference: "Linha 2", excerpt: "Registo declarado" }],
        requiresHumanReview: true,
        professionalReviewRequired: true,
        reviewReasons: ["Documento financeiro exige revisão humana."],
      },
    });

    expect(report.status).toBe("REVIEW_REQUIRED");
    expect(report.provenance).toEqual({ documentId: 44, filename: "registo-interno.csv", contentHash: "hash-autorizado", sourceOrigin: "OWNER_UPLOAD" });
    expect(report.confirmedFacts).toHaveLength(1);
    expect(report.reviewRequired.humanReview).toBe(true);
    expect(report.reviewRequired.professionalReview).toBe(true);
    expect(report.boundaries.join(" ")).toMatch(/Não constitui recomendação financeira/);
    expect(report.boundaries.join(" ")).toMatch(/Não autoriza publicação/);
  });
});
