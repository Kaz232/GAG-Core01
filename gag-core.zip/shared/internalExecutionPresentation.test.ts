import { describe, expect, it } from "vitest";
import { filterAndSortInternalExecutionEvents, getInternalExecutionEventLabel, getInternalExecutionEventTagClass } from "./internalExecutionPresentation";

const events = [
  { id: 1, eventType: "PLAN_PROPOSED", planId: 10, createdAt: "2026-08-19T10:00:00.000Z" },
  { id: 2, eventType: "ACTION_EXECUTED", planId: 10, createdAt: "2026-08-19T10:02:00.000Z" },
  { id: 3, eventType: "PLAN_CANCELLED", planId: 11, createdAt: "2026-08-19T10:01:00.000Z" },
];

describe("internal execution audit presentation", () => {
  it("traduz eventos persistidos sem inventar estados", () => {
    expect(getInternalExecutionEventLabel("ACTION_EXECUTED")).toBe("Ação interna executada");
    expect(getInternalExecutionEventLabel("UNKNOWN_EVENT")).toBe("UNKNOWN_EVENT");
  });

  it("usa tags distinguíveis para sucesso, falha e encerramento", () => {
    expect(getInternalExecutionEventTagClass("ACTION_EXECUTED")).toContain("emerald");
    expect(getInternalExecutionEventTagClass("ACTION_FAILED")).toContain("rose");
    expect(getInternalExecutionEventTagClass("PLAN_CANCELLED")).toContain("slate");
  });

  it("filtra por rótulo ou plano e ordena pela data solicitada", () => {
    expect(filterAndSortInternalExecutionEvents(events, "executada", "newest").map((event) => event.id)).toEqual([2]);
    expect(filterAndSortInternalExecutionEvents(events, "plano 10", "oldest").map((event) => event.id)).toEqual([1, 2]);
    expect(filterAndSortInternalExecutionEvents(events, "", "newest").map((event) => event.id)).toEqual([2, 3, 1]);
  });
});
