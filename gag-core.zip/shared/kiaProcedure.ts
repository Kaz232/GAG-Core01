export const KIA_PROCEDURE_MAX_BYTES = 700_000;

export function isKiaProcedureFilenameAllowed(filename: string): boolean {
  return /\.(txt|md|csv|json)$/i.test(filename.trim());
}

export function validateKiaProcedure(filename: string, content: string): { valid: boolean; message?: string } {
  if (!isKiaProcedureFilenameAllowed(filename)) {
    return { valid: false, message: "Carregue um procedimento em TXT, MD, CSV ou JSON." };
  }
  if (!content.trim()) {
    return { valid: false, message: "O procedimento não pode estar vazio." };
  }
  if (new TextEncoder().encode(content).byteLength > KIA_PROCEDURE_MAX_BYTES) {
    return { valid: false, message: "O procedimento deve ter no máximo 700 KB." };
  }
  return { valid: true };
}
