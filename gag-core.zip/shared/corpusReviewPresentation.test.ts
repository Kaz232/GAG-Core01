import { describe, expect, it } from "vitest";
import { APPROVED_CORPUS_TRANSFORMATION } from "./approvedCorpusTransformation";
import { PENDING_CORPUS_REVIEW_ARTIFACTS, getPendingCorpusReviewSummary } from "./corpusReviewPresentation";

describe("corpusReviewPresentation", () => {
  it("apresenta apenas os workflows e templates que aguardam revisão humana", () => {
    const summary = getPendingCorpusReviewSummary();

    expect(summary).toEqual({ total: 6, workflows: 1, templates: 5, sourceCount: 60 });
    expect(PENDING_CORPUS_REVIEW_ARTIFACTS.every((artifact) => artifact.status === "REVIEW_REQUIRED")).toBe(true);
    expect(PENDING_CORPUS_REVIEW_ARTIFACTS.every((artifact) => !artifact.createsAgent && !artifact.enablesExternalAction)).toBe(true);
  });

  it("mantém a aprovação de conteúdo limitada a um workflow interno sem efeitos externos", () => {
    const artifact = APPROVED_CORPUS_TRANSFORMATION.find((item) => item.id === "content-design-and-brand-ai");

    expect(artifact).toMatchObject({
      kind: "WORKFLOW",
      status: "APPROVED_INTERNAL_WORKFLOW",
      createsAgent: false,
      enablesExternalAction: false,
    });
    expect(PENDING_CORPUS_REVIEW_ARTIFACTS.some((item) => item.id === "content-design-and-brand-ai")).toBe(false);
  });

  it("mantém um foco de decisão verificável por artefacto", () => {
    expect(PENDING_CORPUS_REVIEW_ARTIFACTS.every((artifact) => artifact.reviewFocus.length > 40)).toBe(true);
  });
});
