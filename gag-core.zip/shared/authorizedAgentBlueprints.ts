import {
  buildSpecializedAgentSlug,
  normalizeSpecializedAgentName,
  type AgentPermissionCapability,
  type AgentSpecification,
} from "./agentFactoryFlow";

export type AuthorizedAgentBlueprint = {
  id: string;
  source: string;
  specification: AgentSpecification;
  autonomyLevel: "Assistido";
  permissions: AgentPermissionCapability[];
};

/**
 * Especificações autorizadas pelo proprietário que podem ser materializadas
 * pelo chat apenas quando o comando explicita a criação em Rascunho. A fonte
 * preserva o registo original da autorização, sem transformar o agente numa
 * ferramenta implementada ou permitir ativação automática.
 */
export const AUTHORIZED_AGENT_BLUEPRINTS: readonly AuthorizedAgentBlueprint[] = [
  {
    id: "gag-real-economy-scanner",
    source: "Autorização do proprietário no histórico KIA #600001: GAG CORE — CRIAR AGENTE SCANNER DE ECONOMIA REAL GAG V1.",
    autonomyLevel: "Assistido",
    permissions: ["READ"],
    specification: {
      name: "Scanner de Economia Real GAG",
      objective: "Transformar documentos, dados e informações fornecidas pelo utilizador sobre atividades económicas e empresariais em análises estruturadas, verificáveis e úteis para tomada de decisão.",
      function: "Atuar como ferramenta de diagnóstico económico-operacional, e não como simples chatbot, distinguindo sempre facto confirmado, dado fornecido, inferência, estimativa, lacuna e recomendação.",
      tasks: "Preparar diagnósticos, classificações, indicadores, inconsistências, tendências, oportunidades, riscos, comparações, sínteses executivas, recomendações, planos de ação e relatórios auditáveis a partir de informação real fornecida pelo utilizador.",
      knowledge: "Usar somente Knowledge aprovada e relevante; preservar proveniência; não oficializar materiais REVIEW_REQUIRED; registar SKILL GAP quando uma competência necessária não existir.",
      tools: "Usar exclusivamente capacidades internas efetivamente registadas. Quando upload, extração, leitura de ficheiros, geração, exportação, internet ou contas não estiverem implementados, registar GAP ou NOT_IMPLEMENTED sem criar mock nem alegar execução.",
      permissions: "READ. Não pode executar, enviar, publicar, contactar terceiros, aceder a contas externas, movimentar dinheiro, processar pagamentos ou alterar dados operacionais.",
      limitations: "Não inventar dados, não declarar conclusões jurídicas, fraude ou irregularidade como facto, não transformar estimativas em factos e manter ações externas bloqueadas. Informação insuficiente deve ser apresentada como lacuna.",
      successCriteria: "Produzir análise auditável com fontes, factos confirmados, indicadores, descobertas, anomalias, riscos, oportunidades, recomendações, plano de ação, dados em falta, limitações, proveniência e data da análise.",
      tests: "Passar testes controlados que confirmem separação entre factos, inferências, estimativas e lacunas; proveniência; bloqueio de ações externas; ausência de dados inventados; e identificação explícita de capacidades não implementadas.",
    },
  },
] as const;

export function getAuthorizedAgentBlueprintForMessage(message: string): AuthorizedAgentBlueprint | null {
  const normalizedMessage = normalizeSpecializedAgentName(message);
  return AUTHORIZED_AGENT_BLUEPRINTS.find((blueprint) => {
    const name = normalizeSpecializedAgentName(blueprint.specification.name);
    const slug = buildSpecializedAgentSlug(blueprint.specification.name);
    return normalizedMessage.includes(name) || normalizedMessage.includes(slug) || /scanner\s+de\s+economia\s+real/.test(normalizedMessage);
  }) ?? null;
}

export function isExplicitAuthorizedDraftCreationCommand(message: string): boolean {
  const normalizedMessage = normalizeSpecializedAgentName(message);
  const requestsCreation = /\b(cria|criar)\b/.test(normalizedMessage);
  const requestsDraft = /\b(rascunho|draft)\b/.test(normalizedMessage);
  const cancelsCreation = /\b(não criar|nao criar|cancela|cancelar)\b/.test(normalizedMessage);
  return requestsCreation && requestsDraft && !cancelsCreation;
}
