import { describe, expect, it } from "vitest";
import {
  DOCUMENT_INTELLIGENCE_MAX_EXTRACTED_CHARS,
  createSafeFallbackAnalysis,
  detectDocumentType,
  isDocumentAnalysisIntent,
  isDocumentFileAllowed,
  isFinancialOrLegalDocumentIntent,
  normalizeDocumentOperation,
  sanitizeExtractedContent,
  validateDocumentAnalysisResult,
} from "./documentIntelligence";

describe("Document Intelligence — formato, segurança e revisão", () => {
  it("reconhece apenas os formatos documentais autorizados", () => {
    expect(detectDocumentType("contrato.pdf", "application/pdf")).toBe("PDF");
    expect(detectDocumentType("relatorio.docx")).toBe("DOCX");
    expect(detectDocumentType("valores.xlsx")).toBe("XLSX");
    expect(detectDocumentType("foto.png", "image/png")).toBe("IMAGE");
    expect(isDocumentFileAllowed("executavel.exe")).toBe(false);
  });

  it("normaliza pedidos internos sem executar ações externas", () => {
    expect(normalizeDocumentOperation("Extrai os valores desta fatura")).toBe("EXTRACT_VALUES");
    expect(normalizeDocumentOperation("Compara estas versões")).toBe("COMPARE");
    expect(normalizeDocumentOperation("Organiza os pontos principais")).toBe("ORGANIZE");
    expect(isDocumentAnalysisIntent("Analisa este PDF e resume-o")).toBe(true);
  });

  it("exige atenção humana adicional para contexto financeiro ou jurídico", () => {
    expect(isFinancialOrLegalDocumentIntent("Extrai valores desta fatura")).toBe(true);
    expect(isFinancialOrLegalDocumentIntent("Resume a estratégia interna")).toBe(false);
  });

  it("limpa conteúdo extraído e impede que ultrapasse o limite", () => {
    const content = `início\u0000${"a".repeat(DOCUMENT_INTELLIGENCE_MAX_EXTRACTED_CHARS + 100)}`;
    const sanitized = sanitizeExtractedContent(content);
    expect(sanitized).not.toContain("\u0000");
    expect(sanitized.length).toBe(DOCUMENT_INTELLIGENCE_MAX_EXTRACTED_CHARS);
  });

  it("força revisão humana mesmo quando a resposta analítica tenta dispensá-la", () => {
    const result = validateDocumentAnalysisResult({
      documentSummary: "Resumo fundamentado.",
      documentType: "PDF",
      keyInformation: [{ fact: "Valor visível", sourceReference: "página 1" }],
      requiresHumanReview: false,
      reviewReasons: [],
    });
    expect(result.requiresHumanReview).toBe(true);
    expect(result.keyInformation).toEqual([{ fact: "Valor visível", sourceReference: "página 1" }]);
  });

  it("mantém lacuna e revisão quando não existe evidência analisável", () => {
    const fallback = createSafeFallbackAnalysis({ documentType: "PDF", reason: "Fonte ilegível." });
    expect(fallback.requiresHumanReview).toBe(true);
    expect(fallback.missingInformation).toHaveLength(1);
    expect(fallback.reviewReasons).toEqual(["Fonte ilegível."]);
  });
});
