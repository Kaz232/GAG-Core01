import { getKiaCapability, KIA_CAPABILITY_REGISTRY, type KiaExecutionRoute } from "./kiaExecutionRouter";

export const KIA_ORCHESTRATION_STATUSES = [
  "SUCCESS",
  "FAILED",
  "BLOCKED",
  "NOT_IMPLEMENTED",
  "REVIEW_REQUIRED",
] as const;

export type KiaOrchestrationStatus = (typeof KIA_ORCHESTRATION_STATUSES)[number];

export type KiaOperationalOrchestration = {
  intent: KiaExecutionRoute["intent"];
  agentId: number | null;
  skillId: string | null;
  toolId: string | null;
  status: KiaOrchestrationStatus;
  resultCode: string;
  artifactId: number | null;
  exportStatus: "NOT_REQUESTED" | "REVIEW_REQUIRED" | "AVAILABLE" | "NOT_IMPLEMENTED";
};

type ResolveInput = {
  routing: KiaExecutionRoute;
  agentId?: number | null;
  skillId?: string | null;
  toolId?: string | null;
  status?: KiaOrchestrationStatus;
  resultCode?: string;
  artifactId?: number | null;
  exportStatus?: KiaOperationalOrchestration["exportStatus"];
};

/**
 * Produz o envelope factual de uma rota da KIA. Não executa handlers, não usa
 * texto do chat e não resolve qualquer alvo por posição, nome ou histórico.
 */
export function resolveKiaOperationalOrchestration(input: ResolveInput): KiaOperationalOrchestration {
  const { routing } = input;
  const routeStatus: KiaOrchestrationStatus = routing.status === "NOT_IMPLEMENTED"
    ? "NOT_IMPLEMENTED"
    : routing.status === "BLOCKED"
      ? "BLOCKED"
      : routing.requiresConfirmation
        ? "REVIEW_REQUIRED"
        : "SUCCESS";
  const capability = getKiaCapability(routing.capabilityId as keyof typeof KIA_CAPABILITY_REGISTRY);

  return {
    intent: routing.intent,
    agentId: input.agentId ?? null,
    skillId: input.skillId ?? null,
    toolId: input.toolId ?? capability.handler,
    status: input.status ?? routeStatus,
    resultCode: input.resultCode ?? routing.capabilityId,
    artifactId: input.artifactId ?? null,
    exportStatus: input.exportStatus
      ?? (routing.intent === "DOCUMENT_INTELLIGENCE" ? "REVIEW_REQUIRED" : "NOT_REQUESTED"),
  };
}

export function isKiaOrchestrationStatus(value: string): value is KiaOrchestrationStatus {
  return (KIA_ORCHESTRATION_STATUSES as readonly string[]).includes(value);
}
