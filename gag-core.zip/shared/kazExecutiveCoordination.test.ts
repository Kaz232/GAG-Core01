import { describe, expect, it } from "vitest";
import { isKazExecutiveDelegation, resolveKazExecutiveRequest } from "./kazExecutiveCoordination";

const tasks = [
  { id: 17, title: "Teste real do Kernel", status: "Pendente" as const, priority: "Média" as const },
  { id: 18, title: "Rever plano do GAG Core", status: "Em Curso" as const, priority: "Alta" as const },
];
const knowledge = [{ title: "Metodologia operacional GAG", category: "KNOWLEDGE" }];

describe("Kaz Executive Coordination", () => {
  it("só delega pedidos que mencionam explicitamente o Kaz", () => {
    expect(isKazExecutiveDelegation("Cria uma tarefa interna")).toBe(false);
    expect(isKazExecutiveDelegation("Kaz, cria uma tarefa interna")).toBe(true);
  });

  it("mantém a primeira proposta sem execução", () => {
    const result = resolveKazExecutiveRequest({
      message: "Kaz, cria uma tarefa para rever o fluxo interno com prioridade Alta",
      priorOwnerMessages: [], tasks, approvedKnowledge: knowledge, quarter: "Q3 2026",
    });
    expect(result.action).toBeUndefined();
    expect(result.reply).toContain("Nenhuma tarefa foi criada");
  });

  it("prepara uma criação somente após confirmação no contexto", () => {
    const result = resolveKazExecutiveRequest({
      message: "Kaz, confirmo a criação",
      priorOwnerMessages: ["Kaz, cria uma tarefa para rever o fluxo interno com prioridade Alta"],
      tasks, approvedKnowledge: knowledge, quarter: "Q3 2026",
    });
    expect(result.action).toMatchObject({ type: "TASK_CREATE", priority: "Alta" });
    expect(result.reply).toContain("nenhuma tarefa foi criada ainda");
  });

  it("preserva uma atualização de prioridade no contexto até à confirmação", () => {
    const result = resolveKazExecutiveRequest({
      message: "Kaz, confirmo a criação",
      priorOwnerMessages: ["Kaz, atualiza a tarefa #17 para prioridade Urgente"],
      tasks, approvedKnowledge: knowledge, quarter: "Q3 2026",
    });
    expect(result.action).toEqual({ type: "TASK_UPDATE_PRIORITY", taskId: 17, priority: "Urgente" });
  });

  it("consulta apenas as fontes aprovadas fornecidas pelo coordenador", () => {
    const result = resolveKazExecutiveRequest({
      message: "Kaz, mostra o conhecimento autorizado", priorOwnerMessages: [], tasks, approvedKnowledge: knowledge, quarter: "Q3 2026",
    });
    expect(result.reply).toContain("Metodologia operacional GAG");
    expect(result.reply).toContain("REVIEW_REQUIRED permanecem excluídos");
  });

  it("gera um relatório a partir de tarefas reais fornecidas", () => {
    const result = resolveKazExecutiveRequest({
      message: "Kaz, gera um relatório da operação", priorOwnerMessages: [], tasks, approvedKnowledge: knowledge, quarter: "Q3 2026",
    });
    expect(result.report).toEqual({ total: 2, pending: 1, inProgress: 1, completed: 0, urgent: 0, approvedKnowledgeCount: 1 });
    expect(result.reply).toContain("Nenhuma ação foi executada");
  });

  it("bloqueia pedidos externos antes de preparar qualquer plano", () => {
    const result = resolveKazExecutiveRequest({
      message: "Kaz, envia este plano por WhatsApp", priorOwnerMessages: [], tasks, approvedKnowledge: knowledge, quarter: "Q3 2026",
    });
    expect(result.action).toBeUndefined();
    expect(result.reply).toContain("bloqueio de segurança");
  });
});
