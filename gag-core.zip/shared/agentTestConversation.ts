export const AGENT_TEST_MESSAGE_MAX_LENGTH = 6000;
export const AGENT_TEST_HISTORY_LIMIT = 12;

export type AgentTestConversationRole = "owner" | "agent";

export type AgentTestConversationEntry = {
  role: AgentTestConversationRole;
  content: string;
};

export type PreparedAgentTestRequest = {
  message: string;
  history: AgentTestConversationEntry[];
  wasTruncated: boolean;
};

export function normalizeAgentTestContent(content: string): string {
  return content.trim().slice(0, AGENT_TEST_MESSAGE_MAX_LENGTH);
}

export function prepareAgentTestRequest(input: {
  message: string;
  history: AgentTestConversationEntry[];
}): PreparedAgentTestRequest | null {
  const message = normalizeAgentTestContent(input.message);
  if (!message) return null;

  const normalizedHistory = input.history
    .map((entry) => ({ role: entry.role, content: normalizeAgentTestContent(entry.content) }))
    .filter((entry) => Boolean(entry.content))
    .slice(-AGENT_TEST_HISTORY_LIMIT);

  const wasTruncated = input.message.trim().length !== message.length
    || input.history.length !== normalizedHistory.length
    || input.history.some((entry) => entry.content.trim().length !== normalizeAgentTestContent(entry.content).length);

  return { message, history: normalizedHistory, wasTruncated };
}
