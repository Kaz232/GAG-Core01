import { describe, expect, it } from "vitest";
import { classifyKiaExecutionIntent } from "./kiaExecutionRouter";
import {
  isKiaOrchestrationStatus,
  resolveKiaOperationalOrchestration,
} from "./kiaOperationalOrchestrator";

describe("KIA Operational Orchestrator", () => {
  it("resolve análise documental para revisão sem atribuir agente implícito", () => {
    const routing = classifyKiaExecutionIntent("Analisa este documento interno autorizado");
    const result = resolveKiaOperationalOrchestration({ routing });

    expect(result.intent).toBe("DOCUMENT_INTELLIGENCE");
    expect(result.status).toBe("REVIEW_REQUIRED");
    expect(result.agentId).toBeNull();
    expect(result.exportStatus).toBe("REVIEW_REQUIRED");
    expect(result.toolId).toBe("document_intelligence_ui");
  });

  it("preserva apenas o ID de agente fornecido explicitamente", () => {
    const routing = classifyKiaExecutionIntent("Cria uma tarefa interna");
    const result = resolveKiaOperationalOrchestration({
      routing,
      agentId: 60001,
      skillId: "gag-economic-scanner",
    });

    expect(result.agentId).toBe(60001);
    expect(result.skillId).toBe("gag-economic-scanner");
    expect(result.toolId).toBe("task_preparation");
  });

  it("mantém WhatsApp como ação externa bloqueada sem inventar ferramenta", () => {
    const routing = classifyKiaExecutionIntent("Envia esta mensagem por WhatsApp");
    const result = resolveKiaOperationalOrchestration({ routing });

    expect(result.status).toBe("BLOCKED");
    expect(result.toolId).toBeNull();
    expect(result.artifactId).toBeNull();
  });

  it("mantém ações externas bloqueadas com estado objetivo", () => {
    const routing = classifyKiaExecutionIntent("Publica este relatório no Instagram");
    const result = resolveKiaOperationalOrchestration({ routing });

    expect(result.status).toBe("BLOCKED");
    expect(result.resultCode).toBe("external.action.blocked");
  });

  it("é determinístico para pedidos concorrentes e valida apenas estados permitidos", () => {
    const routing = classifyKiaExecutionIntent("Consulta a Knowledge Base");
    const results = Array.from({ length: 3 }, () => resolveKiaOperationalOrchestration({ routing }));

    expect(new Set(results.map((result) => JSON.stringify(result))).size).toBe(1);
    expect(isKiaOrchestrationStatus("SUCCESS")).toBe(true);
    expect(isKiaOrchestrationStatus("UNKNOWN")).toBe(false);
  });
});
