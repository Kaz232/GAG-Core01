export type KnowledgeOrigin = "GAG_INTERNAL" | "CLIENT" | "EXTERNAL_REFERENCE" | "UNKNOWN";

export type KnowledgeMaterialType =
  | "OPERATIONAL_PROCEDURE"
  | "INSTITUTIONAL_DOCUMENT"
  | "METHODOLOGY"
  | "PROMPT"
  | "SKILL_SPECIFICATION"
  | "TOOL_SPECIFICATION"
  | "INVOICE"
  | "OTHER";

export type KnowledgeIntakeDecision =
  | "APPROVED_KNOWLEDGE"
  | "CANDIDATE_REQUIRES_OWNER_APPROVAL"
  | "REFERENCE_ONLY"
  | "QUARANTINE_CLIENT_SCOPE"
  | "QUARANTINE_SENSITIVE_REVIEW"
  | "DUPLICATE_REFERENCE";

export interface KnowledgeIntakeInput {
  origin: KnowledgeOrigin;
  materialType: KnowledgeMaterialType;
  verified: boolean;
  isDuplicateExact?: boolean;
  containsSensitiveFinancialOrLegalData?: boolean;
  hasExplicitOwnerApproval?: boolean;
}

export interface KnowledgeIntakeResult {
  decision: KnowledgeIntakeDecision;
  mayEnterKiaOperationalContext: boolean;
  mayCreateSkillOrTool: boolean;
  reason: string;
}

export function decideKnowledgeIntake(input: KnowledgeIntakeInput): KnowledgeIntakeResult {
  if (input.isDuplicateExact) {
    return {
      decision: "DUPLICATE_REFERENCE",
      mayEnterKiaOperationalContext: false,
      mayCreateSkillOrTool: false,
      reason: "Cópia exata preservada apenas como referência de proveniência.",
    };
  }

  if (input.origin === "CLIENT") {
    return {
      decision: "QUARANTINE_CLIENT_SCOPE",
      mayEnterKiaOperationalContext: false,
      mayCreateSkillOrTool: false,
      reason: "Informação de cliente não entra no núcleo interno da GAG sem espaço isolado e autorização específica.",
    };
  }

  if (input.containsSensitiveFinancialOrLegalData || input.materialType === "INVOICE") {
    return {
      decision: "QUARANTINE_SENSITIVE_REVIEW",
      mayEnterKiaOperationalContext: false,
      mayCreateSkillOrTool: false,
      reason: "Material sensível requer revisão humana; não autoriza decisões, pagamentos ou aconselhamento profissional.",
    };
  }

  if (input.materialType === "PROMPT" || input.materialType === "SKILL_SPECIFICATION" || input.materialType === "TOOL_SPECIFICATION") {
    return {
      decision: input.hasExplicitOwnerApproval ? "CANDIDATE_REQUIRES_OWNER_APPROVAL" : "REFERENCE_ONLY",
      mayEnterKiaOperationalContext: false,
      mayCreateSkillOrTool: false,
      reason: input.hasExplicitOwnerApproval
        ? "Conteúdo preparado como candidato, mas ainda exige especificação, testes e aprovação antes de criar uma capability."
        : "Prompt ou especificação preservado como referência; não cria capability nem concede permissões.",
    };
  }

  if (input.origin === "GAG_INTERNAL" && input.verified) {
    return {
      decision: "APPROVED_KNOWLEDGE",
      mayEnterKiaOperationalContext: true,
      mayCreateSkillOrTool: false,
      reason: "Conhecimento interno verificado pode ser recuperado pela KIA com proveniência registada.",
    };
  }

  return {
    decision: "REFERENCE_ONLY",
    mayEnterKiaOperationalContext: false,
    mayCreateSkillOrTool: false,
    reason: "Origem ou evidência insuficiente para tornar o conteúdo conhecimento operacional da GAG.",
  };
}
