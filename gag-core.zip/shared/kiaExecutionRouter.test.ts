import { describe, expect, it } from "vitest";
import { classifyKiaExecutionIntent, getKiaCapability, getKiaExecutionRouteReply } from "./kiaExecutionRouter";

describe("Execution Router da KIA", () => {
  it("prioriza criação de agente sobre palavras genéricas de configuração", () => {
    const result = classifyKiaExecutionIntent("KIA, cria um agente para relatórios internos");
    expect(result.intent).toBe("AGENT_FACTORY");
    expect(result.status).toBe("CONFIRMATION_REQUIRED");
  });

  it("encaminha o comando abreviado do Scanner autorizado para a Agent Factory, não para ferramenta ausente", () => {
    const result = classifyKiaExecutionIntent("KIA, cria Scanner de Economia Real como DRAFT");
    expect(result.intent).toBe("AGENT_FACTORY");
    expect(result.capabilityId).toBe("agent.factory");
  });

  it("prepara tarefas sem as executar automaticamente", () => {
    const result = classifyKiaExecutionIntent("Cria uma tarefa para rever o backlog amanhã");
    expect(result.intent).toBe("TASKS_BACKLOG");
    expect(result.capabilityId).toBe("kernel.task.prepare");
    expect(result.requiresConfirmation).toBe(true);
  });

  it("mantém consultas de backlog como leitura interna", () => {
    const result = classifyKiaExecutionIntent("Mostra as tarefas pendentes do backlog");
    expect(result.intent).toBe("TASKS_BACKLOG");
    expect(result.status).toBe("READY");
  });

  it("envia análise documental para o módulo documental", () => {
    const result = classifyKiaExecutionIntent("Analisa este PDF e extrai os dados");
    expect(result.intent).toBe("DOCUMENT_INTELLIGENCE");
    expect(result.requiresConfirmation).toBe(true);
  });

  it("não interpreta pedidos de código como conhecimento ou documento", () => {
    const result = classifyKiaExecutionIntent("Corrige o código do sistema e faz deploy");
    expect(result.intent).toBe("SYSTEM_IMPLEMENTATION");
    expect(result.status).toBe("NOT_IMPLEMENTED");
    expect(getKiaExecutionRouteReply(result)).toContain("não altera código");
  });

  it("bloqueia ações externas antes de qualquer outra rota", () => {
    const result = classifyKiaExecutionIntent("Envia um email ao cliente com o relatório");
    expect(result.intent).toBe("EXTERNAL_ACTION");
    expect(result.status).toBe("BLOCKED");
  });

  it("mantém consultas de conhecimento no caminho factual", () => {
    const result = classifyKiaExecutionIntent("O que diz a Knowledge Base sobre procedimentos?");
    expect(result.intent).toBe("KNOWLEDGE_QUERY");
    expect(result.status).toBe("READY");
  });

  it("expõe apenas capacidades registadas e não apresenta colaboração ausente como pronta", () => {
    const documentExport = getKiaCapability("document.export");
    expect(documentExport.handler).toBe("document_intelligence_ui");
    expect(documentExport.authorization).toBe("OWNER_ONLY");
    expect(documentExport.confirmation).toBe("APPROVAL_REQUIRED");
    expect(documentExport.auditEvent).toBe("DOCUMENT_PDF_EXPORTED");
    const result = classifyKiaExecutionIntent("Atribui esta tarefa à equipa");
    expect(result.intent).toBe("TEAM_COLLABORATION");
    expect(result.status).toBe("NOT_IMPLEMENTED");
  });

  it("encaminha o scanner económico para a análise documental interna com revisão humana", () => {
    const result = classifyKiaExecutionIntent("Faz um scanner de economia e mercado");
    expect(result.capabilityId).toBe("economic.scanner");
    expect(result.status).toBe("CONFIRMATION_REQUIRED");
    expect(getKiaExecutionRouteReply(result)).toContain("documento interno autorizado");
  });
});
