import { describe, expect, it } from "vitest";
import { classifyKiaExecutionIntent, getKiaCapability } from "./kiaExecutionRouter";
import { GAG_INTERNAL_OPERATION_REGISTRY, resolveGagInternalOperation } from "./gagInternalOperations";

describe("Registo de operações internas da GAG", () => {
  it("expõe o Scanner apenas como operação interna com confirmação explícita", () => {
    const operation = GAG_INTERNAL_OPERATION_REGISTRY["scanner.document.analyze"];

    expect(operation.authorization).toBe("OWNER_ONLY");
    expect(operation.confirmation).toBe("EXPLICIT");
    expect(operation.auditEvent).toBe("SCANNER_REPORT_CREATED");
    expect(operation.targetTab).toBe("knowledge");
  });

  it("resolve a rota documental do Scanner para um fluxo existente", () => {
    const route = classifyKiaExecutionIntent("Faz um scanner de economia e mercado");
    const operation = resolveGagInternalOperation(route);

    expect(route.capabilityId).toBe("economic.scanner");
    expect(operation?.id).toBe("scanner.document.analyze");
  });

  it("documenta schema, autorização, confirmação e auditoria em cada capacidade pronta", () => {
    const capability = getKiaCapability("economic.scanner");

    expect(capability.inputSchemaId).toBe("scanner.document.analysis.v1");
    expect(capability.authorization).toBe("OWNER_ONLY");
    expect(capability.confirmation).toBe("EXPLICIT");
    expect(capability.auditEvent).toBe("SCANNER_REPORT_CREATED");
  });

  it("não cria atalho de operação para capacidade ausente", () => {
    const route = classifyKiaExecutionIntent("Atribui esta tarefa à equipa");

    expect(route.status).toBe("NOT_IMPLEMENTED");
    expect(resolveGagInternalOperation(route)).toBeNull();
  });
});
