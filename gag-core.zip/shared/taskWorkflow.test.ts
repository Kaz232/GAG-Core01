import { describe, expect, it } from "vitest";
import { filterAndSortOperationalTasks } from "./taskWorkflow";

describe("operational task workflow", () => {
  const tasks = [
    { id: 1, status: "Pendente" as const, priority: "Média" as const, dueDate: "2026-09-10" },
    { id: 2, status: "Em Curso" as const, priority: "Urgente" as const, dueDate: null },
    { id: 3, status: "Pendente" as const, priority: "Alta" as const, dueDate: "2026-09-02" },
  ];

  it("filters tasks by the explicitly selected lifecycle state", () => {
    expect(filterAndSortOperationalTasks(tasks, "Pendente", "Todas").map((task) => task.id)).toEqual([3, 1]);
  });

  it("prioritizes urgent work and then uses the actual due date", () => {
    expect(filterAndSortOperationalTasks(tasks, "Todas", "Todas").map((task) => task.id)).toEqual([2, 3, 1]);
  });
});
