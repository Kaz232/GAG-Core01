import { describe, expect, it } from "vitest";
import {
  AGENT_SPEC_FIELDS,
  advanceKiaAgentDraft,
  areExternalAgentActionsBlocked,
  buildSpecializedAgentSlug,
  buildAgentInstructions,
  buildAgentSafetyBoundary,
  canTransitionSpecializedAgentStatus,
  createKiaAgentDraft,
  findMentionedSpecializedAgent,
  getKazInternalTaskProposal,
  getIsolatedAgentTestBlock,
  getKiaAgentDraftPrompt,
  hasSpecializedAgentNameConflict,
  hasSpecializedAgentSlugConflict,
  isKiaAgentDraftComplete,
  isKazActivitySummaryRequest,
  isKazExplicitTaskConfirmation,
  isSpecializedAgentNameValid,
  normalizeSpecializedAgentName,
  normalizeAgentPermissions,
} from "./agentFactoryFlow";

describe("fluxo controlado da Agent Factory", () => {
  it("recolhe os dez requisitos sem inventar o primeiro agente", () => {
    let draft = createKiaAgentDraft();
    expect(draft.values.name).toBe("");
    expect(getKiaAgentDraftPrompt(draft)).toContain("nome");

    for (const field of AGENT_SPEC_FIELDS) {
      draft = advanceKiaAgentDraft(draft, `Resposta do proprietário para ${field.label}`);
    }

    expect(isKiaAgentDraftComplete(draft)).toBe(true);
    expect(draft.stage).toBe("ready");
    expect(getKiaAgentDraftPrompt(draft)).toContain("Nenhum agente será criado");
  });

  it("guarda as instruções com os requisitos fornecidos pelo proprietário", () => {
    let draft = createKiaAgentDraft();
    for (const field of AGENT_SPEC_FIELDS) {
      draft = advanceKiaAgentDraft(draft, `${field.label} confirmado`);
    }

    const instructions = buildAgentInstructions(draft.values);
    expect(instructions).toContain("Função:\nFunção confirmado");
    expect(instructions).toContain("Limitações:\nLimitações confirmado");
    expect(instructions).not.toContain("Nome:");
  });

  it("impede a passagem automática de rascunho para ativo", () => {
    expect(canTransitionSpecializedAgentStatus("Rascunho", "Ativo")).toBe(false);
    expect(canTransitionSpecializedAgentStatus("Rascunho", "Em Teste")).toBe(true);
    expect(canTransitionSpecializedAgentStatus("Em Teste", "Ativo")).toBe(true);
    expect(canTransitionSpecializedAgentStatus("Ativo", "Rascunho")).toBe(false);
  });

  it("mantém permissões estruturadas internas e bloqueia capacidades externas", () => {
    expect(normalizeAgentPermissions(["READ", "SEND", "EDIT", "UNKNOWN"])).toEqual(["READ", "EDIT"]);
    expect(areExternalAgentActionsBlocked(["READ", "CREATE"])).toBe(true);
    expect(areExternalAgentActionsBlocked(["READ", "PUBLISH"])).toBe(false);
    expect(buildAgentSafetyBoundary("Assistido", ["READ", "CREATE"])).toContain("Ações externas bloqueadas");
  });

  it("permite vários agentes com nomes distintos e bloqueia apenas nomes repetidos", () => {
    const existingAgents = [{ name: "Kaz" }, { name: "Consultor GAG" }];

    expect(normalizeSpecializedAgentName("  CONSULTOR   GAG ")).toBe("consultor gag");
    expect(hasSpecializedAgentNameConflict("consultor gag", existingAgents)).toBe(true);
    expect(hasSpecializedAgentNameConflict("Analista GAG", existingAgents)).toBe(false);
  });

  it("mantém a Factory multiagente para terceiro e quarto agentes com IDs, slugs e ciclos independentes", () => {
    const agents = [
      { id: 1, name: "Kaz", slug: "kaz", status: "Ativo" },
      { id: 2, name: "Consultor GAG", slug: "consultor-gag", status: "Rascunho" },
      { id: 3, name: "Analista de Processos", slug: "analista-de-processos", status: "Em Teste" },
      { id: 4, name: "Coordenador de Backlog", slug: "coordenador-de-backlog", status: "Rascunho" },
    ];

    expect(new Set(agents.map((agent) => agent.id)).size).toBe(4);
    expect(new Set(agents.map((agent) => agent.slug)).size).toBe(4);
    expect(buildSpecializedAgentSlug("  Analista de Processos  ")).toBe("analista-de-processos");
    expect(isSpecializedAgentNameValid("###")).toBe(false);
    expect(isSpecializedAgentNameValid("Coordenador de Backlog")).toBe(true);
    expect(hasSpecializedAgentSlugConflict("Analista de Processos", agents)).toBe(true);
    expect(hasSpecializedAgentSlugConflict("Novo Agente", agents)).toBe(false);
    expect(canTransitionSpecializedAgentStatus("Rascunho", "Em Teste")).toBe(true);
    expect(canTransitionSpecializedAgentStatus("Em Teste", "Ativo")).toBe(true);
    expect(canTransitionSpecializedAgentStatus("Rascunho", "Ativo")).toBe(false);
  });

  it("reconhece no pedido um agente persistido sem iniciar um rascunho duplicado", () => {
    const existingAgents = [
      { name: "Kaz", status: "Ativo" },
      { name: "Consultor GAG", status: "Rascunho" },
    ];

    expect(findMentionedSpecializedAgent("Cria o Consultor GAG", existingAgents)).toEqual(existingAgents[1]);
    expect(findMentionedSpecializedAgent("Mostra o KAZ", existingAgents)).toEqual(existingAgents[0]);
    expect(findMentionedSpecializedAgent("Cria um Analista de Processos", existingAgents)).toBeNull();
  });

  it("recusa deterministamente ações externas e alterações de dados durante o teste isolado", () => {
    expect(getIsolatedAgentTestBlock("Envia uma mensagem ao cliente por WhatsApp")).toContain("ação externa");
    expect(getIsolatedAgentTestBlock("Publica este anúncio no LinkedIn")).toContain("SEND, PUBLISH e EXECUTE");
    expect(getIsolatedAgentTestBlock("Publica este anúncio nas redes sociais da GAG")).toContain("SEND, PUBLISH e EXECUTE");
    expect(getIsolatedAgentTestBlock("Elimina as tarefas antigas do backlog")).toContain("alteraria dados operacionais");
    expect(getIsolatedAgentTestBlock("Prepara uma proposta de prioridades para revisão")).toBeNull();
  });

  it("prepara uma tarefa interna e exige confirmação explícita antes do registo", () => {
    expect(getKazInternalTaskProposal("Cria uma tarefa interna: Rever plano do GAG Core.")).toMatchObject({
      title: "Rever plano do GAG Core",
      priority: "Média",
    });
    expect(isKazExplicitTaskConfirmation("Confirmo a criação")).toBe(true);
    expect(isKazExplicitTaskConfirmation("cria agora")).toBe(false);
  });

  it("reconhece pedidos de resumo sem os tratar como ações operacionais", () => {
    expect(isKazActivitySummaryRequest("O que fizeste nesta conversa?")).toBe(true);
    expect(isKazActivitySummaryRequest("Publica a campanha")).toBe(false);
  });
});
