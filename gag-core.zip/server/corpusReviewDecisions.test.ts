import { describe, expect, it } from "vitest";
import { getEffectiveCorpusReviewDecisions, type CorpusReviewDecisionRecord } from "../shared/corpusReviewDecisions";

describe("corpus review decision persistence contract", () => {
  it("preserva a auditoria e expõe somente a última decisão como estado efetivo", () => {
    const history: CorpusReviewDecisionRecord[] = [
      { id: 11, ownerId: 1, artifactId: "ai-video", decision: "REJECTED", decisionNote: "Rever direitos.", artifactSnapshot: "{}", decidedAt: "2026-08-19T10:00:00.000Z" },
      { id: 12, ownerId: 1, artifactId: "ai-video", decision: "APPROVED", decisionNote: "Direitos confirmados.", artifactSnapshot: "{}", decidedAt: "2026-08-19T11:00:00.000Z" },
    ];
    expect(getEffectiveCorpusReviewDecisions(history)["ai-video"]?.id).toBe(12);
    expect(history).toHaveLength(2);
  });
});

