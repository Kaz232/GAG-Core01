import { describe, expect, it } from "vitest";
import { buildKiaSystemPrompt, detectAgentFactoryIntent, detectKiaLanguage, detectKiaTaskIntent, isKiaBacklogQuery, isKiaTaskCancellation, KIA_AGENT_FACTORY_ENABLED, refineKiaTaskDraft } from "./gagMasterCore";

describe("KIA Core Knowledge", () => {
  it("mantém identidade e capacidades quando não existe Knowledge Base externa", () => {
    const prompt = buildKiaSystemPrompt("");

    expect(prompt).toContain("És a KIA");
    expect(prompt).toContain("Knowledge Intelligent Agent");
    expect(prompt).toContain("pronúncia natural é “Kia”");
    expect(prompt).toContain("Nenhum documento externo foi carregado");
    expect(prompt).toContain("explicar as tuas próprias capacidades");
  });

  it("mantém factos externos como contexto adicional e não como origem exclusiva da inteligência", () => {
    const prompt = buildKiaSystemPrompt("[Título: Procedimento]\nValidar antes de enviar.");

    expect(prompt).toContain("CONHECIMENTO EXTERNO CARREGADO");
    expect(prompt).toContain("Validar antes de enviar.");
    expect(prompt).toContain("A tua inteligência geral permite responder");
  });

  it("mantém o contexto operacional separado da Knowledge Base externa", () => {
    const prompt = buildKiaSystemPrompt("", "[Tarefa #2 | Estado: Pendente]\nRever projeto");

    expect(prompt).toContain("CONTEXTO OPERACIONAL TEMPORÁRIO");
    expect(prompt).toContain("Rever projeto");
    expect(prompt).toContain("Nenhum documento externo foi carregado");
  });

  it("identifica um pedido de agente sem inventar nome, função, ferramentas ou conhecimento", () => {
    const intent = detectAgentFactoryIntent("Cria um agente especializado em vendas.");

    expect(intent).toMatchObject({
      type: "open_agent_factory",
    });
    expect(intent).not.toHaveProperty("name");
    expect(intent).not.toHaveProperty("objective");
    expect(KIA_AGENT_FACTORY_ENABLED).toBe(true);
  });

  it("distingue a criação autorizada em rascunho de pedidos que ainda exigem recolha de requisitos", () => {
    const prompt = buildKiaSystemPrompt("");

    expect(prompt).toContain("comando explícito do proprietário pode criar diretamente como RASCUNHO");
    expect(prompt).toContain("especificação autorizada e rastreável");
    expect(prompt).toContain("Cada agente exige testes e aprovação próprios para ativação");
  });

  it("prepara uma tarefa em linguagem natural e exige confirmação antes de gravar", () => {
    const draft = detectKiaTaskIntent("KIA, cria uma tarefa para eu rever o projeto amanhã.");

    expect(draft).toMatchObject({
      type: "prepare_task",
      title: "Rever o projeto",
      periodLabel: "amanhã",
      requiresConfirmation: true,
    });
  });

  it("deteta português, inglês e francês sem exigir comandos técnicos", () => {
    expect(detectKiaLanguage("Quero organizar as minhas tarefas.")).toBe("pt-PT");
    expect(detectKiaLanguage("Please organize my tasks for tomorrow.")).toBe("en-US");
    expect(detectKiaLanguage("Bonjour, crée une tâche pour demain.")).toBe("fr-FR");
  });

  it("prepara uma tarefa a partir de linguagem natural e refina hora e prioridade", () => {
    const draft = detectKiaTaskIntent("Faz uma tarefa com isto amanhã às 15 para preparar proposta");
    expect(draft?.timeLabel).toBe("15:00");
    const refined = refineKiaTaskDraft(draft!, "Não, às 16 e prioridade alta.");
    expect(refined.timeLabel).toBe("16:00");
    expect(refined.priority).toBe("Alta");
  });

  it("reconhece cancelamento explícito de uma alteração pendente", () => {
    expect(isKiaTaskCancellation("Cancela essa tarefa")).toBe(true);
    expect(isKiaTaskCancellation("Não, deixa isso para depois")).toBe(false);
  });

  it("não prepara alterações quando o pedido não envolve criação de tarefa", () => {
    expect(detectKiaTaskIntent("KIA, organiza as minhas tarefas.")).toBeNull();
  });

  it("identifica consultas naturais ao backlog sem criar ou alterar tarefas", () => {
    expect(isKiaBacklogQuery("KIA, o que tenho pendente?")).toBe(true);
    expect(isKiaBacklogQuery("KIA, organiza as minhas tarefas.")).toBe(true);
    expect(isKiaBacklogQuery("KIA, cria uma tarefa para amanhã.")).toBe(false);
  });

  it("orienta a apresentação natural e a equivalência de significado entre texto e voz", () => {
    const prompt = buildKiaSystemPrompt("");

    expect(prompt).toContain("apresenta-te de forma breve e natural");
    expect(prompt).toContain("mesmo significado");
  });
});
