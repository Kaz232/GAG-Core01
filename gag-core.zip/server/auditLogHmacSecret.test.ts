import { createHmac } from "node:crypto";
import { describe, expect, it } from "vitest";
import { ENV } from "./_core/env";

describe("AUDIT_LOG_HMAC_KEY", () => {
  it("está disponível apenas no ambiente de servidor e sela uma mensagem de teste", () => {
    expect(ENV.auditLogHmacKey.length).toBeGreaterThanOrEqual(64);

    const seal = createHmac("sha256", ENV.auditLogHmacKey)
      .update("gag-core-internal-execution-kernel-healthcheck")
      .digest("hex");

    expect(seal).toHaveLength(64);
  });
});

describe("INTERNAL_EXECUTION_KERNEL_ENABLED", () => {
  it("é lida exclusivamente pelo ambiente de servidor para permitir o Kernel", () => {
    expect(ENV.internalExecutionKernelEnabled).toBe(true);
  });
});
