import { describe, expect, it } from "vitest";
import { buildInternalDocumentPdfCover, createInternalDocumentReportPdf, GAG_VISUAL_SEAL_STORAGE_KEY } from "./documentReportPdf";

const metadata = {
  filename: "manual-identidade-gag.pdf",
  contentHash: "sha256:abc123",
  approvalStatus: "APPROVED" as const,
  approvedAt: new Date("2026-08-19T10:30:00.000Z"),
  reviewNote: "Aprovação apenas para consulta interna.",
  requestedIntent: "Organizar para revisão interna.",
  analysisId: 42,
  reviewerName: "Proprietário GAG",
};

describe("createInternalDocumentReportPdf", () => {
  it("gera um PDF binário a partir de um relatório interno aprovado", async () => {
    const pdf = await createInternalDocumentReportPdf("Relatório interno aprovado. Uso exclusivamente interno.", metadata);
    expect(pdf.subarray(0, 4).toString()).toBe("%PDF");
    expect(pdf.length).toBeGreaterThan(1_000);
  });

  it("inclui todos os campos auditáveis exigidos na capa", () => {
    const cover = buildInternalDocumentPdfCover(metadata).join("\n");
    expect(cover).toContain("RELATÓRIO INTERNO APROVADO");
    expect(cover).toContain(metadata.filename);
    expect(cover).toContain(metadata.contentHash);
    expect(cover).toContain("APPROVED");
    expect(cover).toContain("2026-08-19T10:30:00.000Z");
    expect(cover).toContain(metadata.reviewerName);
    expect(cover).toContain("42");
    expect(cover).toContain("GAG Visual");
    expect(GAG_VISUAL_SEAL_STORAGE_KEY).toBe("GAG_Visual_Selo_Marca_Dagua_7807a718.png");
  });
});
