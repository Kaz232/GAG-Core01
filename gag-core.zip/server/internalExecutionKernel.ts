import { createHash, createHmac, randomUUID } from "node:crypto";
import { and, desc, eq } from "drizzle-orm";
import { brands, internalExecutionActions, internalExecutionEvents, internalExecutionPlans, tasks } from "../drizzle/schema";
import { ENV } from "./_core/env";
import { getDb } from "./db";
import {
  calculateExecutionPlanHash,
  canonicalizeExecutionPayload,
  internalExecutionPlanInputSchema,
  isExecutionPlanExpired,
  type InternalExecutionAction,
  type InternalExecutionPlanInput,
} from "../shared/internalExecutionKernel";

const GENESIS_HASH = "0".repeat(64);

export class InternalExecutionKernelError extends Error {}

function assertKernelEnabled(): void {
  if (!ENV.internalExecutionKernelEnabled || ENV.auditLogHmacKey.length < 64) {
    throw new InternalExecutionKernelError("O Internal Execution Kernel permanece bloqueado: a feature flag ou o selo de auditoria seguro não está disponível.");
  }
}

function signAuditEvent(serializedEvent: string): string {
  return createHmac("sha256", ENV.auditLogHmacKey).update(serializedEvent).digest("hex");
}

function hashAuditEvent(previousHash: string, serializedEvent: string): string {
  return createHash("sha256").update(`${previousHash}:${serializedEvent}`).digest("hex");
}

async function appendAuditEvent(
  tx: any,
  ownerId: number,
  planId: number,
  eventType: string,
  payload: Record<string, unknown>,
  actionId?: number,
) {
  if (!tx) throw new InternalExecutionKernelError("A base de dados interna não está disponível.");
  const [previous] = await tx.select({ eventHash: internalExecutionEvents.eventHash })
    .from(internalExecutionEvents)
    .where(eq(internalExecutionEvents.ownerId, ownerId))
    .orderBy(desc(internalExecutionEvents.id))
    .limit(1);
  const previousHash = previous?.eventHash ?? GENESIS_HASH;
  const payloadJson = canonicalizeExecutionPayload(payload);
  const eventData = canonicalizeExecutionPayload({ ownerId, planId, actionId: actionId ?? null, eventType, payloadJson, previousHash });
  const eventHash = hashAuditEvent(previousHash, eventData);
  const hmac = signAuditEvent(`${previousHash}:${eventHash}:${eventData}`);
  await tx.insert(internalExecutionEvents).values({
    ownerId,
    planId,
    actionId: actionId ?? null,
    eventType,
    payloadJson,
    previousHash,
    eventHash,
    hmac,
  });
  return { previousHash, eventHash, hmac };
}

async function requireInternalBrand(tx: any, brandId: number) {
  if (!tx) throw new InternalExecutionKernelError("A base de dados interna não está disponível.");
  const [brand] = await tx.select().from(brands).where(and(eq(brands.id, brandId), eq(brands.entityType, "internal_operation"))).limit(1);
  if (!brand) throw new InternalExecutionKernelError("A execução foi bloqueada: apenas a operação interna da GAG é elegível.");
  return brand;
}

export async function createInternalExecutionPlan(ownerId: number, input: InternalExecutionPlanInput) {
  assertKernelEnabled();
  const normalized = internalExecutionPlanInputSchema.parse(input);
  const db = await getDb();
  if (!db) throw new InternalExecutionKernelError("A base de dados interna não está disponível.");
  await requireInternalBrand(db, normalized.action.brandId);
  const now = new Date();
  const expiresAt = new Date(now.getTime() + 10 * 60 * 1000);
  const planHash = calculateExecutionPlanHash(normalized);
  const confirmationNonce = randomUUID();
  const planJson = canonicalizeExecutionPayload(normalized);
  const [created] = await db.insert(internalExecutionPlans).values({
    ownerId,
    brandId: normalized.action.brandId,
    source: normalized.source,
    actionType: normalized.action.type,
    planJson,
    planHash,
    confirmationNonce,
    expiresAt,
  });
  const planId = Number(created.insertId);
  await appendAuditEvent(db, ownerId, planId, "PLAN_PROPOSED", { source: normalized.source, action: normalized.action, planHash });
  return { id: planId, planHash, confirmationNonce, status: "PROPOSED" as const, expiresAt, source: normalized.source, action: normalized.action };
}

function parseStoredPlan(planJson: string): InternalExecutionPlanInput {
  return internalExecutionPlanInputSchema.parse(JSON.parse(planJson));
}

async function runInternalAction(tx: any, action: InternalExecutionAction) {
  if (!tx) throw new InternalExecutionKernelError("A base de dados interna não está disponível.");
  await requireInternalBrand(tx, action.brandId);
  if (action.type === "TASK_CREATE") {
    const [created] = await tx.insert(tasks).values({
      brandId: action.brandId,
      title: action.title,
      description: action.description || null,
      status: "Pendente",
      priority: action.priority,
      quarter: action.quarter,
      dueDate: action.dueDate ?? null,
    });
    return { taskId: Number(created.insertId), operation: "TASK_CREATE" as const };
  }
  const [task] = await tx.select().from(tasks).where(and(eq(tasks.id, action.taskId), eq(tasks.brandId, action.brandId))).limit(1);
  if (!task) throw new InternalExecutionKernelError("A alteração foi bloqueada: a tarefa interna indicada não existe.");
  await tx.update(tasks).set({ priority: action.priority }).where(eq(tasks.id, task.id));
  return { taskId: task.id, operation: "TASK_UPDATE_PRIORITY" as const };
}

export async function confirmAndExecuteInternalPlan(ownerId: number, planId: number, planHash: string, confirmationNonce: string) {
  assertKernelEnabled();
  const db = await getDb();
  if (!db) throw new InternalExecutionKernelError("A base de dados interna não está disponível.");
  return db.transaction(async (tx) => {
    const [plan] = await tx.select().from(internalExecutionPlans)
      .where(and(eq(internalExecutionPlans.id, planId), eq(internalExecutionPlans.ownerId, ownerId)))
      .limit(1);
    if (!plan) throw new InternalExecutionKernelError("O plano interno não foi encontrado para este proprietário.");
    if (plan.planHash !== planHash || plan.confirmationNonce !== confirmationNonce) {
      throw new InternalExecutionKernelError("A confirmação foi bloqueada: o plano, o resumo ou o nonce já não correspondem ao rascunho apresentado.");
    }
    if (plan.status === "EXECUTED") {
      const [action] = await tx.select().from(internalExecutionActions).where(eq(internalExecutionActions.planId, plan.id)).limit(1);
      return { alreadyExecuted: true, planId: plan.id, result: action?.resultJson ? JSON.parse(action.resultJson) : null };
    }
    if (plan.status !== "PROPOSED") throw new InternalExecutionKernelError(`O plano não pode ser confirmado no estado ${plan.status}.`);
    if (isExecutionPlanExpired(plan.expiresAt)) {
      await tx.update(internalExecutionPlans).set({ status: "EXPIRED" }).where(eq(internalExecutionPlans.id, plan.id));
      await appendAuditEvent(tx, ownerId, plan.id, "PLAN_EXPIRED", { planHash: plan.planHash });
      throw new InternalExecutionKernelError("O plano expirou após 10 minutos. Prepare uma nova proposta antes de confirmar.");
    }
    const parsed = parseStoredPlan(plan.planJson);
    if (calculateExecutionPlanHash(parsed) !== plan.planHash) {
      throw new InternalExecutionKernelError("O plano armazenado falhou a verificação de integridade e não foi executado.");
    }
    await tx.update(internalExecutionPlans).set({ status: "CONFIRMED", confirmedAt: new Date() }).where(eq(internalExecutionPlans.id, plan.id));
    await appendAuditEvent(tx, ownerId, plan.id, "PLAN_CONFIRMED", { planHash: plan.planHash });
    const [actionCreated] = await tx.insert(internalExecutionActions).values({ planId: plan.id, actionType: parsed.action.type, actionJson: canonicalizeExecutionPayload(parsed.action), status: "PENDING", startedAt: new Date() });
    const actionId = Number(actionCreated.insertId);
    try {
      const result = await runInternalAction(tx, parsed.action);
      const resultJson = canonicalizeExecutionPayload(result);
      await tx.update(internalExecutionActions).set({ status: "EXECUTED", resultJson, completedAt: new Date() }).where(eq(internalExecutionActions.id, actionId));
      await tx.update(internalExecutionPlans).set({ status: "EXECUTED", executedAt: new Date() }).where(eq(internalExecutionPlans.id, plan.id));
      await appendAuditEvent(tx, ownerId, plan.id, "ACTION_EXECUTED", { planHash: plan.planHash, result }, actionId);
      return { alreadyExecuted: false, planId: plan.id, result };
    } catch (error) {
      const message = error instanceof Error ? error.message : "Falha interna não identificada.";
      await tx.update(internalExecutionActions).set({ status: "FAILED", resultJson: canonicalizeExecutionPayload({ error: message }), completedAt: new Date() }).where(eq(internalExecutionActions.id, actionId));
      await tx.update(internalExecutionPlans).set({ status: "FAILED" }).where(eq(internalExecutionPlans.id, plan.id));
      await appendAuditEvent(tx, ownerId, plan.id, "ACTION_FAILED", { planHash: plan.planHash, message }, actionId);
      throw error;
    }
  });
}

export async function cancelInternalExecutionPlan(ownerId: number, planId: number) {
  assertKernelEnabled();
  const db = await getDb();
  if (!db) throw new InternalExecutionKernelError("A base de dados interna não está disponível.");
  const [plan] = await db.select().from(internalExecutionPlans).where(and(eq(internalExecutionPlans.id, planId), eq(internalExecutionPlans.ownerId, ownerId))).limit(1);
  if (!plan) throw new InternalExecutionKernelError("O plano interno não foi encontrado para este proprietário.");
  if (plan.status !== "PROPOSED") throw new InternalExecutionKernelError(`O plano não pode ser cancelado no estado ${plan.status}.`);
  await db.transaction(async (tx) => {
    await tx.update(internalExecutionPlans).set({ status: "CANCELLED" }).where(eq(internalExecutionPlans.id, planId));
    await appendAuditEvent(tx, ownerId, planId, "PLAN_CANCELLED", { planHash: plan.planHash });
  });
  return { success: true };
}

export async function listInternalExecutionTimeline(ownerId: number) {
  const db = await getDb();
  if (!db) throw new InternalExecutionKernelError("A base de dados interna não está disponível.");
  const plans = await db.select().from(internalExecutionPlans).where(eq(internalExecutionPlans.ownerId, ownerId)).orderBy(desc(internalExecutionPlans.id));
  const events = await db.select().from(internalExecutionEvents).where(eq(internalExecutionEvents.ownerId, ownerId)).orderBy(desc(internalExecutionEvents.id)).limit(50);
  return { plans, events };
}

export async function verifyInternalExecutionAuditChain(ownerId: number) {
  assertKernelEnabled();
  const db = await getDb();
  if (!db) throw new InternalExecutionKernelError("A base de dados interna não está disponível.");
  const events = await db.select().from(internalExecutionEvents).where(eq(internalExecutionEvents.ownerId, ownerId)).orderBy(internalExecutionEvents.id);
  let previousHash = GENESIS_HASH;
  for (const event of events) {
    const eventData = canonicalizeExecutionPayload({ ownerId: event.ownerId, planId: event.planId, actionId: event.actionId ?? null, eventType: event.eventType, payloadJson: event.payloadJson, previousHash: event.previousHash });
    const eventHash = hashAuditEvent(previousHash, eventData);
    const hmac = signAuditEvent(`${previousHash}:${eventHash}:${eventData}`);
    if (event.previousHash !== previousHash || event.eventHash !== eventHash || event.hmac !== hmac) {
      return { valid: false, checkedEvents: events.length, invalidEventId: event.id };
    }
    previousHash = event.eventHash;
  }
  return { valid: true, checkedEvents: events.length, invalidEventId: null };
}
