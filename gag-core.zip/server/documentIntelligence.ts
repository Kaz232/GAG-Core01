import crypto from "node:crypto";
import mammoth from "mammoth";
import * as XLSX from "xlsx";
import { invokeLLM } from "./_core/llm";
import { storageGetSignedUrl, storagePut } from "./storage";
import { DOCUMENT_INTELLIGENCE_MAX_BYTES, createSafeFallbackAnalysis, detectDocumentType, isFinancialOrLegalDocumentIntent, sanitizeExtractedContent, validateDocumentAnalysisResult, type DocumentAnalysisResult, type DocumentOperation } from "../shared/documentIntelligence";

type UploadedDocument = {
  filename: string;
  mimeType: string;
  base64: string;
  ownerId: number;
};

export async function storeDocumentUpload(input: UploadedDocument) {
  const buffer = Buffer.from(input.base64, "base64");
  if (!buffer.length || buffer.length > DOCUMENT_INTELLIGENCE_MAX_BYTES) {
    throw new Error("O documento deve ter conteúdo e no máximo 6 MB.");
  }
  const safeName = input.filename.replace(/[^a-zA-Z0-9._-]/g, "_").slice(-180) || "documento";
  const storageId = crypto.randomUUID();
  const stored = await storagePut(`gag-core/${input.ownerId}/documents/${storageId}-${safeName}`, buffer, input.mimeType);
  return {
    buffer,
    storageKey: stored.key,
    storageUrl: stored.url,
    contentHash: crypto.createHash("sha256").update(buffer).digest("hex"),
    documentType: detectDocumentType(input.filename, input.mimeType),
  };
}

export async function extractDocumentText(params: { buffer: Buffer; documentType: ReturnType<typeof detectDocumentType> }): Promise<string> {
  if (params.documentType === "TEXT" || params.documentType === "CSV") {
    return sanitizeExtractedContent(params.buffer.toString("utf8"));
  }
  if (params.documentType === "DOCX") {
    const extracted = await mammoth.extractRawText({ buffer: params.buffer });
    return sanitizeExtractedContent(extracted.value);
  }
  if (params.documentType === "XLSX") {
    const workbook = XLSX.read(params.buffer, { type: "buffer", cellDates: true });
    const sheets = workbook.SheetNames.map((name) => {
      const sheet = workbook.Sheets[name];
      return `FOLHA: ${name}\n${XLSX.utils.sheet_to_csv(sheet, { blankrows: false }).slice(0, 12_000)}`;
    });
    return sanitizeExtractedContent(sheets.join("\n\n"));
  }
  return "";
}

function analysisInstruction(params: { filename: string; documentType: string; intent: string; extractedText: string; professionalReviewRequired: boolean }) {
  return `És a camada de análise documental interna do GAG Core. Analisa apenas o documento fornecido; nunca inventes conteúdo, valores, páginas, pessoas, números ou contexto. A tua saída é um rascunho interno e nunca uma ação externa.

DOCUMENTO: ${params.filename}
TIPO: ${params.documentType}
OBJETIVO DO PROPRIETÁRIO: ${params.intent}
REGRAS: separa factos confirmados de inferências; aponta lacunas e conflitos; cada facto ou valor deve ter sourceReference; mantém requiresHumanReview como true; não aproves, publiques, envies, contactes, nem recomendes decisões legais, financeiras ou fiscais. ${params.professionalReviewRequired ? "Este pedido é financeiro, fiscal, legal ou contratual: professionalReviewRequired deve ser true." : ""}

TEXTO EXTRAÍDO, QUANDO DISPONÍVEL:
${params.extractedText || "A análise deve usar o ficheiro multimodal anexado. Se não houver evidência legível, indica lacuna."}

Responde somente JSON com estas chaves: documentSummary, documentType, keyInformation [{fact,sourceReference}], detectedValues [{label,value,sourceReference}], organization [{section,content,sourceReference}], insights, missingInformation, conflictsOrInconsistencies, risks, suggestedActions, sources [{sourceReference,excerpt}], requiresHumanReview, professionalReviewRequired, reviewReasons.`;
}

export async function analyzeStoredDocument(params: {
  filename: string;
  mimeType: string;
  storageKey: string;
  documentType: ReturnType<typeof detectDocumentType>;
  extractedText: string;
  intent: string;
  operation: DocumentOperation;
}): Promise<DocumentAnalysisResult> {
  const professionalReviewRequired = isFinancialOrLegalDocumentIntent(params.intent);
  const prompt = analysisInstruction({ ...params, professionalReviewRequired });
  try {
    const content: Array<{ type: "text"; text: string } | { type: "file_url"; file_url: { url: string; mime_type: "application/pdf" } } | { type: "image_url"; image_url: { url: string; detail: "auto" } }> = [{ type: "text", text: prompt }];
    if (params.documentType === "PDF") {
      content.push({ type: "file_url", file_url: { url: await storageGetSignedUrl(params.storageKey), mime_type: "application/pdf" } });
    }
    if (params.documentType === "IMAGE") {
      content.push({ type: "image_url", image_url: { url: await storageGetSignedUrl(params.storageKey), detail: "auto" } });
    }
    const response = await invokeLLM({
      messages: [{ role: "system", content: "Produz análises documentais internas estritamente fundamentadas e em JSON." }, { role: "user", content }],
      response_format: { type: "json_object" },
      max_tokens: 2_400,
    });
    const raw = response.choices[0]?.message?.content;
    const text = typeof raw === "string" ? raw : "";
    const parsed = JSON.parse(text);
    const result = validateDocumentAnalysisResult(parsed);
    result.professionalReviewRequired = result.professionalReviewRequired || professionalReviewRequired;
    if (result.reviewReasons.length === 0) result.reviewReasons = ["Resultado preparado para revisão humana obrigatória."];
    return result;
  } catch (error) {
    return createSafeFallbackAnalysis({
      documentType: params.documentType,
      reason: error instanceof Error ? `Falha de análise: ${error.message}` : "Falha de análise não especificada.",
      professionalReviewRequired,
    });
  }
}
