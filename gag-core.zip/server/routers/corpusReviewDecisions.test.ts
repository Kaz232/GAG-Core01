import { describe, expect, it } from "vitest";
import { buildCorpusDecisionNote, getCorpusReviewArtifactsByIds } from "../../shared/corpusReviewDecisions";

describe("corpus review decision API contract", () => {
  it("recusa implicitamente artefactos que não fazem parte da lista pendente", () => {
    const selection = getCorpusReviewArtifactsByIds(["gag-labs-learning-architecture", "agente-inexistente"]);
    expect(selection).toHaveLength(1);
    expect(selection[0]?.id).toBe("gag-labs-learning-architecture");
  });

  it("mantém a nota de decisão explícita e auditável", () => {
    expect(buildCorpusDecisionNote({ artifactIds: ["ai-design"], decision: "REJECTED", decisionNote: "Faltam referências de marca vigentes." }))
      .toBe("Faltam referências de marca vigentes.");
  });
});

