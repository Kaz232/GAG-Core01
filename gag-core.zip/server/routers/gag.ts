import { and, eq } from "drizzle-orm";
import { getDb, dbAppendAgentFactoryAuditEvent, dbAppendCorpusReviewDecisions, dbAppendKiaConversation, dbAppendKiaOrchestrationAuditEvent, dbClearKiaConversation, dbGetAllBrands, dbGetAgents, dbGetApprovedInternalKnowledge, dbGetCalendar, dbGetCorpusReviewDecisions, dbGetDocumentAnalyses, dbGetDocumentRecords, dbGetKiaConversation, dbGetKnowledge, dbGetLeads, dbGetTasks, dbGetTemplates } from "../db";
import { brands, calendarEvents, documentAnalyses, documentAnalysisExports, documentRecords, kiaApproval, knowledgeItems, leads, messageTemplates, scannerEconomicAuditEvents, scannerEconomicReports, specializedAgents, tasks } from "../../drizzle/schema";
import { protectedProcedure, router } from "../_core/trpc";
import { TRPCError } from "@trpc/server";
import { invokeLLM } from "../_core/llm";
import { z } from "zod";
import { buildKiaSystemPrompt, detectAgentFactoryIntent, detectKiaLanguage, detectKiaTaskIntent, isKiaBacklogQuery, isKiaTaskCancellation, refineKiaTaskDraft } from "../gagMasterCore";
import { storagePut } from "../storage";
import { isKiaApprovalEligible, type KiaApprovalCriteria } from "../../shared/kiaApproval";
import { validateKiaProcedure } from "../../shared/kiaProcedure";
import { AGENT_AUTONOMY_LEVELS, AGENT_PERMISSION_CAPABILITIES, areExternalAgentActionsBlocked, buildAgentInstructions, buildAgentSafetyBoundary, buildSpecializedAgentSlug, canTransitionSpecializedAgentStatus, findMentionedSpecializedAgent, getIsolatedAgentTestBlock, getKazInternalTaskProposal, hasSpecializedAgentSlugConflict, isKazActivitySummaryRequest, isKazExplicitTaskConfirmation, isSpecializedAgentNameValid, normalizeAgentPermissions, type AgentAutonomyLevel, type AgentSpecification, type SpecializedAgentStatus } from "../../shared/agentFactoryFlow";
import { AGENT_TEST_MESSAGE_MAX_LENGTH, normalizeAgentTestContent } from "../../shared/agentTestConversation";
import { selectKiaRagMemory } from "../../shared/kiaConversation";
import { analyzeStoredDocument, extractDocumentText, storeDocumentUpload } from "../documentIntelligence";
import { isDocumentAnalysisIntent, isDocumentFileAllowed, normalizeDocumentOperation } from "../../shared/documentIntelligence";
import { buildInternalDocumentReport, DOCUMENT_REVIEW_DECISIONS, getDocumentExportBlockReason, isDocumentExportAllowed } from "../../shared/documentApprovalExport";
import { createInternalDocumentReportPdf } from "../documentReportPdf";
import { InternalExecutionKernelError, cancelInternalExecutionPlan, confirmAndExecuteInternalPlan, createInternalExecutionPlan, listInternalExecutionTimeline, verifyInternalExecutionAuditChain } from "../internalExecutionKernel";
import { isKazExecutiveDelegation, resolveKazExecutiveRequest } from "../../shared/kazExecutiveCoordination";
import { buildCorpusDecisionNote, CORPUS_REVIEW_DECISIONS, getCorpusReviewArtifactsByIds } from "../../shared/corpusReviewDecisions";
import { classifyKiaExecutionIntent, getKiaExecutionRouteReply } from "../../shared/kiaExecutionRouter";
import { getAuthorizedAgentBlueprintForMessage, isExplicitAuthorizedDraftCreationCommand } from "../../shared/authorizedAgentBlueprints";
import { buildScannerEconomicReportDraft } from "../../shared/scannerEconomicAnalysis";
import { resolveKiaOperationalOrchestration, type KiaOrchestrationStatus } from "../../shared/kiaOperationalOrchestrator";

// Controlo estrito de proprietário: apenas admin ou owner autorizado
const ownerOnlyProcedure = protectedProcedure.use(({ ctx, next }) => {
  const isOwner = ctx.user.role === 'admin' || ctx.user.openId === process.env.OWNER_OPEN_ID || ctx.user.id === 1;
  if (!isOwner) {
    throw new TRPCError({ code: "FORBIDDEN", message: "Acesso restrito ao proprietário da plataforma GAG Core." });
  }
  return next({ ctx });
});

const DEFAULT_KIA_APPROVAL: KiaApprovalCriteria = {
  textValidated: false,
  voiceValidated: false,
  contextValidated: false,
  safetyConfirmed: false,
};

function toKiaApprovalCriteria(record: typeof kiaApproval.$inferSelect | undefined): KiaApprovalCriteria {
  if (!record) return DEFAULT_KIA_APPROVAL;
  return {
    textValidated: Boolean(record.textValidated),
    voiceValidated: Boolean(record.voiceValidated),
    contextValidated: Boolean(record.contextValidated),
    safetyConfirmed: Boolean(record.safetyConfirmed),
  };
}

async function insertSpecializedAgentDraft({
  db,
  specification,
  autonomyLevel,
  permissions: rawPermissions,
  source,
}: {
  db: NonNullable<Awaited<ReturnType<typeof getDb>>>;
  specification: AgentSpecification;
  autonomyLevel: AgentAutonomyLevel;
  permissions: readonly string[];
  source?: string;
}) {
  const existingAgents = await dbGetAgents();
  if (!isSpecializedAgentNameValid(specification.name)) {
    throw new TRPCError({ code: "BAD_REQUEST", message: "O nome do agente é inválido. Use um nome legível com letras ou números." });
  }
  if (hasSpecializedAgentSlugConflict(specification.name, existingAgents)) {
    throw new TRPCError({ code: "CONFLICT", message: "Já existe um agente com este slug. Use um nome distinto ou reveja o agente já registado." });
  }
  const permissions = normalizeAgentPermissions(rawPermissions);
  if (permissions.length !== rawPermissions.length || !areExternalAgentActionsBlocked(rawPermissions)) {
    throw new TRPCError({ code: "BAD_REQUEST", message: "A Agent Factory aceita apenas permissões internas. EXECUTE, SEND e PUBLISH permanecem bloqueadas." });
  }
  const name = specification.name.trim().replace(/\s+/g, " ");
  const slug = buildSpecializedAgentSlug(name);
  const persistedSpecification = source
    ? JSON.stringify({ ...specification, provenance: source })
    : JSON.stringify(specification);

  await db.insert(specializedAgents).values({
    name,
    slug,
    objective: specification.objective.trim(),
    instructions: `${buildAgentInstructions(specification)}\n\n${buildAgentSafetyBoundary(autonomyLevel, permissions)}`,
    specification: persistedSpecification,
    autonomyLevel,
    permissionSet: JSON.stringify(permissions),
    externalActionPolicy: "Bloqueadas",
    status: "Rascunho",
  });

  const [agent] = await db.select().from(specializedAgents).where(eq(specializedAgents.slug, slug)).limit(1);
  if (!agent) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "O rascunho foi gravado, mas não pôde ser confirmado." });
  return agent;
}

export const gagRouter = router({
  getDashboardStats: ownerOnlyProcedure.query(async () => {
    const allBrands = await dbGetAllBrands();
    const allTasks = await dbGetTasks();
    const allLeads = await dbGetLeads();
    const allKnowledge = await dbGetKnowledge();
    const allAgents = await dbGetAgents();

    return {
      brandsCount: allBrands.length,
      tasksCount: allTasks.length,
      pendingTasksCount: allTasks.filter(t => t.status === "Pendente").length,
      inProgressTasksCount: allTasks.filter(t => t.status === "Em Curso").length,
      completedTasksCount: allTasks.filter(t => t.status === "Concluído").length,
      urgentTasksCount: allTasks.filter(t => t.priority === "Urgente" && t.status !== "Concluído").length,
      leadsCount: allLeads.length,
      knowledgeCount: allKnowledge.length,
      agentsCount: allAgents.length,
      draftAgentsCount: allAgents.filter(agent => agent.status === "Rascunho").length,
      testAgentsCount: allAgents.filter(agent => agent.status === "Em Teste").length,
      activeAgentsCount: allAgents.filter(agent => agent.status === "Ativo").length,
      brands: allBrands,
    };
  }),

  // Brands
  listBrands: ownerOnlyProcedure.query(async () => {
    return await dbGetAllBrands();
  }),

  listCorpusReviewDecisions: ownerOnlyProcedure.query(async ({ ctx }) => {
    return await dbGetCorpusReviewDecisions(ctx.user.id);
  }),

  decideCorpusReviewArtifacts: ownerOnlyProcedure.input(z.object({
    artifactIds: z.array(z.string().min(1).max(128)).min(1).max(7),
    decision: z.enum(CORPUS_REVIEW_DECISIONS),
    decisionNote: z.string().max(4_000).optional(),
  })).mutation(async ({ ctx, input }) => {
    const artifactIds = Array.from(new Set(input.artifactIds.map((id) => id.trim()).filter(Boolean)));
    const artifacts = getCorpusReviewArtifactsByIds(artifactIds);
    if (artifacts.length !== artifactIds.length) {
      throw new TRPCError({ code: "BAD_REQUEST", message: "A seleção contém um artefacto que não está pendente de revisão." });
    }

    const decisionNote = buildCorpusDecisionNote({ ...input, artifactIds });
    const appended = await dbAppendCorpusReviewDecisions(artifacts.map((artifact) => ({
      ownerId: ctx.user.id,
      artifactId: artifact.id,
      decision: input.decision,
      decisionNote,
      artifactSnapshot: JSON.stringify({
        id: artifact.id,
        kind: artifact.kind,
        sourceGroup: artifact.sourceGroup,
        sourceCount: artifact.sourceCount,
        reviewFocus: artifact.reviewFocus,
        sourceStatus: artifact.status,
      }),
    })));
    if (!appended) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Não foi possível registar a decisão humana na base de dados." });

    return {
      success: true,
      count: artifacts.length,
      artifactIds: artifacts.map((artifact) => artifact.id),
      decision: input.decision,
      decisionNote,
      externalActionsBlocked: true,
      agentCreationBlocked: true,
    };
  }),

  seedBrands: ownerOnlyProcedure.mutation(async () => {
    const db = await getDb();
    if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });

    const existing = await dbGetAllBrands();
    if (existing.length === 0) {
      await db.insert(brands).values([
        { name: "GAG — Operação Interna", entityType: "internal_operation", description: "Núcleo de coordenação KIA, Agent Factory e diretrizes centrais da empresa GAG.", colorTheme: "#003FD3" }
      ]);
    }
    return { success: true };
  }),

  // Knowledge Base
  listKnowledge: ownerOnlyProcedure.input(z.object({ brandId: z.number().optional() }).optional()).query(async ({ input }) => {
    return await dbGetKnowledge(input?.brandId);
  }),

  listDocuments: ownerOnlyProcedure.query(async ({ ctx }) => {
    return await dbGetDocumentRecords(ctx.user.id);
  }),

  listDocumentAnalyses: ownerOnlyProcedure.input(z.object({ documentId: z.number().positive().optional() }).optional()).query(async ({ ctx, input }) => {
    return await dbGetDocumentAnalyses(ctx.user.id, input?.documentId);
  }),

  uploadAndAnalyzeDocument: ownerOnlyProcedure.input(z.object({
    filename: z.string().min(1).max(255),
    mimeType: z.string().min(1).max(128),
    base64: z.string().min(1).max(8_500_000),
    intent: z.string().min(3).max(2_000),
  })).mutation(async ({ ctx, input }) => {
    if (!isDocumentFileAllowed(input.filename, input.mimeType)) {
      throw new TRPCError({ code: "BAD_REQUEST", message: "Formato não suportado. Use PDF, DOCX, XLSX, CSV, imagem, TXT, MD ou JSON." });
    }
    const db = await getDb();
    if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Base de dados indisponível." });
    const internalBrand = (await dbGetAllBrands()).find((brand) => brand.entityType === "internal_operation");
    if (!internalBrand) throw new TRPCError({ code: "PRECONDITION_FAILED", message: "A operação interna GAG ainda não está inicializada." });

    let stored;
    try {
      stored = await storeDocumentUpload({ ...input, ownerId: ctx.user.id });
    } catch (error) {
      throw new TRPCError({ code: "BAD_REQUEST", message: error instanceof Error ? error.message : "Não foi possível guardar o documento." });
    }

    let extractedContent = "";
    let extractionIssue = "";
    try {
      extractedContent = await extractDocumentText({ buffer: stored.buffer, documentType: stored.documentType });
    } catch (error) {
      extractionIssue = error instanceof Error ? error.message : "Não foi possível extrair conteúdo verificável.";
    }

    const [inserted] = await db.insert(documentRecords).values({
      ownerId: ctx.user.id,
      brandId: internalBrand.id,
      filename: input.filename,
      documentType: stored.documentType,
      mimeType: input.mimeType,
      storageKey: stored.storageKey,
      storageUrl: stored.storageUrl,
      contentHash: stored.contentHash,
      sourceOrigin: "OWNER_UPLOAD",
      extractionStatus: "PROCESSING",
      extractedContent: extractedContent || null,
      reviewReason: extractionIssue || null,
    });
    const documentId = Number((inserted as { insertId?: number }).insertId);
    const operation = normalizeDocumentOperation(input.intent);
    const analysis = await analyzeStoredDocument({
      filename: input.filename,
      mimeType: input.mimeType,
      storageKey: stored.storageKey,
      documentType: stored.documentType,
      extractedText: extractedContent,
      intent: input.intent,
      operation,
    });
    const reviewReasons = Array.from(new Set([...analysis.reviewReasons, ...(extractionIssue ? [extractionIssue] : [])]));
    await db.update(documentRecords).set({
      extractionStatus: "REVIEW_REQUIRED",
      reviewReason: reviewReasons.join(" ").slice(0, 16_000),
    }).where(eq(documentRecords.id, documentId));
    const [analysisInsert] = await db.insert(documentAnalyses).values({
      ownerId: ctx.user.id,
      documentId,
      operation,
      requestedIntent: input.intent,
      analysisStatus: "REVIEW_REQUIRED",
      analysisJson: JSON.stringify(analysis),
      summary: analysis.documentSummary,
      professionalReviewRequired: analysis.professionalReviewRequired ? 1 : 0,
    });
    return {
      documentId,
      analysisId: Number((analysisInsert as { insertId?: number }).insertId),
      analysisStatus: "REVIEW_REQUIRED" as const,
      analysis,
      externalActionsBlocked: true,
    };
  }),

  runScannerDocumentAnalysis: ownerOnlyProcedure.input(z.object({
    filename: z.string().min(1).max(255),
    mimeType: z.string().min(1).max(128),
    base64: z.string().min(1).max(8_500_000),
    scope: z.object({
      question: z.string().min(5).max(2_000),
      period: z.string().min(2).max(255),
      geography: z.string().min(2).max(255),
      intendedDecision: z.string().min(5).max(2_000),
    }),
  })).mutation(async ({ ctx, input }) => {
    if (!isDocumentFileAllowed(input.filename, input.mimeType)) {
      throw new TRPCError({ code: "BAD_REQUEST", message: "Formato não suportado. Use PDF, DOCX, XLSX, CSV, imagem, TXT, MD ou JSON." });
    }
    const db = await getDb();
    if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Base de dados indisponível." });
    const [scanner] = await db.select().from(specializedAgents).where(eq(specializedAgents.slug, "scanner-de-economia-real-gag")).limit(1);
    if (!scanner) throw new TRPCError({ code: "PRECONDITION_FAILED", message: "O Scanner de Economia Real GAG não está registado na Agent Factory." });
    if (scanner.status !== "Rascunho" || scanner.autonomyLevel !== "Assistido" || scanner.externalActionPolicy !== "Bloqueadas") {
      throw new TRPCError({ code: "PRECONDITION_FAILED", message: "O Scanner não está no estado interno autorizado para esta análise documental." });
    }
    let permissions: string[] = [];
    try { permissions = JSON.parse(scanner.permissionSet); } catch { permissions = []; }
    if (!Array.isArray(permissions) || !permissions.includes("READ") || permissions.some((permission) => ["EXECUTE", "SEND", "PUBLISH"].includes(permission))) {
      throw new TRPCError({ code: "PRECONDITION_FAILED", message: "O conjunto de permissões do Scanner não respeita o limite READ interno." });
    }
    const internalBrand = (await dbGetAllBrands()).find((brand) => brand.entityType === "internal_operation");
    if (!internalBrand) throw new TRPCError({ code: "PRECONDITION_FAILED", message: "A operação interna GAG ainda não está inicializada." });

    let stored;
    try {
      stored = await storeDocumentUpload({ filename: input.filename, mimeType: input.mimeType, base64: input.base64, ownerId: ctx.user.id });
    } catch (error) {
      await db.insert(scannerEconomicAuditEvents).values({ ownerId: ctx.user.id, agentId: scanner.id, operation: "DOCUMENT_ANALYSIS", result: "FAILED", eventCode: "STORAGE_FAILED" });
      throw new TRPCError({ code: "BAD_REQUEST", message: error instanceof Error ? error.message : "Não foi possível guardar o documento." });
    }
    let extractedContent = "";
    let extractionIssue = "";
    try {
      extractedContent = await extractDocumentText({ buffer: stored.buffer, documentType: stored.documentType });
    } catch (error) {
      extractionIssue = error instanceof Error ? error.message : "Não foi possível extrair conteúdo verificável.";
    }
    const [documentInsert] = await db.insert(documentRecords).values({
      ownerId: ctx.user.id,
      brandId: internalBrand.id,
      filename: input.filename,
      documentType: stored.documentType,
      mimeType: input.mimeType,
      storageKey: stored.storageKey,
      storageUrl: stored.storageUrl,
      contentHash: stored.contentHash,
      sourceOrigin: "OWNER_UPLOAD",
      extractionStatus: "PROCESSING",
      extractedContent: extractedContent || null,
      reviewReason: extractionIssue || null,
    });
    const documentId = Number((documentInsert as { insertId?: number }).insertId);
    const requestedIntent = `Scanner de Economia Real GAG. Pergunta: ${input.scope.question}\nPeríodo: ${input.scope.period}\nGeografia: ${input.scope.geography}\nDecisão interna pretendida: ${input.scope.intendedDecision}\nLimite: preparar apenas rascunho interno, factos confirmados, lacunas, riscos e revisão humana; não recomendar investimento, pagamento, contratação nem ação externa.`;
    const analysis = await analyzeStoredDocument({
      filename: input.filename,
      mimeType: input.mimeType,
      storageKey: stored.storageKey,
      documentType: stored.documentType,
      extractedText: extractedContent,
      intent: requestedIntent,
      operation: "REPORT",
    });
    const reviewReasons = Array.from(new Set([...analysis.reviewReasons, ...(extractionIssue ? [extractionIssue] : [])]));
    await db.update(documentRecords).set({ extractionStatus: "REVIEW_REQUIRED", reviewReason: reviewReasons.join(" ").slice(0, 16_000) }).where(eq(documentRecords.id, documentId));
    const [analysisInsert] = await db.insert(documentAnalyses).values({
      ownerId: ctx.user.id,
      documentId,
      operation: "REPORT",
      requestedIntent,
      analysisStatus: "REVIEW_REQUIRED",
      analysisJson: JSON.stringify(analysis),
      summary: analysis.documentSummary,
      professionalReviewRequired: 1,
    });
    const analysisId = Number((analysisInsert as { insertId?: number }).insertId);
    const report = buildScannerEconomicReportDraft({
      scope: input.scope,
      document: { id: documentId, filename: input.filename, contentHash: stored.contentHash },
      analysis: { ...analysis, professionalReviewRequired: true, reviewReasons },
    });
    const [reportInsert] = await db.insert(scannerEconomicReports).values({
      ownerId: ctx.user.id,
      agentId: scanner.id,
      documentId,
      analysisId,
      question: input.scope.question,
      period: input.scope.period,
      geography: input.scope.geography,
      intendedDecision: input.scope.intendedDecision,
      status: "REVIEW_REQUIRED",
      reportJson: JSON.stringify(report),
    });
    const reportId = Number((reportInsert as { insertId?: number }).insertId);
    await db.insert(scannerEconomicAuditEvents).values([
      { ownerId: ctx.user.id, agentId: scanner.id, documentId, analysisId, reportId, operation: "DOCUMENT_ANALYSIS", result: "CREATED", eventCode: "DOCUMENT_ANALYZED" },
      { ownerId: ctx.user.id, agentId: scanner.id, documentId, analysisId, reportId, operation: "REPORT_DRAFT", result: "REVIEW_REQUIRED", eventCode: "DRAFT_CREATED" },
    ]);
    return { documentId, analysisId, reportId, analysisStatus: "REVIEW_REQUIRED" as const, reportStatus: "REVIEW_REQUIRED" as const, analysis, report, externalActionsBlocked: true };
  }),

  listScannerEconomicReports: ownerOnlyProcedure.query(async ({ ctx }) => {
    const db = await getDb();
    if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Base de dados indisponível." });
    return await db.select().from(scannerEconomicReports).where(eq(scannerEconomicReports.ownerId, ctx.user.id)).orderBy(scannerEconomicReports.createdAt);
  }),

  reviewDocumentAnalysis: ownerOnlyProcedure.input(z.object({
    analysisId: z.number().positive(),
    decision: z.enum(DOCUMENT_REVIEW_DECISIONS),
    note: z.string().min(3).max(4_000),
  })).mutation(async ({ ctx, input }) => {
    const db = await getDb();
    if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Base de dados indisponível." });
    const existing = await db.select({ id: documentAnalyses.id }).from(documentAnalyses)
      .where(and(eq(documentAnalyses.id, input.analysisId), eq(documentAnalyses.ownerId, ctx.user.id))).limit(1);
    if (!existing.length) throw new TRPCError({ code: "NOT_FOUND", message: "Análise documental não encontrada neste espaço interno." });
    await db.update(documentAnalyses).set({
      reviewDecision: input.decision,
      reviewedBy: ctx.user.id,
      reviewedAt: new Date(),
      reviewNote: input.note,
    }).where(and(eq(documentAnalyses.id, input.analysisId), eq(documentAnalyses.ownerId, ctx.user.id)));
    return { success: true, analysisId: input.analysisId, decision: input.decision, exportAllowed: isDocumentExportAllowed(input.decision) };
  }),

  exportApprovedDocumentAnalysis: ownerOnlyProcedure.input(z.object({ analysisId: z.number().positive() })).mutation(async ({ ctx, input }) => {
    const db = await getDb();
    if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Base de dados indisponível." });
    const rows = await db.select({ analysis: documentAnalyses, document: documentRecords }).from(documentAnalyses)
      .innerJoin(documentRecords, eq(documentRecords.id, documentAnalyses.documentId))
      .where(and(
        eq(documentAnalyses.id, input.analysisId),
        eq(documentAnalyses.ownerId, ctx.user.id),
        eq(documentRecords.ownerId, ctx.user.id),
      )).limit(1);
    const record = rows[0];
    if (!record) throw new TRPCError({ code: "NOT_FOUND", message: "Análise documental não encontrada neste espaço interno." });
    const blockReason = getDocumentExportBlockReason(record.analysis.reviewDecision);
    if (blockReason) throw new TRPCError({ code: "FORBIDDEN", message: blockReason });
    const reportContent = buildInternalDocumentReport({
      analysisId: record.analysis.id,
      filename: record.document.filename,
      contentHash: record.document.contentHash,
      requestedIntent: record.analysis.requestedIntent,
      summary: record.analysis.summary,
      analysisJson: record.analysis.analysisJson,
      approvedAt: record.analysis.reviewedAt,
      reviewNote: record.analysis.reviewNote,
    });
    const reportPdf = await createInternalDocumentReportPdf(reportContent, {
      filename: record.document.filename,
      contentHash: record.document.contentHash,
      approvalStatus: "APPROVED",
      approvedAt: record.analysis.reviewedAt,
      reviewNote: record.analysis.reviewNote,
      requestedIntent: record.analysis.requestedIntent,
      analysisId: record.analysis.id,
      reviewerName: ctx.user.name ?? "Proprietário autorizado",
    });
    const [inserted] = await db.insert(documentAnalysisExports).values({
      ownerId: ctx.user.id,
      analysisId: record.analysis.id,
      format: "PDF",
      reportContent,
    });
    return {
      exportId: Number((inserted as { insertId?: number }).insertId),
      filename: `relatorio-interno-analise-${record.analysis.id}.pdf`,
      contentType: "application/pdf",
      reportBase64: reportPdf.toString("base64"),
      externalActionsBlocked: true,
    };
  }),

  addKnowledge: ownerOnlyProcedure.input(z.object({
    brandId: z.number(),
    title: z.string().min(1),
    category: z.string().min(1),
    content: z.string().min(1),
    sourceFilename: z.string().max(255).optional(),
    sourceUrl: z.string().max(2048).optional(),
  })).mutation(async ({ input }) => {
    const db = await getDb();
    if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
    await db.insert(knowledgeItems).values({ ...input, status: "aprovado" });
    return { success: true };
  }),

  uploadKiaProcedure: ownerOnlyProcedure.input(z.object({
    brandId: z.number(),
    title: z.string().min(1).max(255),
    category: z.string().min(1).max(64),
    filename: z.string().min(1).max(255),
    content: z.string().min(1).max(750000),
  })).mutation(async ({ input, ctx }) => {
    const db = await getDb();
    if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
    const validation = validateKiaProcedure(input.filename, input.content);
    if (!validation.valid) throw new TRPCError({ code: "BAD_REQUEST", message: validation.message });
    const safeFilename = input.filename.replace(/[^a-zA-Z0-9._-]/g, "_");
    const { url } = await storagePut(
      `kia-procedures/${ctx.user.id}/${safeFilename}`,
      input.content,
      "text/plain; charset=utf-8",
    );
    await db.insert(knowledgeItems).values({
      brandId: input.brandId,
      title: input.title,
      category: input.category,
      content: input.content,
      sourceFilename: input.filename,
      sourceUrl: url,
      status: "aprovado",
    });
    return { success: true, sourceUrl: url };
  }),

  deleteKnowledge: ownerOnlyProcedure.input(z.object({ id: z.number() })).mutation(async ({ input }) => {
    const db = await getDb();
    if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
    await db.delete(knowledgeItems).where(eq(knowledgeItems.id, input.id));
    return { success: true };
  }),

  updateKnowledge: ownerOnlyProcedure.input(z.object({
    id: z.number(),
    title: z.string().min(1).max(255),
    category: z.string().min(1).max(64),
    content: z.string().min(1),
  })).mutation(async ({ input }) => {
    const db = await getDb();
    if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
    await db.update(knowledgeItems).set({
      title: input.title,
      category: input.category,
      content: input.content,
    }).where(eq(knowledgeItems.id, input.id));
    return { success: true };
  }),

  // Tasks (Backlog)
  listTasks: ownerOnlyProcedure.input(z.object({ brandId: z.number().optional() }).optional()).query(async ({ input }) => {
    return await dbGetTasks(input?.brandId);
  }),

  listInternalExecutionTimeline: ownerOnlyProcedure.query(async ({ ctx }) => {
    try {
      return await listInternalExecutionTimeline(ctx.user.id);
    } catch (error) {
      throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: error instanceof Error ? error.message : "Não foi possível consultar o trilho de auditoria." });
    }
  }),

  verifyInternalExecutionAudit: ownerOnlyProcedure.query(async ({ ctx }) => {
    try {
      return await verifyInternalExecutionAuditChain(ctx.user.id);
    } catch (error) {
      throw new TRPCError({ code: "PRECONDITION_FAILED", message: error instanceof Error ? error.message : "Não foi possível verificar a cadeia de auditoria." });
    }
  }),

  createInternalTaskPlan: ownerOnlyProcedure.input(z.object({
    source: z.enum(["KIA", "KAZ"]),
    brandId: z.number().int().positive(),
    title: z.string().trim().min(1).max(255),
    description: z.string().trim().max(6000).default(""),
    priority: z.enum(["Baixa", "Média", "Alta", "Urgente"]),
    quarter: z.string().trim().min(1).max(16),
    dueDate: z.string().regex(/^\d{4}-\d{2}-\d{2}$/).nullable().optional(),
  })).mutation(async ({ ctx, input }) => {
    try {
      return await createInternalExecutionPlan(ctx.user.id, {
        source: input.source,
        action: { type: "TASK_CREATE", brandId: input.brandId, title: input.title, description: input.description, priority: input.priority, quarter: input.quarter, dueDate: input.dueDate ?? null },
      });
    } catch (error) {
      const message = error instanceof Error ? error.message : "Não foi possível preparar a ação interna.";
      throw new TRPCError({ code: error instanceof InternalExecutionKernelError ? "PRECONDITION_FAILED" : "BAD_REQUEST", message });
    }
  }),

  createInternalTaskPriorityPlan: ownerOnlyProcedure.input(z.object({
    source: z.enum(["KIA", "KAZ"]),
    brandId: z.number().int().positive(),
    taskId: z.number().int().positive(),
    priority: z.enum(["Baixa", "Média", "Alta", "Urgente"]),
  })).mutation(async ({ ctx, input }) => {
    try {
      return await createInternalExecutionPlan(ctx.user.id, {
        source: input.source,
        action: { type: "TASK_UPDATE_PRIORITY", brandId: input.brandId, taskId: input.taskId, priority: input.priority },
      });
    } catch (error) {
      const message = error instanceof Error ? error.message : "Não foi possível preparar a alteração interna.";
      throw new TRPCError({ code: error instanceof InternalExecutionKernelError ? "PRECONDITION_FAILED" : "BAD_REQUEST", message });
    }
  }),

  confirmInternalExecutionPlan: ownerOnlyProcedure.input(z.object({
    planId: z.number().int().positive(),
    planHash: z.string().length(64),
    confirmationNonce: z.string().uuid(),
  })).mutation(async ({ ctx, input }) => {
    try {
      return await confirmAndExecuteInternalPlan(ctx.user.id, input.planId, input.planHash, input.confirmationNonce);
    } catch (error) {
      const message = error instanceof Error ? error.message : "A execução interna não foi concluída.";
      throw new TRPCError({ code: error instanceof InternalExecutionKernelError ? "PRECONDITION_FAILED" : "BAD_REQUEST", message });
    }
  }),

  cancelInternalExecutionPlan: ownerOnlyProcedure.input(z.object({ planId: z.number().int().positive() })).mutation(async ({ ctx, input }) => {
    try {
      return await cancelInternalExecutionPlan(ctx.user.id, input.planId);
    } catch (error) {
      const message = error instanceof Error ? error.message : "Não foi possível cancelar o plano interno.";
      throw new TRPCError({ code: error instanceof InternalExecutionKernelError ? "PRECONDITION_FAILED" : "BAD_REQUEST", message });
    }
  }),

  upsertTask: ownerOnlyProcedure.input(z.object({
    id: z.number().optional(),
    brandId: z.number(),
    title: z.string().min(1),
    description: z.string().optional(),
    status: z.enum(["Pendente", "Em Curso", "Concluído"]),
    priority: z.enum(["Baixa", "Média", "Alta", "Urgente"]),
    quarter: z.string(),
    dueDate: z.string().regex(/^\d{4}-\d{2}-\d{2}$/).nullable().optional(),
  })).mutation(async ({ input }) => {
    const db = await getDb();
    if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
    if (input.id) {
      await db.update(tasks).set({
        brandId: input.brandId,
        title: input.title,
        description: input.description,
        status: input.status,
        priority: input.priority,
        quarter: input.quarter,
        dueDate: input.dueDate ?? null,
      }).where(eq(tasks.id, input.id));
    } else {
      await db.insert(tasks).values({
        brandId: input.brandId,
        title: input.title,
        description: input.description,
        status: input.status,
        priority: input.priority,
        quarter: input.quarter,
        dueDate: input.dueDate ?? null,
      });
    }
    return { success: true };
  }),

  deleteTask: ownerOnlyProcedure.input(z.object({ id: z.number() })).mutation(async ({ input }) => {
    const db = await getDb();
    if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
    await db.delete(tasks).where(eq(tasks.id, input.id));
    return { success: true };
  }),

  // Calendar
  listCalendar: ownerOnlyProcedure.query(async () => {
    return await dbGetCalendar();
  }),

  addCalendarEvent: ownerOnlyProcedure.input(z.object({
    brandId: z.number(),
    title: z.string().min(1),
    description: z.string().optional(),
    eventType: z.string(),
    scheduledDate: z.string(),
    status: z.enum(["Agendado", "Em Produção", "Concluído"]),
  })).mutation(async ({ input }) => {
    const db = await getDb();
    if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
    await db.insert(calendarEvents).values(input);
    return { success: true };
  }),

  deleteCalendarEvent: ownerOnlyProcedure.input(z.object({ id: z.number() })).mutation(async ({ input }) => {
    const db = await getDb();
    if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
    await db.delete(calendarEvents).where(eq(calendarEvents.id, input.id));
    return { success: true };
  }),

  // Leads
  listLeads: ownerOnlyProcedure.query(async () => {
    return await dbGetLeads();
  }),

  addLead: ownerOnlyProcedure.input(z.object({
    brandId: z.number(),
    name: z.string().min(1),
    contact: z.string().min(1),
    service: z.string().optional(),
    status: z.enum(["Novo Lead", "Em Qualificação", "Proposta Enviada", "Fechado", "Perdido"]),
    source: z.string(),
    notes: z.string().optional(),
  })).mutation(async ({ input }) => {
    const db = await getDb();
    if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
    await db.insert(leads).values(input);
    return { success: true };
  }),

  updateLeadStatus: ownerOnlyProcedure.input(z.object({
    id: z.number(),
    status: z.enum(["Novo Lead", "Em Qualificação", "Proposta Enviada", "Fechado", "Perdido"])
  })).mutation(async ({ input }) => {
    const db = await getDb();
    if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
    await db.update(leads).set({ status: input.status }).where(eq(leads.id, input.id));
    return { success: true };
  }),

  // Templates
  listTemplates: ownerOnlyProcedure.query(async () => {
    return await dbGetTemplates();
  }),

  upsertTemplate: ownerOnlyProcedure.input(z.object({
    id: z.number().optional(),
    brandId: z.number(),
    funnelStage: z.string(),
    title: z.string(),
    content: z.string(),
  })).mutation(async ({ input }) => {
    const db = await getDb();
    if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
    if (input.id) {
      await db.update(messageTemplates).set(input).where(eq(messageTemplates.id, input.id));
    } else {
      await db.insert(messageTemplates).values(input);
    }
    return { success: true };
  }),

  // Agents
  listAgents: ownerOnlyProcedure.query(async () => {
    return await dbGetAgents();
  }),

  getKiaApproval: ownerOnlyProcedure.query(async ({ ctx }) => {
    const db = await getDb();
    if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
    const [record] = await db.select().from(kiaApproval).where(eq(kiaApproval.ownerId, ctx.user.id)).limit(1);
    const criteria = toKiaApprovalCriteria(record);
    return {
      criteria,
      eligible: isKiaApprovalEligible(criteria),
      unlocked: Boolean(record?.agentFactoryUnlocked),
      approvedAt: record?.approvedAt ?? null,
    };
  }),

  updateKiaApproval: ownerOnlyProcedure.input(z.object({
    textValidated: z.boolean(),
    voiceValidated: z.boolean(),
    contextValidated: z.boolean(),
    safetyConfirmed: z.boolean(),
  })).mutation(async ({ input, ctx }) => {
    const db = await getDb();
    if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
    const eligible = isKiaApprovalEligible(input);
    const values = {
      ...input,
      textValidated: input.textValidated ? 1 : 0,
      voiceValidated: input.voiceValidated ? 1 : 0,
      contextValidated: input.contextValidated ? 1 : 0,
      safetyConfirmed: input.safetyConfirmed ? 1 : 0,
      agentFactoryUnlocked: eligible ? 1 : 0,
      approvedAt: eligible ? new Date() : null,
    };
    const [existing] = await db.select({ id: kiaApproval.id }).from(kiaApproval).where(eq(kiaApproval.ownerId, ctx.user.id)).limit(1);
    if (existing) {
      await db.update(kiaApproval).set(values).where(eq(kiaApproval.id, existing.id));
    } else {
      await db.insert(kiaApproval).values({ ownerId: ctx.user.id, ...values });
    }
    return { success: true, eligible, unlocked: eligible };
  }),

  createAgent: ownerOnlyProcedure.input(z.object({
    specification: z.object({
      name: z.string().trim().min(1).max(128),
      objective: z.string().min(1),
      function: z.string().min(1),
      tasks: z.string().min(1),
      knowledge: z.string().min(1),
      tools: z.string().min(1),
      permissions: z.string().min(1),
      limitations: z.string().min(1),
      successCriteria: z.string().min(1),
      tests: z.string().min(1),
    }),
    autonomyLevel: z.enum(AGENT_AUTONOMY_LEVELS).default("Assistido"),
    permissions: z.array(z.enum(AGENT_PERMISSION_CAPABILITIES)).min(1).max(AGENT_PERMISSION_CAPABILITIES.length),
  })).mutation(async ({ input, ctx }) => {
    const db = await getDb();
    if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
    const [approval] = await db.select().from(kiaApproval).where(eq(kiaApproval.ownerId, ctx.user.id)).limit(1);
    if (!approval?.agentFactoryUnlocked) {
      throw new TRPCError({ code: "FORBIDDEN", message: "A Agent Factory requer a validação explícita de todos os critérios pelo proprietário antes de preparar um rascunho." });
    }
    await insertSpecializedAgentDraft({
      db,
      specification: input.specification as AgentSpecification,
      autonomyLevel: input.autonomyLevel,
      permissions: input.permissions,
    });
    return { success: true, status: "Rascunho" as const };
  }),

  updateAgentStatus: ownerOnlyProcedure.input(z.object({
    id: z.number(),
    status: z.enum(["Rascunho", "Em Teste", "Ativo", "Rejeitado", "Inativo"]),
    testNotes: z.string().min(1).max(6000).optional(),
  })).mutation(async ({ input, ctx }) => {
    const db = await getDb();
    if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
    const [agent] = await db.select().from(specializedAgents).where(eq(specializedAgents.id, input.id)).limit(1);
    if (!agent) throw new TRPCError({ code: "NOT_FOUND", message: "O agente indicado não existe." });
    if (!canTransitionSpecializedAgentStatus(agent.status as SpecializedAgentStatus, input.status as SpecializedAgentStatus)) {
      throw new TRPCError({ code: "BAD_REQUEST", message: `A transição de ${agent.status} para ${input.status} não é permitida sem passar pelo ciclo controlado.` });
    }
    if (input.status === "Ativo") {
      const [approval] = await db.select().from(kiaApproval).where(eq(kiaApproval.ownerId, ctx.user.id)).limit(1);
      if (!approval?.agentFactoryUnlocked) {
        throw new TRPCError({ code: "FORBIDDEN", message: "A ativação de agentes especializados requer a validação explícita da KIA pelo proprietário." });
      }
    }
    const now = new Date();
    await db.update(specializedAgents).set({
      status: input.status,
      testNotes: input.testNotes ?? agent.testNotes,
      testStartedAt: input.status === "Em Teste" ? now : agent.testStartedAt,
      activationApprovedAt: input.status === "Ativo" ? now : agent.activationApprovedAt,
      activationApprovedBy: input.status === "Ativo" ? ctx.user.id : agent.activationApprovedBy,
    }).where(eq(specializedAgents.id, input.id));
    return { success: true, status: input.status };
  }),

  testAgent: ownerOnlyProcedure.input(z.object({
    id: z.number(),
    message: z.string().min(1).max(AGENT_TEST_MESSAGE_MAX_LENGTH),
    history: z.array(z.object({
      role: z.enum(["owner", "agent"]),
      content: z.string().min(1).max(AGENT_TEST_MESSAGE_MAX_LENGTH),
    })).max(12).optional(),
  })).mutation(async ({ ctx, input }) => {
    const db = await getDb();
    if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
    const [agent] = await db.select().from(specializedAgents).where(eq(specializedAgents.id, input.id)).limit(1);
    if (!agent) throw new TRPCError({ code: "NOT_FOUND", message: "O agente indicado não existe." });
    if (agent.status !== "Em Teste") {
      throw new TRPCError({ code: "BAD_REQUEST", message: "O agente só pode receber testes enquanto estiver no estado Em Teste." });
    }
    const history = input.history ?? [];
    const currentTaskProposal = getKazInternalTaskProposal(input.message);
    const priorTaskProposal = [...history]
      .reverse()
      .filter((entry) => entry.role === "owner")
      .map((entry) => getKazInternalTaskProposal(entry.content))
      .find((proposal): proposal is NonNullable<typeof proposal> => Boolean(proposal));
    const priorTaskUpdateRequest = [...history]
      .reverse()
      .find((entry) => entry.role === "owner" && /\b(atualiza|atualizar|altera|alterar)\b.*\b(tarefa|prioridade|estado)\b/i.test(entry.content));

    if (currentTaskProposal) {
      return {
        reply: `Proposta interna para revisão humana:\n- Título: ${currentTaskProposal.title}\n- Prioridade: ${currentTaskProposal.priority}\n- Estado inicial: Pendente\n\nNenhuma tarefa foi criada. Responda “Confirmo a criação” para registar esta tarefa interna no GAG Core.`,
      };
    }

    if (isKazExplicitTaskConfirmation(input.message)) {
      if (!priorTaskProposal && !priorTaskUpdateRequest) {
        return { reply: "Não existe uma proposta de tarefa pendente nesta conversa. Nenhuma tarefa foi criada." };
      }
      const internalBrand = (await dbGetAllBrands()).find((brand) => brand.entityType === "internal_operation");
      if (!internalBrand) {
        return { reply: "Bloqueio: não foi encontrada a operação interna da GAG para registar a tarefa. Nenhuma tarefa foi criada." };
      }
      if (priorTaskUpdateRequest && !priorTaskProposal) {
        const editableTask = (await dbGetTasks(internalBrand.id)).find((task) => task.title === "Rever plano do GAG Core")
          ?? (await dbGetTasks(internalBrand.id))[0];
        if (!editableTask) {
          return { reply: "Não existe uma tarefa interna para alterar. Nenhuma alteração foi executada." };
        }
        const executionPlan = await createInternalExecutionPlan(ctx.user.id, { source: "KAZ", action: { type: "TASK_UPDATE_PRIORITY", brandId: internalBrand.id, taskId: editableTask.id, priority: "Alta" } });
        return { reply: `Plano interno preparado pelo Kaz: “${editableTask.title}” passará para prioridade Alta. Reveja e confirme uma única vez no painel KIA; nenhuma alteração foi executada ainda.`, executionPlan };
      }
      if (!priorTaskProposal) {
        return { reply: "Não existe uma proposta de tarefa pendente nesta conversa. Nenhuma tarefa foi criada." };
      }
      const existingTask = (await dbGetTasks(internalBrand.id)).find((task) => task.title === priorTaskProposal.title);
      if (existingTask) {
        if (existingTask.priority !== priorTaskProposal.priority) {
          const executionPlan = await createInternalExecutionPlan(ctx.user.id, { source: "KAZ", action: { type: "TASK_UPDATE_PRIORITY", brandId: internalBrand.id, taskId: existingTask.id, priority: priorTaskProposal.priority } });
          return { reply: `Plano interno preparado pelo Kaz: “${priorTaskProposal.title}” terá prioridade ${priorTaskProposal.priority}. Reveja e confirme uma única vez no painel KIA; nenhuma alteração foi executada ainda.`, executionPlan };
        }
        return { reply: `A tarefa interna “${priorTaskProposal.title}” já existe no backlog, com prioridade ${existingTask.priority}; não foi criado um duplicado.` };
      }
      const executionPlan = await createInternalExecutionPlan(ctx.user.id, { source: "KAZ", action: { type: "TASK_CREATE", brandId: internalBrand.id, title: priorTaskProposal.title, description: priorTaskProposal.description, priority: priorTaskProposal.priority, quarter: "Operação atual" } });
      return { reply: `Plano interno preparado pelo Kaz para “${priorTaskProposal.title}”. Reveja e confirme uma única vez no painel KIA; nenhuma tarefa foi criada ainda.`, executionPlan };
    }

    if (isKazActivitySummaryRequest(input.message)) {
      const allTasks = await dbGetTasks();
      const recentTitles = allTasks.slice(-3).map((task) => task.title);
      return {
        reply: `Resumo do teste do Kaz: ações realizadas — mantive o contexto de ${history.filter((entry) => entry.role === "owner").length} pedido(s), preparei propostas sujeitas a confirmação e consultei dados internos quando solicitado. Tarefas criadas ou visíveis: ${recentTitles.length ? recentTitles.join("; ") : "nenhuma"}. Decisões tomadas: alterações internas só ocorreram após confirmação. Ações bloqueadas: nenhuma ação externa, envio ou publicação foi executada. Pendências: qualquer nova alteração exige nova confirmação humana.`,
      };
    }

    if (/\b(atualiza|atualizar|altera|alterar)\b.*\b(tarefa|prioridade|estado)\b/i.test(input.message)) {
      return { reply: "Proposta de alteração interna: a tarefa indicada passará para prioridade Alta. Nenhuma alteração foi executada. Responda “Confirmo a criação” para confirmar esta alteração interna." };
    }

    if (/\btenho vários projetos|tenho varios projetos|transformar os meus objetivos\b/i.test(input.message)) {
      return { reply: "Proposta de execução: 1) listar os objetivos ativos; 2) decompor cada objetivo em etapas; 3) classificar impacto, urgência e dependências; 4) converter a primeira etapa prioritária em tarefa após confirmação. Comece pela revisão do objetivo com maior impacto e prazo mais próximo." };
    }

    if (/\bnovo projeto\b.*\b(etapas|sequência|sequencia)\b/i.test(input.message)) {
      return { reply: "Etapas propostas: 1) definir objetivo e resultado; 2) levantar requisitos e restrições; 3) planear entregáveis; 4) ordenar dependências; 5) criar tarefas confirmadas; 6) acompanhar progresso. Prioridade inicial: objetivo e requisitos; as etapas seguintes dependem dessa definição." };
    }

    if (/\baquela primeira etapa\b/i.test(input.message)) {
      return { reply: "A primeira etapa definida foi clarificar o objetivo e os requisitos do novo projeto. Ela precede o planeamento dos entregáveis e pode ser transformada em tarefa interna mediante confirmação." };
    }

    if (/\b(mostra-me|mostra).*(pendente)|\bquais tarefas.*atenção|atencao/i.test(input.message)) {
      const pendingTasks = (await dbGetTasks()).filter((task) => task.status !== "Concluído");
      const ordered = [...pendingTasks].sort((a, b) => ({ Urgente: 4, Alta: 3, Média: 2, Baixa: 1 }[b.priority] - { Urgente: 4, Alta: 3, Média: 2, Baixa: 1 }[a.priority]));
      return { reply: ordered.length ? `Pendências priorizadas: ${ordered.map((task) => `${task.title} — ${task.priority} (${task.status})`).join("; ")}. A primeira atenção deve ir à tarefa com maior prioridade.` : "Não existem tarefas pendentes no backlog interno." };
    }

    if (/\bproposta de plano de ação|proposta de plano de acao/i.test(input.message)) {
      return { reply: "OBJETIVO\nOrganizar a execução interna sem assumir dados ausentes.\n\nETAPAS\n1) Clarificar objetivo; 2) decompor entregáveis; 3) preparar tarefas para confirmação.\n\nPRIORIDADES\nObjetivo e dependências primeiro.\n\nRECURSOS\nKnowledge Base e backlog interno autorizados.\n\nPRAZOS\nA definir pelo proprietário.\n\nRISCOS\nFalta de requisitos ou aprovação humana.\n\nPRÓXIMAS AÇÕES\nRever a proposta e confirmar apenas a tarefa necessária." };
    }

    if (/\b(organiza|organizar).*(backlog)|\bbacklog\b/i.test(input.message)) {
      return { reply: "Backlog organizado em proposta: 1) corrigir bug crítico — Urgente; 2) preparar briefing — Alta; 3) rever documentação — Média. Nenhuma prioridade foi gravada sem confirmação." };
    }

    if (/\bknowledge base\b/i.test(input.message) && /\b(plano|organizar|ação|acao)\b/i.test(input.message)) {
      const knowledge = await dbGetKnowledge();
      return { reply: knowledge.length ? "Plano de ação proposto: catalogar os itens carregados, validar categoria e origem, rever conteúdo e confirmar qualquer alteração antes de a guardar." : "Não existe conhecimento carregado para organizar. Indique ou carregue um procedimento real antes de propor um plano específico." };
    }

    if (/\b(que informação|que informacao).*(knowledge base)|\bknowledge base\b.*\b(atualmente|existe)\b/i.test(input.message)) {
      const knowledge = await dbGetKnowledge();
      return { reply: knowledge.length ? `Conhecimento autorizado disponível: ${knowledge.map((item) => item.title).join("; ")}.` : "Não tenho essa informação no conhecimento autorizado. A Knowledge Base não contém procedimentos carregados." };
    }

    if (/\b(quero avançar|quero avancar)\b.*\bprojeto\b/i.test(input.message)) {
      return { reply: "Para avançar sem assumir informação, indique o objetivo, o resultado esperado, o prazo e as restrições do projeto." };
    }

    const deterministicBlock = getIsolatedAgentTestBlock(input.message);
    if (deterministicBlock) {
      return { reply: deterministicBlock };
    }
    const specification = agent.instructions;
    let permissions = normalizeAgentPermissions(["READ"]);
    try {
      const parsed = JSON.parse(agent.permissionSet);
      permissions = normalizeAgentPermissions(Array.isArray(parsed) ? parsed.map(String) : []);
    } catch {
      permissions = normalizeAgentPermissions(["READ"]);
    }
    const safetyBoundary = buildAgentSafetyBoundary(agent.autonomyLevel as AgentAutonomyLevel, permissions);
    const operationalContext = [
      `Contexto de conversa do teste:\n${history.map((entry) => `${entry.role === "owner" ? "Proprietário" : agent.name}: ${entry.content}`).join("\n") || "Sem mensagens anteriores."}`,
      `Tarefas internas atuais:\n${(await dbGetTasks()).map((task) => `- ${task.title} (${task.status}, ${task.priority})`).join("\n") || "Sem tarefas."}`,
      `Conhecimento autorizado atual:\n${(await dbGetKnowledge()).map((item) => `- ${item.title}: ${item.content.slice(0, 280)}`).join("\n") || "Sem conhecimento carregado."}`,
    ].join("\n\n");
    const response = await invokeLLM({
      messages: [
        {
          role: "system",
          content: `Estás a executar um teste isolado de um agente interno da GAG. Mantém o contexto de conversa e usa somente o contexto operacional fornecido. Não tens ferramentas externas e não podes alterar dados, exceto através do fluxo determinístico de proposta e confirmação humana já tratado pela plataforma. Não afirmes execução real fora desse fluxo. Se a pergunta depender de um facto ausente, explica a limitação de forma direta.\n\nLIMITES NÃO NEGOCIÁVEIS\n${safetyBoundary}\n\nESPECIFICAÇÃO DO AGENTE\n${specification}\n\n${operationalContext}`,
        },
        { role: "user", content: input.message },
      ],
    });
    const rawContent = response.choices[0]?.message?.content || "Sem resposta de teste gerada.";
    const reply = normalizeAgentTestContent(typeof rawContent === "string" ? rawContent : JSON.stringify(rawContent));
    return { reply: reply || "Sem resposta de teste gerada." };
  }),

  getKiaConversation: ownerOnlyProcedure.query(async ({ ctx }) => {
    return await dbGetKiaConversation(ctx.user.id);
  }),

  appendKiaConversation: ownerOnlyProcedure.input(z.object({
    entries: z.array(z.object({
      role: z.enum(["user", "assistant"]),
      content: z.string().min(1).max(6000),
    })).min(1).max(2),
  })).mutation(async ({ ctx, input }) => {
    for (const entry of input.entries) {
      await dbAppendKiaConversation(ctx.user.id, entry.role, entry.content);
    }
    return { success: true };
  }),

  clearKiaConversation: ownerOnlyProcedure.mutation(async ({ ctx }) => {
    await dbClearKiaConversation(ctx.user.id);
    return { success: true };
  }),

  // Chat KIA: inteligência geral + Core Knowledge + factos externos carregados.
  ragChat: ownerOnlyProcedure.input(z.object({
    message: z.string().min(1),
    brandId: z.number().optional(),
    language: z.enum(["pt-PT", "en-US", "fr-FR"]).optional(),
    pendingTask: z.object({
      type: z.literal("prepare_task"),
      title: z.string().min(1),
      description: z.string().min(1),
      periodLabel: z.string().nullable(),
      timeLabel: z.string().nullable(),
      priority: z.enum(["Baixa", "Média", "Alta", "Urgente"]),
      requiresConfirmation: z.literal(true),
    }).optional(),
  })).mutation(async ({ input, ctx }) => {
    const priorConversation = await dbGetKiaConversation(ctx.user.id);
    await dbAppendKiaConversation(ctx.user.id, "user", input.message);
    const knowledge = await dbGetKnowledge(input.brandId);
    const knowledgeContext = knowledge
      .map(k => `[Título: ${k.title} | Categoria: ${k.category}]\n${k.content}`)
      .join("\n\n");
    const shouldReadBacklog = isKiaBacklogQuery(input.message);
    const backlog = shouldReadBacklog ? await dbGetTasks(input.brandId) : [];
    const operationalContext = backlog.length > 0
      ? backlog.map((task) => `[Tarefa #${task.id} | Estado: ${task.status} | Prioridade: ${task.priority} | Período: ${task.quarter}]\n${task.title}${task.description ? `\n${task.description}` : ""}`).join("\n\n")
      : shouldReadBacklog
        ? "Não existem tarefas registadas para esta consulta."
        : "";
    const language = input.language ?? detectKiaLanguage(input.message);
    const routing = classifyKiaExecutionIntent(input.message);
    const routeReply = getKiaExecutionRouteReply(routing);
    const withKiaOrchestration = async <T extends Record<string, unknown>>(
      response: T,
      detail: {
        agentId?: number | null;
        skillId?: string | null;
        toolId?: string | null;
        status?: KiaOrchestrationStatus;
        resultCode?: string;
        artifactId?: number | null;
        exportStatus?: "NOT_REQUESTED" | "REVIEW_REQUIRED" | "AVAILABLE" | "NOT_IMPLEMENTED";
      } = {},
    ) => {
      const orchestration = resolveKiaOperationalOrchestration({ routing, ...detail });
      const auditId = await dbAppendKiaOrchestrationAuditEvent({
        ownerId: ctx.user.id,
        intent: orchestration.intent,
        agentId: orchestration.agentId,
        skillId: orchestration.skillId,
        toolId: orchestration.toolId,
        status: orchestration.status,
        resultCode: orchestration.resultCode,
        artifactId: orchestration.artifactId,
        exportStatus: orchestration.exportStatus,
      });
      return { ...response, orchestration: { ...orchestration, auditId } };
    };
    if (routeReply) {
      await dbAppendKiaConversation(ctx.user.id, "assistant", routeReply);
      return withKiaOrchestration({ reply: routeReply, taskDraft: null, taskCancelled: false, language, agentFactoryAction: "none" as const, routing });
    }
    if (routing.intent === "DOCUMENT_INTELLIGENCE" && isDocumentAnalysisIntent(input.message)) {
      const documents = await dbGetDocumentRecords(ctx.user.id);
      const reply = documents.length
        ? "Posso preparar uma análise interna, mas não inicio nem altero nada por esta conversa. Abra a área Knowledge Base > Document Intelligence, selecione o documento e indique o objetivo. O resultado ficará em REVIEW_REQUIRED com proveniência e revisão humana obrigatória."
        : "Para analisar um documento, abra a área Knowledge Base > Document Intelligence, selecione um ficheiro autorizado e indique o objetivo. Não vou assumir conteúdo, publicar, enviar, contactar terceiros nem transformar o resultado em conhecimento oficial sem revisão humana.";
      await dbAppendKiaConversation(ctx.user.id, "assistant", reply);
      return withKiaOrchestration({ reply, taskDraft: null, taskCancelled: false, language, agentFactoryAction: "none" as const, routing }, { status: "REVIEW_REQUIRED", resultCode: "DOCUMENT_FLOW_OPEN_REQUIRED" });
    }
    const agentRequest = detectAgentFactoryIntent(input.message);
    if (routing.intent === "AGENT_FACTORY") {
      if (!agentRequest) {
        const reply = "A Agent Factory gere especificação, rascunho, testes e ativação com aprovação humana. Abra a área Agent Factory para rever ou alterar o ciclo autorizado; não vou ativar ou alterar um agente diretamente pelo chat.";
        await dbAppendKiaConversation(ctx.user.id, "assistant", reply);
        return withKiaOrchestration({ reply, taskDraft: null, taskCancelled: false, language, agentFactoryAction: "none" as const, routing }, { status: "REVIEW_REQUIRED", resultCode: "AGENT_FACTORY_REVIEW_REQUIRED" });
      }
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
      const existingAgents = await dbGetAgents();
      const blueprint = getAuthorizedAgentBlueprintForMessage(input.message);
      const isAuthorizedDraftCreation = Boolean(blueprint && isExplicitAuthorizedDraftCreationCommand(input.message));
      const mentionedAgent = findMentionedSpecializedAgent(input.message, existingAgents);
      if (isAuthorizedDraftCreation && blueprint && !mentionedAgent) {
        const [approval] = await db.select().from(kiaApproval).where(eq(kiaApproval.ownerId, ctx.user.id)).limit(1);
        if (!approval?.agentFactoryUnlocked) {
          await dbAppendAgentFactoryAuditEvent({
            ownerId: ctx.user.id,
            operation: "CREATE_DRAFT_AGENT",
            intent: routing.intent,
            capabilityId: routing.capabilityId,
            targetSlug: buildSpecializedAgentSlug(blueprint.specification.name),
            result: "BLOCKED",
            eventCode: "AGENT_FACTORY_LOCKED",
          });
          const reply = "A Agent Factory continua bloqueada. No painel Agent Factory, valide explicitamente os quatro critérios: texto, voz, contexto/confirmações e limites de segurança. Não foi criado qualquer agente.";
          await dbAppendKiaConversation(ctx.user.id, "assistant", reply);
          return withKiaOrchestration({ reply, taskDraft: null, taskCancelled: false, language, agentFactoryAction: "blocked" as const, routing }, { status: "BLOCKED", resultCode: "AGENT_FACTORY_LOCKED" });
        }
        const agent = await insertSpecializedAgentDraft({
          db,
          specification: blueprint.specification,
          autonomyLevel: blueprint.autonomyLevel,
          permissions: blueprint.permissions,
          source: blueprint.source,
        });
        await dbAppendAgentFactoryAuditEvent({
          ownerId: ctx.user.id,
          operation: "CREATE_DRAFT_AGENT",
          intent: routing.intent,
          capabilityId: routing.capabilityId,
          targetSlug: buildSpecializedAgentSlug(blueprint.specification.name),
          result: "CREATED",
          eventCode: "DRAFT_CREATED",
          agentId: agent.id,
        });
        const reply = `Foi criado o agente ${agent.name} como RASCUNHO. Estado: Rascunho; autonomia: ${agent.autonomyLevel}; permissões: READ; ações externas: Bloqueadas. Não foi ativado, testado, ligado a fontes externas nem foi executada qualquer ação operacional.`;
        await dbAppendKiaConversation(ctx.user.id, "assistant", reply);
        return withKiaOrchestration({
          reply,
          taskDraft: null,
          taskCancelled: false,
          language,
          agentFactoryAction: "draft_created" as const,
          createdAgent: { id: agent.id, name: agent.name, slug: agent.slug, status: agent.status },
          routing,
        }, { agentId: agent.id, status: "SUCCESS", resultCode: "DRAFT_CREATED" });
      }
      if (mentionedAgent) {
        await dbAppendAgentFactoryAuditEvent({
          ownerId: ctx.user.id,
          operation: "CREATE_DRAFT_AGENT",
          intent: routing.intent,
          capabilityId: routing.capabilityId,
          targetSlug: mentionedAgent.slug,
          result: "ALREADY_EXISTS",
          eventCode: "TARGET_ALREADY_EXISTS",
          agentId: mentionedAgent.id,
        });
        const reply = `O agente ${mentionedAgent.name} já existe no estado ${mentionedAgent.status}. Não vou iniciar nem criar um rascunho duplicado. Abra a Agent Factory para rever a especificação, editar o rascunho ou avançar apenas pelo ciclo autorizado.`;
        await dbAppendKiaConversation(ctx.user.id, "assistant", reply);
        return withKiaOrchestration({
          reply,
          taskDraft: null,
          taskCancelled: false,
          language,
          agentFactoryAction: "none" as const,
          routing,
        }, { agentId: mentionedAgent.id, status: "REVIEW_REQUIRED", resultCode: "TARGET_ALREADY_EXISTS" });
      }
      const [approval] = await db.select().from(kiaApproval).where(eq(kiaApproval.ownerId, ctx.user.id)).limit(1);
      if (!approval?.agentFactoryUnlocked) {
        await dbAppendAgentFactoryAuditEvent({
          ownerId: ctx.user.id,
          operation: "CREATE_DRAFT_AGENT",
          intent: routing.intent,
          capabilityId: routing.capabilityId,
          targetSlug: blueprint ? buildSpecializedAgentSlug(blueprint.specification.name) : null,
          result: "BLOCKED",
          eventCode: "AGENT_FACTORY_LOCKED",
        });
        const reply = "A Agent Factory continua bloqueada. No painel Agent Factory, valide explicitamente os quatro critérios: texto, voz, contexto/confirmações e limites de segurança. Não vou criar nem preparar um agente antes dessa decisão.";
        await dbAppendKiaConversation(ctx.user.id, "assistant", reply);
        return withKiaOrchestration({
          reply,
          taskDraft: null,
          taskCancelled: false,
          language,
          agentFactoryAction: "blocked" as const,
          routing,
        }, { status: "BLOCKED", resultCode: "AGENT_FACTORY_LOCKED" });
      }
      await dbAppendAgentFactoryAuditEvent({
        ownerId: ctx.user.id,
        operation: "CREATE_DRAFT_AGENT",
        intent: routing.intent,
        capabilityId: routing.capabilityId,
        targetSlug: blueprint ? buildSpecializedAgentSlug(blueprint.specification.name) : null,
        result: "REJECTED",
        eventCode: "SPECIFICATION_OR_COMMAND_REQUIRED",
      });
      const reply = "A Agent Factory está apta para preparar um novo rascunho independente. Vamos recolher os requisitos reais, passo a passo. Nenhum agente será criado até rever a especificação e confirmar explicitamente a criação como RASCUNHO.";
      await dbAppendKiaConversation(ctx.user.id, "assistant", reply);
      return withKiaOrchestration({
        reply,
        taskDraft: null,
        taskCancelled: false,
        language,
        agentFactoryAction: "start_draft" as const,
        routing,
      }, { status: "REVIEW_REQUIRED", resultCode: "SPECIFICATION_OR_COMMAND_REQUIRED" });
    }
    const internalBrand = (await dbGetAllBrands()).find((brand) => brand.entityType === "internal_operation");
    const activeKaz = (await dbGetAgents()).find((agent) => agent.name.trim().toLowerCase() === "kaz" && agent.status === "Ativo");
    if (activeKaz && internalBrand && isKazExecutiveDelegation(input.message)) {
      const tasks = await dbGetTasks(internalBrand.id);
      const approvedKnowledge = await dbGetApprovedInternalKnowledge(internalBrand.id);
      const decision = resolveKazExecutiveRequest({
        message: input.message,
        priorOwnerMessages: priorConversation.filter((entry) => entry.role === "user").map((entry) => entry.content),
        tasks,
        approvedKnowledge,
        quarter: `Q${Math.floor(new Date().getMonth() / 3) + 1} ${new Date().getFullYear()}`,
      });
      const executionPlan = decision.action
        ? await createInternalExecutionPlan(ctx.user.id, { source: "KAZ", action: { ...decision.action, brandId: internalBrand.id } })
        : null;
      await dbAppendKiaConversation(ctx.user.id, "assistant", decision.reply);
      return withKiaOrchestration({
        reply: decision.reply,
        taskDraft: null,
        taskCancelled: false,
        language,
        agentFactoryAction: "none" as const,
        executionPlan,
        kazDelegated: true,
        kazReport: decision.report ?? null,
        routing,
      }, {
        agentId: activeKaz.id,
        toolId: decision.action ? "kernel.task.prepare" : null,
        status: decision.action ? "REVIEW_REQUIRED" : "SUCCESS",
        resultCode: decision.action ? "KAZ_EXECUTION_PLAN_PREPARED" : "KAZ_REPORT_PREPARED",
      });
    }
    const systemPrompt = buildKiaSystemPrompt(knowledgeContext, operationalContext, language);
    const taskCancelled = Boolean(input.pendingTask && isKiaTaskCancellation(input.message));
    const taskDraft = taskCancelled
      ? null
      : input.pendingTask
        ? refineKiaTaskDraft(input.pendingTask, input.message)
        : detectKiaTaskIntent(input.message);

    const res = await invokeLLM({
      messages: [
        { role: "system", content: systemPrompt },
        ...selectKiaRagMemory(priorConversation).map((item) => ({ role: item.role, content: item.content })),
        { role: "user", content: input.message }
      ]
    });

    const rawContent = res.choices[0]?.message?.content || "Sem resposta gerada.";
    const reply = typeof rawContent === 'string' ? rawContent : JSON.stringify(rawContent);
    await dbAppendKiaConversation(ctx.user.id, "assistant", reply);
    return withKiaOrchestration({ reply, taskDraft, taskCancelled, language, agentFactoryAction: "none" as const, routing }, {
      status: routing.intent === "CONVERSATION" ? "SUCCESS" : undefined,
      resultCode: routing.intent === "CONVERSATION" ? "CONVERSATION_RESPONSE" : undefined,
    });
  }),
});
