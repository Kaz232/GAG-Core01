import { describe, expect, it } from "vitest";
import { extractDocumentText } from "./documentIntelligence";

describe("teste documental interno controlado", () => {
  it("extrai texto de um documento interno de exemplo sem criar ação externa", async () => {
    const text = "Documento interno de exemplo\nFacto: teste técnico\nLacuna: revisão humana.";
    const extracted = await extractDocumentText({ buffer: Buffer.from(text, "utf8"), documentType: "TEXT" });
    expect(extracted).toContain("teste técnico");
    expect(extracted).toContain("revisão humana");
  });
});
