import PDFDocument from "pdfkit";
import { storageGetSignedUrl } from "./storage";

export const GAG_VISUAL_SEAL_STORAGE_KEY = "GAG_Visual_Selo_Marca_Dagua_7807a718.png";
let gagVisualSealBuffer: Promise<Buffer | null> | null = null;

async function loadGagVisualSealBuffer(): Promise<Buffer | null> {
  if (!gagVisualSealBuffer) {
    gagVisualSealBuffer = (async () => {
      try {
        const signedUrl = await storageGetSignedUrl(GAG_VISUAL_SEAL_STORAGE_KEY);
        const response = await fetch(signedUrl);
        if (!response.ok) return null;
        return Buffer.from(await response.arrayBuffer());
      } catch {
        return null;
      }
    })();
  }
  return gagVisualSealBuffer;
}

export type InternalDocumentReportPdfMetadata = {
  filename: string;
  contentHash: string;
  approvalStatus: "APPROVED";
  approvedAt: Date | null;
  reviewNote: string | null;
  requestedIntent: string;
  analysisId: number;
  reviewerName: string;
};

export function buildInternalDocumentPdfCover(metadata: InternalDocumentReportPdfMetadata): string[] {
  return [
    "RELATÓRIO INTERNO APROVADO",
    `Documento: ${metadata.filename}`,
    `Identificador da análise: ${metadata.analysisId}`,
    `Estado de aprovação: ${metadata.approvalStatus}`,
    `Data de aprovação: ${metadata.approvedAt?.toISOString() ?? "Não registada"}`,
    `Revisor autorizado: ${metadata.reviewerName}`,
    `Hash de proveniência: ${metadata.contentHash}`,
    "Identidade visual: GAG Visual",
    `Objetivo solicitado: ${metadata.requestedIntent}`,
    `Nota de revisão: ${metadata.reviewNote?.trim() || "Sem nota adicional."}`,
  ];
}

export async function createInternalDocumentReportPdf(reportContent: string, metadata: InternalDocumentReportPdfMetadata): Promise<Buffer> {
  const sealBuffer = await loadGagVisualSealBuffer();
  return await new Promise((resolve, reject) => {
    const document = new PDFDocument({ size: "A4", margin: 46, info: { Title: "Relatório interno — GAG Core" } });
    const chunks: Buffer[] = [];
    document.on("data", (chunk: Buffer) => chunks.push(chunk));
    document.on("end", () => resolve(Buffer.concat(chunks)));
    document.on("error", reject);

    document.rect(0, 0, 595, 155).fill("#003FD3");
    if (sealBuffer) {
      document.save().opacity(0.22).image(sealBuffer, 405, 22, { fit: [138, 138], align: "center", valign: "center" }).restore();
    }
    document.fillColor("#FFFFFF").fontSize(13).text("GAG CORE", 46, 52, { characterSpacing: 1.5 });
    document.fontSize(24).text("RELATÓRIO INTERNO", 46, 82);
    document.fontSize(10).fillColor("#DCE8FF").text("Documento aprovado para utilização exclusivamente interna", 46, 118);
    document.fillColor("#041038").fontSize(18).text("Capa de proveniência e aprovação", 46, 196);
    document.moveDown(0.7);
    buildInternalDocumentPdfCover(metadata).forEach((line, index) => {
      document.fontSize(index === 0 ? 12 : 9.5).fillColor(index === 0 ? "#003FD3" : "#041038").text(line, { width: 500, lineGap: 4 });
      document.moveDown(index === 0 ? 0.7 : 0.25);
    });
    document.fontSize(8.5).fillColor("#5B657A").text("Este artefacto não autoriza publicação, envio, contacto ou qualquer ação externa.", { width: 500, lineGap: 3 });
    document.addPage();
    document.fontSize(16).fillColor("#003FD3").text("GAG Core — Conteúdo do relatório", { align: "left" });
    document.moveDown(0.8);
    document.fontSize(10).fillColor("#041038").text(reportContent, { width: 500, lineGap: 3 });
    document.end();
  });
}
