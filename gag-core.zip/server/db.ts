import { and, desc, eq } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { InsertUser, users, brands, knowledgeItems, tasks, calendarEvents, leads, messageTemplates, specializedAgents, kiaConversationMessages, documentAnalyses, documentRecords, corpusReviewDecisions, agentFactoryAuditEvents, kiaOrchestrationAuditEvents } from "../drizzle/schema";
import { ENV } from './_core/env';
import { KIA_CONVERSATION_HISTORY_LIMIT, normalizeKiaConversationEntry, type KiaConversationRole } from "../shared/kiaConversation";

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

// GAG Core Database Helpers
export async function dbGetAllBrands() {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(brands);
}

export async function dbGetKnowledge(brandId?: number) {
  const db = await getDb();
  if (!db) return [];
  if (brandId) {
    return await db.select().from(knowledgeItems).where(eq(knowledgeItems.brandId, brandId));
  }
  return await db.select().from(knowledgeItems);
}

export async function dbGetApprovedInternalKnowledge(brandId: number) {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(knowledgeItems).where(and(
    eq(knowledgeItems.brandId, brandId),
    eq(knowledgeItems.status, "aprovado"),
  ));
}

export async function dbGetDocumentRecords(ownerId: number) {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(documentRecords).where(eq(documentRecords.ownerId, ownerId)).orderBy(desc(documentRecords.createdAt));
}

export async function dbGetDocumentAnalyses(ownerId: number, documentId?: number) {
  const db = await getDb();
  if (!db) return [];
  if (documentId) {
    return await db.select().from(documentAnalyses).where(and(eq(documentAnalyses.ownerId, ownerId), eq(documentAnalyses.documentId, documentId))).orderBy(desc(documentAnalyses.createdAt));
  }
  return await db.select().from(documentAnalyses).where(eq(documentAnalyses.ownerId, ownerId)).orderBy(desc(documentAnalyses.createdAt));
}

export async function dbGetTasks(brandId?: number) {
  const db = await getDb();
  if (!db) return [];
  if (brandId) {
    return await db.select().from(tasks).where(eq(tasks.brandId, brandId));
  }
  return await db.select().from(tasks);
}

export async function dbGetCalendar() {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(calendarEvents);
}

export async function dbGetLeads() {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(leads);
}

export async function dbGetTemplates() {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(messageTemplates);
}

export async function dbGetAgents() {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(specializedAgents);
}

export async function dbGetKiaConversation(ownerId: number, limit = KIA_CONVERSATION_HISTORY_LIMIT) {
  const db = await getDb();
  if (!db) return [];
  const rows = await db.select().from(kiaConversationMessages)
    .where(eq(kiaConversationMessages.ownerId, ownerId))
    .orderBy(desc(kiaConversationMessages.id))
    .limit(limit);
  return rows.reverse();
}

export async function dbAppendKiaConversation(ownerId: number, role: KiaConversationRole, content: string) {
  const entry = normalizeKiaConversationEntry({ role, content });
  if (!entry) return false;
  const db = await getDb();
  if (!db) return false;
  await db.insert(kiaConversationMessages).values({ ownerId, ...entry });
  return true;
}

export async function dbClearKiaConversation(ownerId: number) {
  const db = await getDb();
  if (!db) return false;
  await db.delete(kiaConversationMessages).where(eq(kiaConversationMessages.ownerId, ownerId));
  return true;
}

export async function dbGetCorpusReviewDecisions(ownerId: number) {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(corpusReviewDecisions)
    .where(eq(corpusReviewDecisions.ownerId, ownerId))
    .orderBy(desc(corpusReviewDecisions.id));
}

export async function dbAppendCorpusReviewDecisions(input: Array<{
  ownerId: number;
  artifactId: string;
  decision: "APPROVED" | "REJECTED";
  decisionNote: string;
  artifactSnapshot: string;
}>) {
  const db = await getDb();
  if (!db || input.length === 0) return false;
  await db.insert(corpusReviewDecisions).values(input);
  return true;
}

export async function dbAppendAgentFactoryAuditEvent(input: {
  ownerId: number;
  operation: "CREATE_DRAFT_AGENT";
  intent: string;
  capabilityId: string;
  targetSlug?: string | null;
  result: "CREATED" | "ALREADY_EXISTS" | "BLOCKED" | "REJECTED" | "FAILED";
  eventCode: string;
  agentId?: number | null;
}) {
  const db = await getDb();
  if (!db) return false;
  await db.insert(agentFactoryAuditEvents).values({
    ...input,
    targetSlug: input.targetSlug ?? null,
    agentId: input.agentId ?? null,
  });
  return true;
}

export async function dbAppendKiaOrchestrationAuditEvent(input: {
  ownerId: number;
  intent: string;
  agentId?: number | null;
  skillId?: string | null;
  toolId?: string | null;
  status: "SUCCESS" | "FAILED" | "BLOCKED" | "NOT_IMPLEMENTED" | "REVIEW_REQUIRED";
  resultCode: string;
  artifactId?: number | null;
  exportStatus: "NOT_REQUESTED" | "REVIEW_REQUIRED" | "AVAILABLE" | "NOT_IMPLEMENTED";
}) {
  const db = await getDb();
  if (!db) return null;
  const created = await db.insert(kiaOrchestrationAuditEvents).values({
    ...input,
    agentId: input.agentId ?? null,
    skillId: input.skillId ?? null,
    toolId: input.toolId ?? null,
    artifactId: input.artifactId ?? null,
  }).$returningId();
  return created[0]?.id ?? null;
}
