import { describe, expect, it, vi } from "vitest";
import { chooseVoice, configureInterruptionRecognition, configureRecognition, createVoiceOptions, disposeRecognition, getRecognitionTranscript, prepareKiaSpeechText, shouldKeepListening } from "./useVoiceConversation";

function makeVoice(name: string, lang: string, voiceURI: string) {
  return { name, lang, voiceURI } as SpeechSynthesisVoice;
}

describe("seleção de voz da KIA", () => {
  const voices = [
    makeVoice("English", "en-US", "en-us"),
    makeVoice("Português", "pt-PT", "pt-pt"),
  ];

  it("prioriza a voz escolhida pelo utilizador", () => {
    expect(chooseVoice(voices, "en-us", "pt-PT")?.voiceURI).toBe("en-us");
  });

  it("seleciona uma voz compatível com o idioma quando não há escolha gravada", () => {
    expect(chooseVoice(voices, "", "pt-PT")?.voiceURI).toBe("pt-pt");
  });

  it("usa a voz disponível mais próxima quando o idioma da resposta não existe no dispositivo", () => {
    expect(chooseVoice(voices, "", "fr-FR")?.voiceURI).toBe("en-us");
  });

  it("assigns unique option identifiers when the browser returns repeated voice URIs", () => {
    const repeatedVoice = makeVoice("Português", "pt-PT", "pt-pt");
    const options = createVoiceOptions([repeatedVoice, repeatedVoice]);

    expect(options.map((option) => option.id)).toEqual(["pt-pt::0", "pt-pt::1"]);
    expect(new Set(options.map((option) => option.id)).size).toBe(options.length);
  });

  it("não mantém a escuta ativa quando o modo de conversação está desativado", () => {
    expect(shouldKeepListening(false)).toBe(false);
    expect(shouldKeepListening(true)).toBe(true);
  });

  it("configura o reconhecimento para terminar após um pedido quando o modo está desativado", () => {
    const recognition = { lang: "", continuous: true, interimResults: true, maxAlternatives: 0 };

    configureRecognition(recognition, "pt-PT", false);

    expect(recognition).toEqual({
      lang: "pt-PT",
      continuous: false,
      interimResults: false,
      maxAlternatives: 1,
    });
  });

  it("configura a escuta de interrupção com resultados intercalares para reagir ao início da fala", () => {
    const recognition = { lang: "", continuous: true, interimResults: false, maxAlternatives: 0 };

    configureInterruptionRecognition(recognition, "pt-PT");

    expect(recognition).toEqual({
      lang: "pt-PT",
      continuous: false,
      interimResults: true,
      maxAlternatives: 1,
    });
  });

  it("mantém o texto intercetarado e só marca a entrega quando a fala termina", () => {
    const event = {
      resultIndex: 0,
      results: {
        length: 2,
        0: { length: 1, isFinal: false, 0: { transcript: "Kia, espera" } },
        1: { length: 1, isFinal: true, 0: { transcript: " por favor" } },
      },
    };

    expect(getRecognitionTranscript(event)).toEqual({ transcript: "Kia, espera por favor", hasFinalResult: true });
  });

  it("remove listeners e aborta o reconhecimento ao libertar o recurso", () => {
    const recognition = {
      abort: vi.fn(),
      onstart: vi.fn(),
      onend: vi.fn(),
      onerror: vi.fn(),
      onresult: vi.fn(),
    };

    disposeRecognition(recognition);

    expect(recognition.abort).toHaveBeenCalledOnce();
    expect(recognition.onstart).toBeNull();
    expect(recognition.onend).toBeNull();
    expect(recognition.onerror).toBeNull();
    expect(recognition.onresult).toBeNull();
  });

  it("prepara KIA como Kia para uma pronúncia natural sem alterar a resposta visível", () => {
    expect(prepareKiaSpeechText("A **KIA** organiza o backlog.")).toBe("A Kia organiza o backlog.");
  });

  it("remove artefactos de markdown e cria pausas naturais para a síntese", () => {
    expect(prepareKiaSpeechText("## KIA:\n- confirma a tarefa; depois responde.")).toBe("Kia, confirma a tarefa, depois responde.");
  });
});
