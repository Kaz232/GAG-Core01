/** @vitest-environment jsdom */

import { act, renderHook } from "@testing-library/react";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { useVoiceConversation } from "./useVoiceConversation";

class MockRecognition {
  lang = "";
  continuous = false;
  interimResults = false;
  maxAlternatives = 1;
  onstart: (() => void) | null = null;
  onend: (() => void) | null = null;
  onerror: ((event: { error: string }) => void) | null = null;
  onresult: ((event: { resultIndex: number; results: { length: number; [index: number]: { length: number; isFinal: boolean; 0: { transcript: string } } } }) => void) | null = null;
  start = vi.fn(() => this.onstart?.());
  abort = vi.fn(() => this.onend?.());

  emitResult(transcript: string, isFinal: boolean) {
    this.onresult?.({
      resultIndex: 0,
      results: { length: 1, 0: { length: 1, isFinal, 0: { transcript } } },
    });
  }
}

class MockUtterance {
  lang = "";
  rate = 1;
  pitch = 1;
  volume = 1;
  voice: SpeechSynthesisVoice | null = null;
  onstart: (() => void) | null = null;
  onend: (() => void) | null = null;
  onerror: (() => void) | null = null;

  constructor(public text: string) {}
}

describe("conversação de voz com interrupção da KIA", () => {
  let recognitions: MockRecognition[];
  let utterances: MockUtterance[];
  let synthesis: { cancel: ReturnType<typeof vi.fn>; speak: ReturnType<typeof vi.fn>; getVoices: ReturnType<typeof vi.fn>; onvoiceschanged: (() => void) | null };

  beforeEach(() => {
    vi.useFakeTimers();
    recognitions = [];
    utterances = [];
    synthesis = {
      cancel: vi.fn(),
      speak: vi.fn((utterance: MockUtterance) => {
        utterances.push(utterance);
        utterance.onstart?.();
      }),
      getVoices: vi.fn(() => []),
      onvoiceschanged: null,
    };

    const RecognitionConstructor = class extends MockRecognition {
      constructor() {
        super();
        recognitions.push(this);
      }
    };

    Object.defineProperty(window, "SpeechRecognition", { configurable: true, value: RecognitionConstructor });
    Object.defineProperty(window, "webkitSpeechRecognition", { configurable: true, value: undefined });
    Object.defineProperty(window, "speechSynthesis", { configurable: true, value: synthesis });
    vi.stubGlobal("SpeechSynthesisUtterance", MockUtterance);
  });

  afterEach(() => {
    vi.useRealTimers();
    vi.unstubAllGlobals();
    window.localStorage.clear();
  });

  function beginVoiceTurn() {
    const onTranscript = vi.fn();
    const hook = renderHook(() => useVoiceConversation());

    act(() => hook.result.current.startListening(onTranscript));
    act(() => hook.result.current.speak("KIA: resposta pronta.", true));
    act(() => vi.advanceTimersByTime(100));

    return { ...hook, onTranscript };
  }

  it("inicia escuta de interrupção quando a KIA começa a responder", () => {
    const { result } = beginVoiceTurn();

    expect(utterances).toHaveLength(1);
    expect(utterances[0]).toMatchObject({ text: "Kia, resposta pronta.", rate: 0.92, pitch: 1.05 });
    expect(recognitions).toHaveLength(2);
    expect(recognitions[1]).toMatchObject({ continuous: false, interimResults: true, lang: "pt-PT" });
    expect(result.current.status).toBe("speaking");
    expect(result.current.isInterruptionListening).toBe(true);
  });

  it("cancela imediatamente a síntese quando a pessoa começa a falar e só entrega após silêncio", () => {
    const { result, onTranscript } = beginVoiceTurn();
    synthesis.cancel.mockClear();

    act(() => recognitions[1].emitResult("Kia, espera", false));

    expect(synthesis.cancel).toHaveBeenCalledOnce();
    expect(result.current.status).toBe("listening");
    expect(onTranscript).not.toHaveBeenCalled();

    act(() => recognitions[1].emitResult("Kia, espera", true));

    expect(onTranscript).toHaveBeenCalledOnce();
    expect(onTranscript).toHaveBeenCalledWith("Kia, espera");
    expect(result.current.status).toBe("processing");
  });

  it("limpa a escuta de interrupção e a síntese quando o utilizador cancela", () => {
    const { result } = beginVoiceTurn();
    const interruptionRecognition = recognitions[1];
    synthesis.cancel.mockClear();

    act(() => result.current.cancel());

    expect(interruptionRecognition.abort).toHaveBeenCalledOnce();
    expect(synthesis.cancel).toHaveBeenCalledOnce();
    expect(result.current.isInterruptionListening).toBe(false);
    expect(result.current.status).toBe("idle");
  });
});
