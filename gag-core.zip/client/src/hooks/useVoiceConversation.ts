import { useCallback, useEffect, useRef, useState } from "react";

type RecognitionResult = { transcript: string };
type RecognitionResultList = {
  length: number;
  [index: number]: { length: number; isFinal: boolean; [index: number]: RecognitionResult };
};
type RecognitionEvent = { resultIndex: number; results: RecognitionResultList };
type RecognitionInstance = {
  lang: string;
  continuous: boolean;
  interimResults: boolean;
  maxAlternatives: number;
  start: () => void;
  abort: () => void;
  onstart: (() => void) | null;
  onend: (() => void) | null;
  onerror: ((event: { error: string }) => void) | null;
  onresult: ((event: RecognitionEvent) => void) | null;
};
type RecognitionConstructor = new () => RecognitionInstance;
export type RecognitionCleanupTarget = Pick<RecognitionInstance, "abort" | "onstart" | "onend" | "onerror" | "onresult">;

declare global {
  interface Window {
    SpeechRecognition?: RecognitionConstructor;
    webkitSpeechRecognition?: RecognitionConstructor;
  }
}

export type VoiceStatus = "idle" | "listening" | "processing" | "speaking" | "error" | "unsupported";

export type VoicePreferences = {
  voiceReplies: boolean;
  autoPlay: boolean;
  conversationMode: boolean;
  voiceURI: string;
  language: string;
  rate: number;
  volume: number;
};

export type VoiceOption = {
  id: string;
  voiceURI: string;
  label: string;
};

const STORAGE_KEY = "gag-core-voice-preferences";
const NATURAL_VOICE_RATE = 0.92;
const NATURAL_VOICE_PITCH = 1.05;
const SPEECH_START_DELAY_MS = 100;

export const defaultVoicePreferences: VoicePreferences = {
  voiceReplies: true,
  autoPlay: true,
  conversationMode: false,
  voiceURI: "",
  language: "pt-PT",
  rate: NATURAL_VOICE_RATE,
  volume: 1,
};

export function chooseVoice(voices: SpeechSynthesisVoice[], voiceURI: string, language: string): SpeechSynthesisVoice | undefined {
  const normalizedLanguage = language.toLocaleLowerCase();
  const languagePrefix = normalizedLanguage.split("-")[0];

  return voices.find((voice) => voice.voiceURI === voiceURI)
    ?? voices.find((voice) => voice.lang.toLocaleLowerCase() === normalizedLanguage)
    ?? voices.find((voice) => voice.lang.toLocaleLowerCase().startsWith(languagePrefix))
    ?? voices[0];
}

export function createVoiceOptions(voices: SpeechSynthesisVoice[]): VoiceOption[] {
  const occurrences = new Map<string, number>();

  return voices.map((voice) => {
    const baseId = voice.voiceURI || `${voice.name}::${voice.lang}`;
    const occurrence = occurrences.get(baseId) ?? 0;
    occurrences.set(baseId, occurrence + 1);

    return {
      id: `${baseId}::${occurrence}`,
      voiceURI: voice.voiceURI,
      label: `${voice.name} — ${voice.lang}`,
    };
  });
}

export function shouldKeepListening(conversationMode: boolean): boolean {
  return conversationMode;
}

export function configureRecognition(
  recognition: Pick<RecognitionInstance, "lang" | "continuous" | "interimResults" | "maxAlternatives">,
  language: string,
  conversationMode: boolean,
): void {
  recognition.lang = language;
  recognition.continuous = shouldKeepListening(conversationMode);
  recognition.interimResults = false;
  recognition.maxAlternatives = 1;
}

export function configureInterruptionRecognition(
  recognition: Pick<RecognitionInstance, "lang" | "continuous" | "interimResults" | "maxAlternatives">,
  language: string,
): void {
  recognition.lang = language;
  recognition.continuous = false;
  recognition.interimResults = true;
  recognition.maxAlternatives = 1;
}

export function getRecognitionTranscript(event: RecognitionEvent): { transcript: string; hasFinalResult: boolean } {
  let transcript = "";
  let hasFinalResult = false;

  for (let index = event.resultIndex; index < event.results.length; index += 1) {
    const result = event.results[index];
    transcript += result?.[0]?.transcript ?? "";
    hasFinalResult ||= Boolean(result?.isFinal);
  }

  return { transcript: transcript.trim(), hasFinalResult };
}

export function disposeRecognition(recognition: RecognitionCleanupTarget | null): void {
  if (!recognition) return;

  recognition.onstart = null;
  recognition.onend = null;
  recognition.onerror = null;
  recognition.onresult = null;
  recognition.abort();
}

function getRecognitionConstructor(): RecognitionConstructor | undefined {
  if (typeof window === "undefined") return undefined;
  return window.SpeechRecognition ?? window.webkitSpeechRecognition;
}

export function prepareKiaSpeechText(text: string): string {
  return text
    .replace(/```[\s\S]*?```/g, " ")
    .replace(/[`*_#>]/g, " ")
    .replace(/^\s*[-•]\s*/gm, ", ")
    .replace(/[\n\r]+/g, ", ")
    .replace(/\s*[:;]\s*/g, ", ")
    .replace(/\s*[•-]\s+/g, ", ")
    .replace(/\bKIA\b/g, "Kia")
    .replace(/\s+/g, " ")
    .replace(/\s*,\s*/g, ", ")
    .replace(/(?:,\s*){2,}/g, ", ")
    .trim();
}

export function useVoiceConversation() {
  const [voices, setVoices] = useState<SpeechSynthesisVoice[]>([]);
  const [preferences, setPreferences] = useState<VoicePreferences>(defaultVoicePreferences);
  const [status, setStatus] = useState<VoiceStatus>("idle");
  const [error, setError] = useState<string | null>(null);
  const [isInterruptionListening, setIsInterruptionListening] = useState(false);
  const recognitionRef = useRef<RecognitionInstance | null>(null);
  const interruptionRecognitionRef = useRef<RecognitionInstance | null>(null);
  const transcriptHandlerRef = useRef<((transcript: string) => void) | null>(null);
  const startListeningRef = useRef<((onTranscript: (transcript: string) => void) => void) | null>(null);
  const speechSessionRef = useRef(0);
  const speechStartTimerRef = useRef<number | null>(null);
  const statusRef = useRef<VoiceStatus>("idle");

  const updateStatus = useCallback((nextStatus: VoiceStatus) => {
    statusRef.current = nextStatus;
    setStatus(nextStatus);
  }, []);

  const clearSpeechStartDelay = useCallback(() => {
    if (speechStartTimerRef.current !== null) {
      window.clearTimeout(speechStartTimerRef.current);
      speechStartTimerRef.current = null;
    }
  }, []);

  const disposeActiveRecognition = useCallback(() => {
    const recognition = recognitionRef.current;
    recognitionRef.current = null;
    disposeRecognition(recognition);
  }, []);

  const disposeInterruptionRecognition = useCallback(() => {
    const recognition = interruptionRecognitionRef.current;
    interruptionRecognitionRef.current = null;
    setIsInterruptionListening(false);
    disposeRecognition(recognition);
  }, []);

  useEffect(() => {
    if (typeof window === "undefined") return;
    const stored = window.localStorage.getItem(STORAGE_KEY);
    if (!stored) return;
    try {
      setPreferences({ ...defaultVoicePreferences, ...JSON.parse(stored) });
    } catch {
      window.localStorage.removeItem(STORAGE_KEY);
    }
  }, []);

  useEffect(() => {
    return () => {
      speechSessionRef.current += 1;
      clearSpeechStartDelay();
      disposeActiveRecognition();
      disposeInterruptionRecognition();
      if (typeof window !== "undefined" && "speechSynthesis" in window) window.speechSynthesis.cancel();
    };
  }, [clearSpeechStartDelay, disposeActiveRecognition, disposeInterruptionRecognition]);

  useEffect(() => {
    if (typeof window === "undefined" || !("speechSynthesis" in window)) return;
    const synth = window.speechSynthesis;
    const loadVoices = () => setVoices(synth.getVoices());
    loadVoices();
    synth.onvoiceschanged = loadVoices;
    return () => {
      synth.onvoiceschanged = null;
    };
  }, []);

  const updatePreferences = useCallback((patch: Partial<VoicePreferences>) => {
    setPreferences((current) => {
      const next = { ...current, ...patch };
      if (typeof window !== "undefined") {
        window.localStorage.setItem(STORAGE_KEY, JSON.stringify(next));
      }
      return next;
    });
  }, []);

  const selectedVoice = chooseVoice(voices, preferences.voiceURI, preferences.language);

  const speak = useCallback((text: string, force = false, languageOverride?: string) => {
    if (typeof window === "undefined" || !("speechSynthesis" in window)) {
      setError("A reprodução de voz não é suportada neste navegador.");
      updateStatus("unsupported");
      return;
    }
    if (!force && (!preferences.voiceReplies || !preferences.autoPlay)) return;

    const content = prepareKiaSpeechText(text);
    if (!content) return;

    const language = languageOverride ?? preferences.language;
    const voiceForLanguage = chooseVoice(voices, preferences.voiceURI, language);
    const utterance = new SpeechSynthesisUtterance(content);
    const sessionId = speechSessionRef.current + 1;
    speechSessionRef.current = sessionId;
    utterance.lang = language;
    utterance.rate = preferences.rate;
    utterance.pitch = NATURAL_VOICE_PITCH;
    utterance.volume = preferences.volume;
    if (voiceForLanguage) utterance.voice = voiceForLanguage;

    const finishInterruptedTurn = (recognition: RecognitionInstance, transcript: string) => {
      if (!transcript) {
        if (statusRef.current === "listening") updateStatus("idle");
        return;
      }
      if (interruptionRecognitionRef.current === recognition) {
        interruptionRecognitionRef.current = null;
        setIsInterruptionListening(false);
        disposeRecognition(recognition);
      }
      updateStatus("processing");
      transcriptHandlerRef.current?.(transcript);
    };

    const startInterruptionDetection = () => {
      const Recognition = getRecognitionConstructor();
      if (!Recognition || !transcriptHandlerRef.current || speechSessionRef.current !== sessionId) return;

      disposeInterruptionRecognition();
      const recognition = new Recognition();
      let capturedTranscript = "";
      let interrupted = false;
      let delivered = false;
      interruptionRecognitionRef.current = recognition;
      configureInterruptionRecognition(recognition, language);
      recognition.onstart = () => {
        if (speechSessionRef.current === sessionId) setIsInterruptionListening(true);
      };
      recognition.onresult = (event) => {
        if (speechSessionRef.current !== sessionId && !interrupted) return;
        const { transcript, hasFinalResult } = getRecognitionTranscript(event);
        if (transcript) capturedTranscript = transcript;
        if (!capturedTranscript) return;

        if (!interrupted) {
          interrupted = true;
          speechSessionRef.current += 1;
          clearSpeechStartDelay();
          setIsInterruptionListening(false);
          window.speechSynthesis.cancel();
          updateStatus("listening");
        }
        if (hasFinalResult && !delivered) {
          delivered = true;
          finishInterruptedTurn(recognition, capturedTranscript);
        }
      };
      recognition.onerror = () => {
        if (interruptionRecognitionRef.current === recognition) interruptionRecognitionRef.current = null;
        setIsInterruptionListening(false);
      };
      recognition.onend = () => {
        if (interruptionRecognitionRef.current === recognition) interruptionRecognitionRef.current = null;
        setIsInterruptionListening(false);
        if (interrupted && !delivered) {
          delivered = true;
          finishInterruptedTurn(recognition, capturedTranscript);
        }
      };
      try {
        recognition.start();
      } catch {
        if (interruptionRecognitionRef.current === recognition) interruptionRecognitionRef.current = null;
        setIsInterruptionListening(false);
      }
    };

    utterance.onstart = () => {
      if (speechSessionRef.current !== sessionId) return;
      updateStatus("speaking");
      startInterruptionDetection();
    };
    utterance.onend = () => {
      if (speechSessionRef.current !== sessionId) return;
      disposeInterruptionRecognition();
      const handler = transcriptHandlerRef.current;
      if (preferences.conversationMode && handler) startListeningRef.current?.(handler);
      else updateStatus("idle");
    };
    utterance.onerror = () => {
      if (speechSessionRef.current !== sessionId) return;
      disposeInterruptionRecognition();
      setError("Não foi possível reproduzir a resposta por voz.");
      updateStatus("error");
    };

    clearSpeechStartDelay();
    disposeActiveRecognition();
    disposeInterruptionRecognition();
    window.speechSynthesis.cancel();
    speechStartTimerRef.current = window.setTimeout(() => {
      speechStartTimerRef.current = null;
      if (speechSessionRef.current === sessionId) window.speechSynthesis.speak(utterance);
    }, SPEECH_START_DELAY_MS);
  }, [clearSpeechStartDelay, disposeActiveRecognition, disposeInterruptionRecognition, preferences, updateStatus, voices]);

  const startListening = useCallback((onTranscript: (transcript: string) => void) => {
    const Recognition = getRecognitionConstructor();
    if (!Recognition) {
      setError("A entrada de voz não é suportada neste navegador. Use Chromium no Android ou Chrome atualizado.");
      updateStatus("unsupported");
      return;
    }

    transcriptHandlerRef.current = onTranscript;
    speechSessionRef.current += 1;
    clearSpeechStartDelay();
    disposeActiveRecognition();
    disposeInterruptionRecognition();
    if (typeof window !== "undefined" && "speechSynthesis" in window) window.speechSynthesis.cancel();
    setError(null);
    const recognition = new Recognition();
    recognitionRef.current = recognition;
    configureRecognition(recognition, preferences.language, preferences.conversationMode);
    recognition.onstart = () => updateStatus("listening");
    recognition.onresult = (event) => {
      const { transcript, hasFinalResult } = getRecognitionTranscript(event);
      if (transcript && hasFinalResult) {
        updateStatus("processing");
        onTranscript(transcript);
      }
    };
    recognition.onerror = (event) => {
      const message = event.error === "not-allowed"
        ? "Permissão de microfone negada. Autorize o microfone para utilizar a conversação por voz."
        : "Não foi possível compreender a fala. Tente novamente num local mais silencioso.";
      setError(message);
      updateStatus("error");
    };
    recognition.onend = () => {
      if (recognitionRef.current === recognition) recognitionRef.current = null;
      if (statusRef.current === "listening") updateStatus("idle");
    };

    try {
      recognition.start();
    } catch {
      setError("A entrada de voz já está ativa ou não pôde ser iniciada.");
      updateStatus("error");
    }
  }, [clearSpeechStartDelay, disposeActiveRecognition, disposeInterruptionRecognition, preferences.conversationMode, preferences.language, updateStatus]);

  startListeningRef.current = startListening;

  const cancel = useCallback(() => {
    speechSessionRef.current += 1;
    clearSpeechStartDelay();
    disposeActiveRecognition();
    disposeInterruptionRecognition();
    if (typeof window !== "undefined" && "speechSynthesis" in window) window.speechSynthesis.cancel();
    setError(null);
    updateStatus("idle");
  }, [clearSpeechStartDelay, disposeActiveRecognition, disposeInterruptionRecognition, updateStatus]);

  return {
    voices,
    preferences,
    selectedVoice,
    status,
    error,
    isInterruptionListening,
    isRecognitionSupported: Boolean(getRecognitionConstructor()),
    updatePreferences,
    startListening,
    speak,
    cancel,
  };
}
