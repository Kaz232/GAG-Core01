import { describe, expect, it } from "vitest";
import { getNextVoiceSettingsOpen } from "./voiceSettings";

describe("configuração de voz recolhível", () => {
  it("abre a partir do estado recolhido", () => {
    expect(getNextVoiceSettingsOpen(false, "toggle")).toBe(true);
  });

  it("volta a recolher depois de aplicar a configuração", () => {
    expect(getNextVoiceSettingsOpen(true, "apply")).toBe(false);
  });
});
