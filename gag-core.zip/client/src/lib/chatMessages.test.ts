import { describe, expect, it } from "vitest";
import { createChatMessage, toRagHistory } from "./chatMessages";

describe("chat message identity", () => {
  it("creates a deterministic identity for each rendered message", () => {
    expect(createChatMessage(4, "assistant", "Resposta confirmada.")).toEqual({
      id: "chat-message-4",
      role: "assistant",
      content: "Resposta confirmada.",
    });
  });

  it("excludes render-only identities from the RAG history payload", () => {
    const message = createChatMessage(7, "user", "Pergunta operacional");

    expect(toRagHistory([message])).toEqual([
      { role: "user", content: "Pergunta operacional" },
    ]);
  });
});
