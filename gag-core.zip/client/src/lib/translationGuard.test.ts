import { readFileSync } from "node:fs";
import { describe, expect, it } from "vitest";

const indexHtml = readFileSync(new URL("../../index.html", import.meta.url), "utf8");

describe("proteção da árvore React contra tradução automática", () => {
  it("declara o idioma da aplicação e bloqueia tradução que altera nós montados pelo React", () => {
    expect(indexHtml).toContain('<html lang="pt-PT" translate="no">');
    expect(indexHtml).toContain('<meta name="google" content="notranslate" />');
    expect(indexHtml).toContain('<div id="root" translate="no"></div>');
  });
});
