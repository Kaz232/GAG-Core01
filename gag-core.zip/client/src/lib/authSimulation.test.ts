import { describe, expect, it } from "vitest";
import { getSimulatedAuthError } from "./authSimulation";

describe("authSimulation", () => {
  it("gera somente mensagens locais e reversíveis", () => {
    expect(getSimulatedAuthError("NETWORK")).toContain("Simulação local");
    expect(getSimulatedAuthError("NONE")).toBeUndefined();
  });
});

