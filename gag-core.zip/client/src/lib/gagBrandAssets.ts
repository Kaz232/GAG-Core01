export const GAG_BRAND_ASSETS = {
  simplifiedLogo: "/manus-storage/GAG_Visual_Logo_Simplificado(2)_1faaaaef.png",
  monochromeBlackLogo: "/manus-storage/GAG_Visual_Logo_Monocromatico_Preto(2)_061cdb2f.png",
  seal: "/manus-storage/GAG_Visual_Selo_Marca_Dagua_7807a718.png",
  monochromeWhiteLogo: "/manus-storage/GAG_Visual_Logo_Monocromatico_Branco(1)_3f7f2906.png",
  horizontalLogo: "/manus-storage/GAG_Visual_Horizontal_6313dadf.webp",
  letterheadReference: "/manus-storage/GAG_Visual_Papel_Timbrado_A4_1892d7e4.webp",
} as const;
