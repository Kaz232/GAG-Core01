/**
 * O Chromium pode emitir estes avisos após uma alteração de layout observada
 * pela própria plataforma. Não representam uma falha de dados, autenticação
 * ou execução e não devem ser apresentados como erro operacional ao utilizador.
 */
export function isBenignResizeObserverWarning(message: string | undefined) {
  return (
    message === "ResizeObserver loop completed with undelivered notifications." ||
    message === "ResizeObserver loop limit exceeded"
  );
}

/**
 * Interrompe apenas os avisos conhecidos e não-fatais do navegador. Todos os
 * restantes erros continuam a chegar ao coletor e à consola normalmente.
 */
export function installBenignResizeObserverWarningFilter() {
  window.addEventListener(
    "error",
    event => {
      if (!isBenignResizeObserverWarning(event.message)) return;

      event.preventDefault();
      event.stopImmediatePropagation();
    },
    true
  );
}
