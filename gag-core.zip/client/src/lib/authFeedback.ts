export type AuthenticationFeedback = {
  tone: "info" | "error" | "progress";
  title: string;
  message: string;
};

export function getAuthenticationFeedback(errorMessage?: string | null, loginStarted = false): AuthenticationFeedback {
  const normalizedError = errorMessage?.toLowerCase().trim() ?? "";

  if (normalizedError) {
    if (/(cookie|state|403|sessão)/.test(normalizedError)) {
      return {
        tone: "error",
        title: "Não foi possível validar a sessão",
        message: "Verifique se o navegador permite cookies para este site e tente entrar novamente. A sessão não foi criada.",
      };
    }

    if (/(network|fetch|ligação|conexão|connection)/.test(normalizedError)) {
      return {
        tone: "error",
        title: "Não foi possível contactar o serviço de autenticação",
        message: "Confirme a ligação à internet, recarregue esta página e tente novamente. Nenhum acesso foi concedido.",
      };
    }

    return {
      tone: "error",
      title: "A validação da sessão falhou",
      message: "Recarregue a página e tente entrar novamente. Se o erro persistir, verifique as definições de cookies do navegador.",
    };
  }

  if (loginStarted) {
    return {
      tone: "progress",
      title: "A abrir autenticação segura",
      message: "Será direcionado para validar a sua conta. Não feche esta página durante a validação.",
    };
  }

  return {
    tone: "info",
    title: "Acesso reservado ao proprietário",
    message: "Use a conta autorizada da GAG. O sistema não concede acesso nem executa alterações antes de confirmar a sessão.",
  };
}
