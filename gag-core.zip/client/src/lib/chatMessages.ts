export type ChatMessageRole = "user" | "assistant";

export type ChatMessage = {
  id: string;
  role: ChatMessageRole;
  content: string;
};

export function createChatMessage(
  sequence: number,
  role: ChatMessageRole,
  content: string,
): ChatMessage {
  return {
    id: `chat-message-${sequence}`,
    role,
    content,
  };
}

export function toRagHistory(messages: ChatMessage[]) {
  return messages.map(({ role, content }) => ({ role, content }));
}
