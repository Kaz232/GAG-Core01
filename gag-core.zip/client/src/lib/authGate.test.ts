import { describe, expect, it } from "vitest";
import {
  canRunProtectedQueries,
  shouldShowAuthLoading,
  shouldShowLogin,
} from "./authGate";

describe("auth gate", () => {
  it("blocks protected queries while the session is loading", () => {
    expect(canRunProtectedQueries({ loading: true, isAuthenticated: false })).toBe(false);
    expect(shouldShowAuthLoading(true)).toBe(true);
  });

  it("blocks protected queries for an unauthenticated user", () => {
    expect(canRunProtectedQueries({ loading: false, isAuthenticated: false })).toBe(false);
    expect(shouldShowLogin({ loading: false, isAuthenticated: false })).toBe(true);
  });

  it("allows protected queries only after authentication is ready", () => {
    expect(canRunProtectedQueries({ loading: false, isAuthenticated: true })).toBe(true);
    expect(shouldShowLogin({ loading: false, isAuthenticated: true })).toBe(false);
  });
});
