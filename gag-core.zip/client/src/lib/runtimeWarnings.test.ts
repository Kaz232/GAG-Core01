import { describe, expect, it } from "vitest";
import { isBenignResizeObserverWarning } from "./runtimeWarnings";

describe("isBenignResizeObserverWarning", () => {
  it("reconhece apenas os avisos ResizeObserver não-fatais conhecidos", () => {
    expect(
      isBenignResizeObserverWarning(
        "ResizeObserver loop completed with undelivered notifications."
      )
    ).toBe(true);
    expect(isBenignResizeObserverWarning("ResizeObserver loop limit exceeded")).toBe(
      true
    );
  });

  it("preserva erros reais para o coletor de erros", () => {
    expect(isBenignResizeObserverWarning("Unexpected server error")).toBe(false);
    expect(isBenignResizeObserverWarning(undefined)).toBe(false);
  });
});
