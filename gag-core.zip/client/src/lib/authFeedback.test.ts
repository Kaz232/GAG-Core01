import { describe, expect, it } from "vitest";
import { getAuthenticationFeedback } from "./authFeedback";

describe("getAuthenticationFeedback", () => {
  it("explica uma falha relacionada com cookies ou estado OAuth sem expor detalhes internos", () => {
    const feedback = getAuthenticationFeedback("invalid oauth state 403");

    expect(feedback.tone).toBe("error");
    expect(feedback.message).toContain("cookies");
    expect(feedback.message).not.toContain("invalid oauth state");
  });

  it("mostra o estado de redirecionamento quando o início de sessão foi solicitado", () => {
    expect(getAuthenticationFeedback(null, true)).toMatchObject({ tone: "progress", title: "A abrir autenticação segura" });
  });

  it("mostra um erro seguro e acionável para sessões expiradas simuladas", () => {
    const feedback = getAuthenticationFeedback("Simulação local: sessão expirada.");
    expect(feedback.tone).toBe("error");
    expect(feedback.message).toContain("cookies");
  });
});
