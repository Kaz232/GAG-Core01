export function canRunProtectedQueries(input: {
  loading: boolean;
  isAuthenticated: boolean;
}): boolean {
  return !input.loading && input.isAuthenticated;
}

export function shouldShowLogin(input: {
  loading: boolean;
  isAuthenticated: boolean;
}): boolean {
  return !input.loading && !input.isAuthenticated;
}

export function shouldShowAuthLoading(loading: boolean): boolean {
  return loading;
}

// Kept as a tiny pure module so the authentication boundary can be tested
// without mounting the full dashboard or making network requests.
export type AuthGateState = Parameters<typeof canRunProtectedQueries>[0];
