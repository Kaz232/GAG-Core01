export type AuthSimulationMode = "NONE" | "COOKIE_BLOCKED" | "NETWORK" | "SESSION_EXPIRED";

export const AUTH_SIMULATION_OPTIONS: ReadonlyArray<{ value: AuthSimulationMode; label: string }> = [
  { value: "NONE", label: "Sem simulação" },
  { value: "COOKIE_BLOCKED", label: "Cookies ou estado OAuth bloqueados" },
  { value: "NETWORK", label: "Ligação indisponível" },
  { value: "SESSION_EXPIRED", label: "Sessão expirada" },
];

export function getSimulatedAuthError(mode: AuthSimulationMode): string | undefined {
  if (mode === "COOKIE_BLOCKED") return "Simulação local: cookies ou estado OAuth bloqueados.";
  if (mode === "NETWORK") return "Simulação local: falha de rede ao validar a sessão.";
  if (mode === "SESSION_EXPIRED") return "Simulação local: sessão expirada.";
  return undefined;
}
