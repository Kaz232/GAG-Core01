export type VoiceSettingsEvent = "toggle" | "apply";

export function getNextVoiceSettingsOpen(currentlyOpen: boolean, event: VoiceSettingsEvent): boolean {
  return event === "apply" ? false : !currentlyOpen;
}
