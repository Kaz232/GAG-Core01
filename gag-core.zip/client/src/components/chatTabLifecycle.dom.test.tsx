/**
 * @vitest-environment jsdom
 */
import { render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import React, { useState } from "react";
import ReactMarkdown from "react-markdown";
import { describe, expect, it, vi } from "vitest";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

function ChatNavigationHarness() {
  const [activeTab, setActiveTab] = useState("chat");

  return (
    <Tabs value={activeTab} onValueChange={setActiveTab}>
      <TabsList>
        <TabsTrigger value="dashboard">Dashboard</TabsTrigger>
        <TabsTrigger value="chat">Chat KIA</TabsTrigger>
      </TabsList>
      <TabsContent value="dashboard">Resumo operacional</TabsContent>
      <TabsContent value="chat">
        <div data-testid="chat-response">
          <ReactMarkdown>**Resposta carregada com segurança**</ReactMarkdown>
        </div>
      </TabsContent>
    </Tabs>
  );
}

describe("ciclo de vida do conteúdo Markdown do chat", () => {
  it("alterna os separadores e monta novamente a resposta sem erros de reconciliação", async () => {
    const user = userEvent.setup();
    const consoleError = vi.spyOn(console, "error").mockImplementation(() => undefined);

    render(<ChatNavigationHarness />);
    expect(screen.getByTestId("chat-response").textContent).toContain("Resposta carregada com segurança");

    await user.click(screen.getByRole("tab", { name: "Dashboard" }));
    expect(screen.queryByTestId("chat-response")).toBeNull();
    expect(screen.getByText("Resumo operacional")).not.toBeNull();

    await user.click(screen.getByRole("tab", { name: "Chat KIA" }));
    expect(screen.getByTestId("chat-response").textContent).toContain("Resposta carregada com segurança");
    expect(consoleError).not.toHaveBeenCalled();

    consoleError.mockRestore();
  });
});
