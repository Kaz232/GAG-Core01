import { useEffect, useRef, useState } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { startLogin } from "@/const";
import { trpc } from "@/lib/trpc";
import { canRunProtectedQueries } from "@/lib/authGate";
import { createChatMessage, type ChatMessage } from "@/lib/chatMessages";
import { getAuthenticationFeedback } from "@/lib/authFeedback";
import { AUTH_SIMULATION_OPTIONS, getSimulatedAuthError, type AuthSimulationMode } from "@/lib/authSimulation";
import { GAG_BRAND_ASSETS } from "@/lib/gagBrandAssets";
import { getNextVoiceSettingsOpen } from "@/lib/voiceSettings";
import { createVoiceOptions, useVoiceConversation } from "@/hooks/useVoiceConversation";
import { KIA_APPROVAL_CRITERIA, isKiaApprovalEligible, type KiaApprovalCriteria } from "../../../shared/kiaApproval";
import { KIA_PROCEDURE_MAX_BYTES, isKiaProcedureFilenameAllowed } from "../../../shared/kiaProcedure";
import { DOCUMENT_INTELLIGENCE_MAX_BYTES, type DocumentAnalysisResult } from "../../../shared/documentIntelligence";
import type { ScannerEconomicReportDraft } from "../../../shared/scannerEconomicAnalysis";
import { AGENT_AUTONOMY_LEVELS, AGENT_PERMISSION_CAPABILITIES, AGENT_SPEC_FIELDS, advanceKiaAgentDraft, createKiaAgentDraft, getKiaAgentDraftPrompt, isKiaAgentDraftComplete, type AgentAutonomyLevel, type AgentPermissionCapability, type KiaAgentDraft } from "../../../shared/agentFactoryFlow";
import { normalizeAgentTestContent, prepareAgentTestRequest } from "../../../shared/agentTestConversation";
import { filterAndSortOperationalTasks, type TaskPriority, type TaskStatus } from "../../../shared/taskWorkflow";
import { filterAndSortInternalExecutionEvents, getInternalExecutionEventLabel, getInternalExecutionEventTagClass, type InternalExecutionAuditDateOrder } from "../../../shared/internalExecutionPresentation";
import { PENDING_CORPUS_REVIEW_ARTIFACTS, getPendingCorpusReviewSummary } from "../../../shared/corpusReviewPresentation";
import { getEffectiveCorpusReviewDecisions, type CorpusReviewDecision } from "../../../shared/corpusReviewDecisions";
import { summarizeDashboardAgents } from "../../../shared/dashboardAgentSummary";
import type { KiaExecutionRoute } from "../../../shared/kiaExecutionRouter";
import { GAG_INTERNAL_OPERATION_SHORTCUTS, resolveGagInternalOperation, type GagInternalOperation } from "../../../shared/gagInternalOperations";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Checkbox } from "@/components/ui/checkbox";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import ReactMarkdown from "react-markdown";
import { toast } from "sonner";
import { LayoutDashboard, BookOpen, CheckSquare, Calendar, Users, MessageSquareCode, Bot, ShieldCheck, LogOut, Plus, Trash2, Send, LogIn, Mic, Volume2, X, Play, AudioLines, ChevronDown, CheckCircle2, FileText, Loader2, ClipboardCheck, Pencil, CircleCheckBig, CircleAlert } from "lucide-react";

type PendingKiaTask = {
  type: "prepare_task";
  title: string;
  description: string;
  periodLabel: string | null;
  timeLabel: string | null;
  priority: "Baixa" | "Média" | "Alta" | "Urgente";
  requiresConfirmation: true;
};

type PendingInternalExecutionPlan = {
  id: number;
  planHash: string;
  confirmationNonce: string;
  expiresAt: Date | string;
  source: "KIA" | "KAZ";
  action:
    | {
        type: "TASK_CREATE";
        brandId: number;
        title: string;
        description: string;
        priority: "Baixa" | "Média" | "Alta" | "Urgente";
        quarter: string;
        dueDate?: string | null;
      }
    | {
        type: "TASK_UPDATE_PRIORITY";
        brandId: number;
        taskId: number;
        priority: "Baixa" | "Média" | "Alta" | "Urgente";
      };
};

type KazOperationalReport = {
  total: number;
  pending: number;
  inProgress: number;
  completed: number;
  urgent: number;
  approvedKnowledgeCount: number;
};

type KiaReplyMode = "text" | "voice" | "both";

type KiaRoutingSummary = Pick<KiaExecutionRoute, "intent" | "capabilityId" | "capabilityLabel" | "status" | "requiresConfirmation" | "summary">;

type DocumentAnalysisPreview = DocumentAnalysisResult & {
  documentId: number;
  analysisId: number;
  reviewDecision: "PENDING" | "APPROVED" | "CHANGES_REQUESTED" | "REJECTED";
};

type DocumentReviewFilter = "ALL" | "PENDING" | "APPROVED" | "CHANGES_REQUESTED" | "REJECTED";
type DocumentAnalysisMode = "GENERAL" | "SCANNER";

function getInternalExecutionActionLabel(actionType: PendingInternalExecutionPlan["action"]["type"]): string {
  return actionType === "TASK_CREATE" ? "Criar tarefa" : "Atualizar prioridade";
}

function readFileAsBase64(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onerror = () => reject(new Error("Não foi possível ler o ficheiro neste dispositivo."));
    reader.onload = () => {
      const value = typeof reader.result === "string" ? reader.result : "";
      const base64 = value.includes(",") ? value.split(",", 2)[1] : value;
      if (!base64) reject(new Error("O ficheiro não contém conteúdo legível."));
      else resolve(base64);
    };
    reader.readAsDataURL(file);
  });
}

const EMPTY_KIA_APPROVAL: KiaApprovalCriteria = {
  textValidated: false,
  voiceValidated: false,
  contextValidated: false,
  safetyConfirmed: false,
};

function toKiaLanguage(language: string): "pt-PT" | "en-US" | "fr-FR" {
  if (language === "en-US") return "en-US";
  if (language === "fr-FR") return "fr-FR";
  return "pt-PT";
}

function buildConfirmedTaskDescription(task: PendingKiaTask): string {
  const timing = [task.periodLabel, task.timeLabel].filter(Boolean).join(" · ") || "por definir";
  return `${task.description}\n\nConfirmação do proprietário: quando ${timing}; prioridade ${task.priority}.`;
}

function getCurrentQuarter(): string {
  const now = new Date();
  return `Q${Math.floor(now.getMonth() / 3) + 1} ${now.getFullYear()}`;
}

export default function Home() {
  const { user, logout, loading, error: authError, isAuthenticated } = useAuth();
  const canQuery = canRunProtectedQueries({ loading, isAuthenticated });
  const utils = trpc.useUtils();
  const [activeTab, setActiveTab] = useState("dashboard");
  const [loginStarted, setLoginStarted] = useState(false);
  const [authSimulationMode, setAuthSimulationMode] = useState<AuthSimulationMode>("NONE");
  const [selectedCorpusArtifactIds, setSelectedCorpusArtifactIds] = useState<string[]>([]);
  const [corpusDecisionCandidate, setCorpusDecisionCandidate] = useState<CorpusReviewDecision | null>(null);
  const [corpusDecisionNote, setCorpusDecisionNote] = useState("");
  const voice = useVoiceConversation();
  const voiceOptions = createVoiceOptions(voice.voices);
  const selectedVoiceOptionId = voiceOptions.find((option) => option.voiceURI === voice.preferences.voiceURI)?.id ?? "";

  // Queries
  const statsQuery = trpc.gag.getDashboardStats.useQuery(undefined, {
    enabled: canQuery,
    refetchOnMount: "always",
    refetchOnWindowFocus: true,
  });
  const brandsQuery = trpc.gag.listBrands.useQuery(undefined, { enabled: canQuery });
  const knowledgeQuery = trpc.gag.listKnowledge.useQuery(undefined, { enabled: canQuery });
  const tasksQuery = trpc.gag.listTasks.useQuery(undefined, { enabled: canQuery });
  const calendarQuery = trpc.gag.listCalendar.useQuery(undefined, { enabled: canQuery });
  const leadsQuery = trpc.gag.listLeads.useQuery(undefined, { enabled: canQuery });
  const templatesQuery = trpc.gag.listTemplates.useQuery(undefined, { enabled: canQuery });
  const agentsQuery = trpc.gag.listAgents.useQuery(undefined, {
    enabled: canQuery,
    refetchOnMount: "always",
    refetchOnWindowFocus: true,
  });
  const kiaApprovalQuery = trpc.gag.getKiaApproval.useQuery(undefined, { enabled: canQuery });
  const kiaConversationQuery = trpc.gag.getKiaConversation.useQuery(undefined, { enabled: canQuery });
  const documentsQuery = trpc.gag.listDocuments.useQuery(undefined, { enabled: canQuery });
  const documentAnalysesQuery = trpc.gag.listDocumentAnalyses.useQuery(undefined, { enabled: canQuery });
  const scannerEconomicReportsQuery = trpc.gag.listScannerEconomicReports.useQuery(undefined, { enabled: canQuery });
  const internalExecutionTimelineQuery = trpc.gag.listInternalExecutionTimeline.useQuery(undefined, { enabled: canQuery });
  const internalExecutionAuditQuery = trpc.gag.verifyInternalExecutionAudit.useQuery(undefined, { enabled: canQuery });
  const corpusReviewDecisionsQuery = trpc.gag.listCorpusReviewDecisions.useQuery(undefined, { enabled: canQuery });

  // Seed mutation
  const seedMutation = trpc.gag.seedBrands.useMutation({
    onSuccess: () => {
      utils.gag.listBrands.invalidate();
      utils.gag.getDashboardStats.invalidate();
      toast.success("Marcas iniciais carregadas!");
    }
  });

  // Knowledge form state
  const [kBrandId, setKBrandId] = useState<string>("1");
  const [kTitle, setKTitle] = useState("");
  const [kCategory, setKCategory] = useState("Estratégia");
  const [kContent, setKContent] = useState("");
  const [procedureFile, setProcedureFile] = useState<File | null>(null);
  const [editingKnowledgeId, setEditingKnowledgeId] = useState<number | null>(null);
  const [knowledgeDeleteCandidateId, setKnowledgeDeleteCandidateId] = useState<number | null>(null);
  const [documentFile, setDocumentFile] = useState<File | null>(null);
  const [documentIntent, setDocumentIntent] = useState("Analisar e organizar este documento para revisão interna.");
  const [documentResult, setDocumentResult] = useState<DocumentAnalysisPreview | null>(null);
  const [documentReviewNote, setDocumentReviewNote] = useState("");
  const [documentReviewFilter, setDocumentReviewFilter] = useState<DocumentReviewFilter>("ALL");
  const [documentAnalysisMode, setDocumentAnalysisMode] = useState<DocumentAnalysisMode>("GENERAL");
  const [scannerQuestion, setScannerQuestion] = useState("");
  const [scannerPeriod, setScannerPeriod] = useState("");
  const [scannerGeography, setScannerGeography] = useState("Angola");
  const [scannerIntendedDecision, setScannerIntendedDecision] = useState("");
  const [scannerReport, setScannerReport] = useState<ScannerEconomicReportDraft | null>(null);

  const visibleDocumentAnalyses = (documentAnalysesQuery.data ?? []).filter((analysis) => (
    documentReviewFilter === "ALL" || analysis.reviewDecision === documentReviewFilter
  ));
  const dashboardAgentSummary = summarizeDashboardAgents(agentsQuery.data ?? []);
  const dashboardAgentsLoading = canQuery && (agentsQuery.isLoading || !agentsQuery.data);

  const openInternalOperation = (operation: GagInternalOperation) => {
    setActiveTab(operation.targetTab);
    if (operation.id === "scanner.document.analyze") {
      setDocumentAnalysisMode("SCANNER");
    }
    toast.info(`${operation.label}: abra o fluxo interno e confirme os dados necessários. Nenhuma ação foi iniciada automaticamente.`);
  };

  const openDocumentAnalysis = (analysis: NonNullable<typeof documentAnalysesQuery.data>[number]) => {
    try {
      const parsedAnalysis = JSON.parse(analysis.analysisJson) as DocumentAnalysisResult;
      setDocumentResult({
        ...parsedAnalysis,
        documentId: analysis.documentId,
        analysisId: analysis.id,
        reviewDecision: analysis.reviewDecision,
      });
      setDocumentReviewNote(analysis.reviewNote ?? "");
    } catch {
      toast.error("Não foi possível abrir este rascunho. O conteúdo estruturado precisa de revisão técnica.");
    }
  };

  const uploadAndAnalyzeDocumentMutation = trpc.gag.uploadAndAnalyzeDocument.useMutation({
    onSuccess: (result) => {
      setDocumentResult({ ...result.analysis, documentId: result.documentId, analysisId: result.analysisId, reviewDecision: "PENDING" });
      setDocumentFile(null);
      setDocumentReviewNote("");
      utils.gag.listDocuments.invalidate();
      utils.gag.listDocumentAnalyses.invalidate();
      toast.success("Análise concluída como rascunho interno. A revisão humana continua obrigatória.");
    },
    onError: (error) => toast.error(error.message),
  });

  const runScannerDocumentAnalysisMutation = trpc.gag.runScannerDocumentAnalysis.useMutation({
    onSuccess: (result) => {
      setDocumentResult({ ...result.analysis, documentId: result.documentId, analysisId: result.analysisId, reviewDecision: "PENDING" });
      setScannerReport(result.report);
      setDocumentFile(null);
      setDocumentReviewNote("");
      utils.gag.listDocuments.invalidate();
      utils.gag.listDocumentAnalyses.invalidate();
      utils.gag.listScannerEconomicReports.invalidate();
      toast.success("O Scanner criou um rascunho interno com proveniência. A revisão humana permanece obrigatória.");
    },
    onError: (error) => toast.error(error.message),
  });

  const reviewDocumentAnalysisMutation = trpc.gag.reviewDocumentAnalysis.useMutation({
    onSuccess: (result) => {
      setDocumentResult((current) => current ? { ...current, reviewDecision: result.decision } : current);
      utils.gag.listDocumentAnalyses.invalidate();
      toast.success(result.exportAllowed ? "Aprovação registada. A exportação interna foi desbloqueada." : "Decisão humana registada. A exportação permanece bloqueada.");
    },
    onError: (error) => toast.error(error.message),
  });

  const decideCorpusReviewArtifactsMutation = trpc.gag.decideCorpusReviewArtifacts.useMutation({
    onSuccess: (result) => {
      utils.gag.listCorpusReviewDecisions.invalidate();
      setSelectedCorpusArtifactIds([]);
      setCorpusDecisionCandidate(null);
      setCorpusDecisionNote("");
      toast.success(result.decision === "APPROVED"
        ? `${result.count} artefacto(s) aprovado(s) internamente. Nenhuma ação externa foi executada.`
        : `${result.count} artefacto(s) rejeitado(s). O histórico e as fontes foram preservados.`);
    },
    onError: (error) => toast.error(error.message),
  });

  const exportApprovedDocumentAnalysisMutation = trpc.gag.exportApprovedDocumentAnalysis.useMutation({
    onSuccess: (result) => {
      const bytes = Uint8Array.from(window.atob(result.reportBase64), (character) => character.charCodeAt(0));
      const blob = new Blob([bytes], { type: result.contentType });
      const url = URL.createObjectURL(blob);
      const link = window.document.createElement("a");
      link.href = url;
      link.download = result.filename;
      link.click();
      URL.revokeObjectURL(url);
      toast.success("Relatório interno PDF exportado. Nenhuma ação externa foi executada.");
    },
    onError: (error) => toast.error(error.message),
  });

  const handleDocumentAnalysis = async () => {
    if (!documentFile) {
      toast.error("Selecione um documento antes de iniciar a análise.");
      return;
    }
    if (documentFile.size > DOCUMENT_INTELLIGENCE_MAX_BYTES) {
      toast.error("O documento deve ter no máximo 6 MB.");
      return;
    }
    if (documentAnalysisMode === "SCANNER" && (!scannerQuestion.trim() || !scannerPeriod.trim() || !scannerGeography.trim() || !scannerIntendedDecision.trim())) {
      toast.error("No modo Scanner, declare pergunta, período, geografia e decisão interna pretendida antes de analisar.");
      return;
    }
    try {
      const base64 = await readFileAsBase64(documentFile);
      if (documentAnalysisMode === "SCANNER") {
        runScannerDocumentAnalysisMutation.mutate({
          filename: documentFile.name,
          mimeType: documentFile.type || "application/octet-stream",
          base64,
          scope: {
            question: scannerQuestion.trim(),
            period: scannerPeriod.trim(),
            geography: scannerGeography.trim(),
            intendedDecision: scannerIntendedDecision.trim(),
          },
        });
        return;
      }
      uploadAndAnalyzeDocumentMutation.mutate({
        filename: documentFile.name,
        mimeType: documentFile.type || "application/octet-stream",
        base64,
        intent: documentIntent.trim() || "Analisar este documento para revisão interna.",
      });
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Não foi possível preparar o documento.");
    }
  };

  const addKnowledgeMutation = trpc.gag.addKnowledge.useMutation({
    onSuccess: () => {
      utils.gag.listKnowledge.invalidate();
      toast.success("Conhecimento adicionado com sucesso!");
      setKTitle("");
      setKContent("");
    }
  });

  const deleteKnowledgeMutation = trpc.gag.deleteKnowledge.useMutation({
    onSuccess: () => {
      utils.gag.listKnowledge.invalidate();
      setKnowledgeDeleteCandidateId(null);
      toast.success("Conhecimento removido.");
    }
  });

  const updateKnowledgeMutation = trpc.gag.updateKnowledge.useMutation({
    onSuccess: () => {
      utils.gag.listKnowledge.invalidate();
      setEditingKnowledgeId(null);
      setProcedureFile(null);
      setKTitle("");
      setKContent("");
      toast.success("Conhecimento atualizado após confirmação.");
    },
    onError: (error) => toast.error(error.message),
  });

  const uploadKiaProcedureMutation = trpc.gag.uploadKiaProcedure.useMutation({
    onSuccess: () => {
      utils.gag.listKnowledge.invalidate();
      toast.success("Procedimento real carregado na Knowledge Base da KIA.");
      setProcedureFile(null);
      setKTitle("");
      setKContent("");
    },
    onError: (error) => toast.error(error.message),
  });

  const [approvalDraft, setApprovalDraft] = useState<KiaApprovalCriteria>(EMPTY_KIA_APPROVAL);
  useEffect(() => {
    if (kiaApprovalQuery.data?.criteria) setApprovalDraft(kiaApprovalQuery.data.criteria);
  }, [kiaApprovalQuery.data]);

  const updateKiaApprovalMutation = trpc.gag.updateKiaApproval.useMutation({
    onSuccess: (result) => {
      utils.gag.getKiaApproval.invalidate();
      toast.success(result.unlocked ? "Critérios confirmados. A Agent Factory pode preparar rascunhos sob aprovação explícita." : "Critérios de validação atualizados.");
    },
    onError: (error) => toast.error(error.message),
  });

  const handleProcedureFile = async (file: File | undefined) => {
    if (!file) return;
    if (!isKiaProcedureFilenameAllowed(file.name)) {
      toast.error("Use um ficheiro TXT, MD, CSV ou JSON para manter o procedimento pesquisável pela KIA.");
      return;
    }
    if (file.size > KIA_PROCEDURE_MAX_BYTES) {
      toast.error("O procedimento deve ter no máximo 700 KB.");
      return;
    }
    try {
      const content = await file.text();
      if (!content.trim()) {
        toast.error("O procedimento selecionado está vazio.");
        return;
      }
      setProcedureFile(file);
      setKTitle((current) => current || file.name.replace(/\.[^.]+$/, ""));
      setKCategory("Procedimento operacional");
      setKContent(content);
      toast.success("Procedimento lido. Reveja os dados e carregue-o na Knowledge Base.");
    } catch {
      toast.error("Não foi possível ler este ficheiro no dispositivo.");
    }
  };

  // Task form state
  const [tBrandId, setTBrandId] = useState<string>("1");
  const [tTitle, setTTitle] = useState("");
  const [tDesc, setTDesc] = useState("");
  const [tStatus, setTStatus] = useState<"Pendente" | "Em Curso" | "Concluído">("Pendente");
  const [tPriority, setTPriority] = useState<"Baixa" | "Média" | "Alta" | "Urgente">("Média");
  const [tQuarter, setTQuarter] = useState(getCurrentQuarter);
  const [tDueDate, setTDueDate] = useState("");
  const [editingTaskId, setEditingTaskId] = useState<number | null>(null);
  const [taskDeleteCandidateId, setTaskDeleteCandidateId] = useState<number | null>(null);
  const [taskStatusFilter, setTaskStatusFilter] = useState<TaskStatus | "Todas">("Todas");
  const [taskPriorityFilter, setTaskPriorityFilter] = useState<TaskPriority | "Todas">("Todas");

  const addTaskMutation = trpc.gag.upsertTask.useMutation({
    onSuccess: () => {
      utils.gag.listTasks.invalidate();
      utils.gag.getDashboardStats.invalidate();
      toast.success("Tarefa guardada no backlog!");
      setTTitle("");
      setTDesc("");
      setTDueDate("");
      setEditingTaskId(null);
    }
  });

  const prepareKiaInternalTaskPlanMutation = trpc.gag.createInternalTaskPlan.useMutation({
    onSuccess: (plan) => {
      setPendingInternalExecutionPlan(plan as PendingInternalExecutionPlan);
      toast.success("Plano interno preparado. Reveja o resumo e confirme uma única vez para executar.");
      utils.gag.listInternalExecutionTimeline.invalidate();
      utils.gag.verifyInternalExecutionAudit.invalidate();
    },
    onError: (error) => toast.error(error.message),
  });

  const confirmInternalExecutionPlanMutation = trpc.gag.confirmInternalExecutionPlan.useMutation({
    onSuccess: (result) => {
      setPendingKiaTask(null);
      setIsEditingPendingTask(false);
      setPendingInternalExecutionPlan(null);
      utils.gag.listTasks.invalidate();
      utils.gag.getDashboardStats.invalidate();
      utils.gag.listInternalExecutionTimeline.invalidate();
      utils.gag.verifyInternalExecutionAudit.invalidate();
      toast.success(result.alreadyExecuted ? "Este plano já tinha sido executado. Nenhuma tarefa duplicada foi criada." : "Tarefa interna executada e registada no trilho de auditoria.");
    },
    onError: (error) => toast.error(error.message),
  });

  const cancelInternalExecutionPlanMutation = trpc.gag.cancelInternalExecutionPlan.useMutation({
    onSuccess: () => {
      setPendingInternalExecutionPlan(null);
      utils.gag.listInternalExecutionTimeline.invalidate();
      utils.gag.verifyInternalExecutionAudit.invalidate();
      toast.info("Plano interno cancelado. Nenhuma tarefa foi executada.");
    },
    onError: (error) => toast.error(error.message),
  });

  const deleteTaskMutation = trpc.gag.deleteTask.useMutation({
    onSuccess: () => {
      utils.gag.listTasks.invalidate();
      utils.gag.getDashboardStats.invalidate();
      setTaskDeleteCandidateId(null);
      toast.success("Tarefa eliminada.");
    }
  });

  // Chat RAG state
  const [chatMessage, setChatMessage] = useState("");
  const [chatBrandId, setChatBrandId] = useState<string>("all");
  const [chatHistory, setChatHistory] = useState<ChatMessage[]>([]);
  const chatMessageSequence = useRef(0);
  const [pendingKiaTask, setPendingKiaTask] = useState<PendingKiaTask | null>(null);
  const [pendingInternalExecutionPlan, setPendingInternalExecutionPlan] = useState<PendingInternalExecutionPlan | null>(null);
  const [kazOperationalReport, setKazOperationalReport] = useState<KazOperationalReport | null>(null);
  const [lastKiaRouting, setLastKiaRouting] = useState<KiaRoutingSummary | null>(null);
  const lastKiaOperation = lastKiaRouting ? resolveGagInternalOperation(lastKiaRouting) : null;
  const [auditSearch, setAuditSearch] = useState("");
  const [auditDateOrder, setAuditDateOrder] = useState<InternalExecutionAuditDateOrder>("newest");
  const [isEditingPendingTask, setIsEditingPendingTask] = useState(false);
  const [pendingAgentDraft, setPendingAgentDraft] = useState<KiaAgentDraft | null>(null);
  const [isEditingAgentDraft, setIsEditingAgentDraft] = useState(false);
  const [agentAutonomyLevel, setAgentAutonomyLevel] = useState<AgentAutonomyLevel>("Assistido");
  const [agentPermissions, setAgentPermissions] = useState<AgentPermissionCapability[]>(["READ"]);
  const [agentTestInput, setAgentTestInput] = useState("");
  const [agentTestHistories, setAgentTestHistories] = useState<Record<number, Array<{ role: "owner" | "agent"; content: string }>>>({});
  const [selectedTestAgentId, setSelectedTestAgentId] = useState<number | null>(null);
  const [activationCandidateId, setActivationCandidateId] = useState<number | null>(null);
  const [replyMode, setReplyMode] = useState<KiaReplyMode>("both");
  const [languageMode, setLanguageMode] = useState<"auto" | "manual">("auto");
  const [isVoiceSettingsOpen, setIsVoiceSettingsOpen] = useState(false);

  useEffect(() => {
    if (!kiaConversationQuery.data) return;
    const restored = kiaConversationQuery.data.map((message, index) => createChatMessage(index + 1, message.role, message.content));
    chatMessageSequence.current = restored.length;
    setChatHistory(restored);
  }, [kiaConversationQuery.data]);

  const clearKiaConversationMutation = trpc.gag.clearKiaConversation.useMutation({
    onSuccess: () => {
      setChatHistory([]);
      setPendingKiaTask(null);
      setKazOperationalReport(null);
      setPendingAgentDraft(null);
      setIsEditingPendingTask(false);
      setIsEditingAgentDraft(false);
      utils.gag.getKiaConversation.invalidate();
      toast.success("Contexto da conversa limpo. Nenhum dado operacional foi alterado.");
    },
    onError: (error) => toast.error(error.message),
  });

  const appendKiaConversationMutation = trpc.gag.appendKiaConversation.useMutation({
    onSuccess: () => utils.gag.getKiaConversation.invalidate(),
    onError: (error) => toast.error(error.message),
  });

  const chatMutation = trpc.gag.ragChat.useMutation({
    onSuccess: (data) => {
      setChatHistory(prev => [...prev, createChatMessage(++chatMessageSequence.current, "assistant", data.reply)]);
      if ("routing" in data && data.routing) setLastKiaRouting(data.routing as KiaRoutingSummary);
      if ("routing" in data && data.routing?.capabilityId === "economic.scanner") {
        setActiveTab("knowledge");
        toast.info("O painel Document Intelligence foi aberto no modo Scanner. Selecione um documento autorizado e reveja os campos antes de iniciar a análise.");
      }
      utils.gag.getKiaConversation.invalidate();
      if (languageMode === "auto") voice.updatePreferences({ language: data.language });
      if (replyMode !== "text") voice.speak(data.reply, replyMode === "voice", data.language);
      if (data.taskDraft) {
        setPendingKiaTask(data.taskDraft);
        setIsEditingPendingTask(false);
      }
      if (data.taskCancelled) {
        setPendingKiaTask(null);
        setIsEditingPendingTask(false);
        toast.info("A ação pendente foi cancelada. Nenhuma tarefa foi gravada.");
      }
      if (data.agentFactoryAction === "blocked") {
        toast.info("A Agent Factory continua bloqueada até a validação explícita dos quatro critérios.");
      }
      if (data.agentFactoryAction === "start_draft") {
        const draft = createKiaAgentDraft();
        setPendingAgentDraft(draft);
        setIsEditingAgentDraft(false);
        const prompt = getKiaAgentDraftPrompt(draft);
        setChatHistory(prev => [...prev, createChatMessage(++chatMessageSequence.current, "assistant", prompt)]);
        appendKiaConversationMutation.mutate({ entries: [{ role: "assistant", content: prompt }] });
        if (replyMode !== "text") voice.speak(prompt, replyMode === "voice", data.language);
      }
      if (data.agentFactoryAction === "draft_created") {
        setPendingAgentDraft(null);
        setIsEditingAgentDraft(false);
        utils.gag.listAgents.invalidate();
        utils.gag.getDashboardStats.invalidate();
        setActiveTab("agents");
        const agentName = "createdAgent" in data && data.createdAgent ? data.createdAgent.name : "O agente";
        toast.success(`${agentName} foi criado como RASCUNHO e está disponível na Agent Factory.`);
      }
      if ("executionPlan" in data && data.executionPlan) {
        setPendingInternalExecutionPlan(data.executionPlan as PendingInternalExecutionPlan);
        toast.info("O Kaz preparou um plano interno. Reveja-o e confirme uma única vez no Kernel.");
      }
      if ("kazDelegated" in data && data.kazDelegated) {
        setKazOperationalReport(("kazReport" in data && data.kazReport ? data.kazReport : null) as KazOperationalReport | null);
        utils.gag.listTasks.invalidate();
        utils.gag.listInternalExecutionTimeline.invalidate();
        utils.gag.verifyInternalExecutionAudit.invalidate();
      }
    },
    onError: (err) => {
      toast.error("Erro no chat: " + err.message);
    }
  });

  const handleSendChat = (voiceTranscript?: string) => {
    const userMsg = (voiceTranscript ?? chatMessage).trim();
    if (!userMsg) return;
    setChatMessage("");
    const nextHistory = [...chatHistory, createChatMessage(++chatMessageSequence.current, "user", userMsg)];
    setChatHistory(nextHistory);
    if (pendingAgentDraft && /^(cancelar|cancela|cancelar rascunho)$/i.test(userMsg)) {
      setPendingAgentDraft(null);
      setIsEditingAgentDraft(false);
      const response = "Rascunho cancelado por si. Nenhum agente foi criado.";
      setChatHistory(prev => [...prev, createChatMessage(++chatMessageSequence.current, "assistant", response)]);
      appendKiaConversationMutation.mutate({ entries: [{ role: "user", content: userMsg }, { role: "assistant", content: response }] });
      if (replyMode !== "text") voice.speak(response, replyMode === "voice", toKiaLanguage(voice.preferences.language));
      return;
    }
    if (pendingAgentDraft?.stage === "collecting") {
      const nextDraft = advanceKiaAgentDraft(pendingAgentDraft, userMsg);
      const prompt = getKiaAgentDraftPrompt(nextDraft);
      setPendingAgentDraft(nextDraft);
      setChatHistory(prev => [...prev, createChatMessage(++chatMessageSequence.current, "assistant", prompt)]);
      appendKiaConversationMutation.mutate({ entries: [{ role: "user", content: userMsg }, { role: "assistant", content: prompt }] });
      if (replyMode !== "text") voice.speak(prompt, replyMode === "voice", toKiaLanguage(voice.preferences.language));
      return;
    }
    chatMutation.mutate({
      message: userMsg,
      brandId: chatBrandId === "all" ? undefined : Number(chatBrandId),
      language: languageMode === "manual" ? toKiaLanguage(voice.preferences.language) : undefined,
      pendingTask: pendingKiaTask ?? undefined,
    });
  };

  const cancelPendingKiaTask = () => {
    setPendingKiaTask(null);
    setIsEditingPendingTask(false);
    toast.info("Pré-visualização cancelada. Nenhuma tarefa foi gravada.");
  };

  const preparePendingKiaTaskForKernel = () => {
    if (!pendingKiaTask) return;
    const internalBrand = (brandsQuery.data ?? []).find((brand) => brand.entityType === "internal_operation");
    if (!internalBrand) {
      toast.error("A proposta foi bloqueada porque a operação interna GAG ainda não está disponível.");
      return;
    }
    prepareKiaInternalTaskPlanMutation.mutate({
      source: "KIA",
      brandId: internalBrand.id,
      title: pendingKiaTask.title,
      description: buildConfirmedTaskDescription(pendingKiaTask),
      priority: pendingKiaTask.priority,
      quarter: getCurrentQuarter(),
      dueDate: null,
    });
  };

  const confirmPendingInternalExecutionPlan = () => {
    if (!pendingInternalExecutionPlan) return;
    confirmInternalExecutionPlanMutation.mutate({
      planId: pendingInternalExecutionPlan.id,
      planHash: pendingInternalExecutionPlan.planHash,
      confirmationNonce: pendingInternalExecutionPlan.confirmationNonce,
    });
  };

  const cancelPendingInternalExecutionPlan = () => {
    if (!pendingInternalExecutionPlan) return;
    cancelInternalExecutionPlanMutation.mutate({ planId: pendingInternalExecutionPlan.id });
  };

  const handleVoiceTranscript = (transcript: string) => {
    handleSendChat(transcript);
  };

  const createAgentMutation = trpc.gag.createAgent.useMutation({
    onSuccess: () => {
      utils.gag.listAgents.invalidate();
      utils.gag.getDashboardStats.invalidate();
      setPendingAgentDraft(null);
      setIsEditingAgentDraft(false);
      setAgentAutonomyLevel("Assistido");
      setAgentPermissions(["READ"]);
      setActiveTab("agents");
      toast.success("Agente criado exclusivamente como RASCUNHO. Teste-o antes de qualquer ativação.");
    },
    onError: (error) => toast.error(error.message),
  });

  const updateAgentStatusMutation = trpc.gag.updateAgentStatus.useMutation({
    onSuccess: (result) => {
      utils.gag.listAgents.invalidate();
      utils.gag.getDashboardStats.invalidate();
      setActivationCandidateId(null);
      toast.success(`Estado do agente atualizado para ${result.status}.`);
    },
    onError: (error) => toast.error(error.message),
  });

  const testAgentMutation = trpc.gag.testAgent.useMutation({
    onSuccess: (data, variables) => {
      const reply = normalizeAgentTestContent(data.reply);
      setAgentTestHistories((current) => ({
        ...current,
        [variables.id]: [...(current[variables.id] ?? []), { role: "agent", content: reply || "Sem resposta de teste gerada." }],
      }));
      if (data.executionPlan) {
        setPendingInternalExecutionPlan(data.executionPlan as PendingInternalExecutionPlan);
        toast.info("O Kaz preparou um plano interno. Abra o Chat KIA para a confirmação final.");
      }
      if (replyMode !== "text") voice.speak(reply || "Sem resposta de teste gerada.", replyMode === "voice", toKiaLanguage(voice.preferences.language));
    },
    onError: (error) => toast.error(error.message),
  });

  const handleAgentTest = (agentId: number, voiceTranscript?: string) => {
    const message = (voiceTranscript ?? agentTestInput).trim();
    if (!message) return;
    const nextHistory = [...(agentTestHistories[agentId] ?? []), { role: "owner" as const, content: message }];
    const preparedRequest = prepareAgentTestRequest({ message, history: nextHistory });
    if (!preparedRequest) return;

    setAgentTestInput("");
    setAgentTestHistories((current) => ({ ...current, [agentId]: preparedRequest.history }));
    if (preparedRequest.wasTruncated) {
      toast.info("Para manter o teste estável, cada mensagem foi limitada a 6000 caracteres e foram preservadas apenas as 12 entradas mais recentes.");
    }
    testAgentMutation.mutate({ id: agentId, message: preparedRequest.message, history: preparedRequest.history });
  };

  const stats = statsQuery.data;
  const brands = brandsQuery.data || [];
  const knowledge = knowledgeQuery.data || [];
  const tasks = tasksQuery.data || [];
  const calendar = calendarQuery.data || [];
  const leads = leadsQuery.data || [];
  const templates = templatesQuery.data || [];
  const agents = agentsQuery.data || [];
  const testableAgents = agents.filter((agent) => agent.status === "Em Teste");
  const selectedTestAgent = testableAgents.find((agent) => agent.id === selectedTestAgentId) ?? testableAgents[0] ?? null;
  const selectedAgentTestHistory = selectedTestAgent ? agentTestHistories[selectedTestAgent.id] ?? [] : [];
  const visibleTasks = filterAndSortOperationalTasks(tasks, taskStatusFilter, taskPriorityFilter);
  const visibleInternalExecutionEvents = filterAndSortInternalExecutionEvents(internalExecutionTimelineQuery.data?.events ?? [], auditSearch, auditDateOrder);
  const simulatedAuthError = getSimulatedAuthError(authSimulationMode);
  const authenticationFeedback = getAuthenticationFeedback(simulatedAuthError ?? authError?.message, loginStarted);
  const corpusReviewDecisionsByArtifact = getEffectiveCorpusReviewDecisions(corpusReviewDecisionsQuery.data ?? []);
  const pendingCorpusReviewArtifacts = PENDING_CORPUS_REVIEW_ARTIFACTS.filter((artifact) => !corpusReviewDecisionsByArtifact[artifact.id]);
  const pendingCorpusReviewSummary = {
    ...getPendingCorpusReviewSummary(),
    total: pendingCorpusReviewArtifacts.length,
    workflows: pendingCorpusReviewArtifacts.filter((artifact) => artifact.kind === "WORKFLOW").length,
    templates: pendingCorpusReviewArtifacts.filter((artifact) => artifact.kind === "TEMPLATE").length,
    sourceCount: pendingCorpusReviewArtifacts.reduce((total, artifact) => total + artifact.sourceCount, 0),
  };
  const selectedCorpusReviewArtifacts = pendingCorpusReviewArtifacts.filter((artifact) => selectedCorpusArtifactIds.includes(artifact.id));
  const allPendingCorpusArtifactsSelected = pendingCorpusReviewArtifacts.length > 0 && selectedCorpusReviewArtifacts.length === pendingCorpusReviewArtifacts.length;

  const toggleCorpusArtifactSelection = (artifactId: string, checked: boolean) => {
    setSelectedCorpusArtifactIds((current) => checked
      ? Array.from(new Set([...current, artifactId]))
      : current.filter((id) => id !== artifactId));
  };

  const toggleAllPendingCorpusArtifacts = (checked: boolean) => {
    setSelectedCorpusArtifactIds(checked ? pendingCorpusReviewArtifacts.map((artifact) => artifact.id) : []);
  };

  const requestCorpusDecision = (decision: CorpusReviewDecision) => {
    if (selectedCorpusReviewArtifacts.length === 0) {
      toast.error("Selecione pelo menos um workflow ou template pendente antes de continuar.");
      return;
    }
    setCorpusDecisionCandidate(decision);
  };

  const confirmCorpusDecision = () => {
    if (!corpusDecisionCandidate || selectedCorpusReviewArtifacts.length === 0) return;
    decideCorpusReviewArtifactsMutation.mutate({
      artifactIds: selectedCorpusReviewArtifacts.map((artifact) => artifact.id),
      decision: corpusDecisionCandidate,
      decisionNote: corpusDecisionNote.trim() || undefined,
    });
  };

  if (loading) {
    return (
      <div className="gag-auth-shell min-h-screen bg-slate-950 text-slate-100 flex items-center justify-center p-6">
          <div className="text-center">
            <div className="mx-auto mb-4 h-10 w-10 animate-spin rounded-full border-2 border-slate-700 border-t-blue-500" />
          <p className="text-sm text-slate-300" role="status" aria-live="polite">A verificar a sessão...</p>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return (
      <div className="gag-auth-shell min-h-screen bg-slate-950 text-slate-100 flex items-center justify-center p-6">
        <Card className="gag-auth-card w-full max-w-md bg-slate-900 border-slate-800">
          <CardHeader className="space-y-5">
            <div className="rounded-xl bg-white p-3 ring-1 ring-white/10">
              <img
                src={GAG_BRAND_ASSETS.horizontalLogo}
                alt="GAG Visual — Soluções com propósito, inovação com raízes."
                className="h-20 w-full object-contain sm:h-24"
              />
            </div>
            <CardTitle>Entrar no GAG Core</CardTitle>
            <CardDescription>Esta plataforma é privada e requer autenticação do proprietário.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div
              role={authenticationFeedback.tone === "error" ? "alert" : "status"}
              aria-live="polite"
              className={`rounded-lg border p-3 text-sm ${authenticationFeedback.tone === "error" ? "border-rose-800 bg-rose-950/40 text-rose-100" : authenticationFeedback.tone === "progress" ? "border-blue-800 bg-blue-950/40 text-blue-100" : "border-slate-700 bg-slate-950/60 text-slate-200"}`}
            >
              <p className="flex items-center gap-2 font-medium">
                {authenticationFeedback.tone === "error" ? <CircleAlert className="h-4 w-4 shrink-0" /> : authenticationFeedback.tone === "progress" ? <Loader2 className="h-4 w-4 shrink-0 animate-spin" /> : <ShieldCheck className="h-4 w-4 shrink-0" />}
                {authenticationFeedback.title}
              </p>
              <p className="mt-1 text-xs leading-5 opacity-90">{authenticationFeedback.message}</p>
            </div>
            <div className="rounded-lg border border-dashed border-slate-700 bg-slate-950/50 p-3" aria-label="Validação visual da autenticação">
              <label className="text-xs font-medium text-slate-200" htmlFor="auth-feedback-simulation">Validar feedback visual</label>
              <Select value={authSimulationMode} onValueChange={(value) => setAuthSimulationMode(value as AuthSimulationMode)}>
                <SelectTrigger id="auth-feedback-simulation" className="mt-2 border-slate-700 bg-slate-900 text-slate-100"><SelectValue /></SelectTrigger>
                <SelectContent>
                  {AUTH_SIMULATION_OPTIONS.map((option) => <SelectItem key={option.value} value={option.value}>{option.label}</SelectItem>)}
                </SelectContent>
              </Select>
              <p className="mt-2 text-xs leading-5 text-slate-400">A simulação altera apenas a mensagem apresentada nesta página. Não chama OAuth, não altera cookies e não concede acesso.</p>
            </div>
            <Button
              onClick={() => {
                setLoginStarted(true);
                startLogin();
              }}
              disabled={loginStarted}
              className="w-full bg-blue-600 hover:bg-blue-700 disabled:bg-blue-900"
            >
              {loginStarted ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <LogIn className="mr-2 h-4 w-4" />}
              {loginStarted ? "A preparar validação segura..." : "Entrar com a minha conta"}
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="gag-core-shell min-h-screen bg-slate-950 text-slate-100 flex flex-col">
      {/* Header */}
      <header className="gag-core-header sticky top-0 z-50 flex flex-col gap-3 border-b border-slate-800 bg-slate-900/80 px-4 py-3 backdrop-blur sm:flex-row sm:items-center sm:justify-between sm:px-6 sm:py-4">
        <div className="flex min-w-0 items-center gap-3">
          <div className="flex h-11 w-[76px] shrink-0 items-center justify-center overflow-hidden rounded-xl bg-white p-1 shadow-lg shadow-blue-500/20 ring-1 ring-white/10 sm:h-12 sm:w-[88px]">
            <img
              src={GAG_BRAND_ASSETS.simplifiedLogo}
              alt="GAG Visual"
              className="h-full w-full object-contain"
            />
          </div>
          <div className="min-w-0">
            <h1 className="flex flex-wrap items-center gap-2 text-base font-bold tracking-tight sm:text-lg">
              GAG CORE <Badge variant="outline" className="border-blue-500 text-blue-400">Núcleo Interno GAG</Badge>
            </h1>
            <p className="text-xs leading-snug text-slate-400">Plataforma exclusiva de gestão operacional e marketing da GAG</p>
          </div>
        </div>

        <div className="flex w-full items-center justify-end gap-2 sm:w-auto sm:gap-4">
          <div className="text-right hidden sm:block">
            <p className="text-sm font-medium">{user?.name || "Proprietário"}</p>
            <p className="text-xs text-emerald-400 flex items-center gap-1 justify-end">
              <ShieldCheck className="w-3 h-3" /> Acesso Total (Admin)
            </p>
          </div>
          {brands.length === 0 && (
            <Button size="sm" variant="default" onClick={() => seedMutation.mutate()} className="bg-blue-600 hover:bg-blue-700">
              Inicializar Núcleo GAG
            </Button>
          )}
          <Button size="sm" variant="outline" onClick={() => logout()} className="border-slate-700 px-3 hover:bg-slate-800" aria-label="Sair do GAG Core">
            <LogOut className="h-4 w-4 sm:mr-2" /> <span className="hidden sm:inline">Sair</span>
          </Button>
        </div>
      </header>

      {/* Main Content */}
      <main className="gag-core-main mx-auto w-full max-w-7xl flex-1 p-3 sm:p-5 lg:p-6">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="min-w-0 space-y-4 sm:space-y-6">
          <div>
          <TabsList aria-label="Secções do GAG Core" className="gag-core-nav flex h-auto min-h-11 w-full max-w-full flex-nowrap justify-start gap-1 overflow-x-auto border border-slate-800 bg-slate-900 p-1 pr-6">
            <TabsTrigger value="dashboard" className="!flex-none text-slate-200 hover:bg-slate-800 hover:text-white data-[state=active]:bg-blue-600 data-[state=active]:text-white">
              <LayoutDashboard className="w-4 h-4 mr-2" /> Dashboard
            </TabsTrigger>
            <TabsTrigger value="knowledge" className="!flex-none text-slate-200 hover:bg-slate-800 hover:text-white data-[state=active]:bg-blue-600 data-[state=active]:text-white">
              <BookOpen className="w-4 h-4 mr-2" /> Conhecimento (RAG)
            </TabsTrigger>
            <TabsTrigger value="chat" className="!flex-none text-slate-200 hover:bg-slate-800 hover:text-white data-[state=active]:bg-blue-600 data-[state=active]:text-white">
              <MessageSquareCode className="w-4 h-4 mr-2" /> Chat KIA
            </TabsTrigger>
            <TabsTrigger value="tasks" className="!flex-none text-slate-200 hover:bg-slate-800 hover:text-white data-[state=active]:bg-blue-600 data-[state=active]:text-white">
              <CheckSquare className="w-4 h-4 mr-2" /> Backlog & Tarefas
            </TabsTrigger>
            <TabsTrigger value="calendar" className="!flex-none text-slate-200 hover:bg-slate-800 hover:text-white data-[state=active]:bg-blue-600 data-[state=active]:text-white">
              <Calendar className="w-4 h-4 mr-2" /> Calendário & Redes
            </TabsTrigger>
            <TabsTrigger value="leads" className="!flex-none text-slate-200 hover:bg-slate-800 hover:text-white data-[state=active]:bg-blue-600 data-[state=active]:text-white">
              <Users className="w-4 h-4 mr-2" /> Leads & Templates
            </TabsTrigger>
            <TabsTrigger value="agents" className="!flex-none text-slate-200 hover:bg-slate-800 hover:text-white data-[state=active]:bg-blue-600 data-[state=active]:text-white">
              <Bot className="w-4 h-4 mr-2" /> Agent Factory
            </TabsTrigger>
          </TabsList>
          <p className="mt-1 px-1 text-xs text-slate-300 sm:hidden">Deslize a barra de secções para aceder às restantes áreas.</p>
          </div>

          {/* DASHBOARD TAB */}
          <TabsContent value="dashboard" className="space-y-6">
            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
              <Card className="gag-metric-card bg-slate-900 border-slate-800">
                <CardHeader className="pb-2">
                  <CardDescription className="text-slate-200">Marcas Ativas</CardDescription>
                  <CardTitle className="text-3xl text-blue-400">{stats?.brandsCount ?? 0}</CardTitle>
                </CardHeader>
                  <CardContent>
                    <p className="text-xs text-slate-200">Núcleo Operacional Exclusivo</p>
                  </CardContent>
              </Card>

              <Card className="gag-metric-card bg-slate-900 border-slate-800">
                <CardHeader className="pb-2">
                  <CardDescription className="text-slate-200">Tarefas Pendentes</CardDescription>
                  <CardTitle className="text-3xl text-amber-400">{stats?.pendingTasksCount || 0}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-xs text-slate-200">Em curso: {stats?.inProgressTasksCount ?? 0} · Concluídas: {stats?.completedTasksCount ?? 0}</p>
                </CardContent>
              </Card>

              <Card className="gag-metric-card bg-slate-900 border-slate-800">
                <CardHeader className="pb-2">
                  <CardDescription className="text-slate-200">Itens de Conhecimento</CardDescription>
                  <CardTitle className="text-3xl text-emerald-400">{stats?.knowledgeCount || 0}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-xs text-slate-200">Bases RAG operacionais</p>
                </CardContent>
              </Card>

              <Card className="gag-metric-card bg-slate-900 border-slate-800">
                <CardHeader className="pb-2">
                  <CardDescription className="text-slate-200">Agentes Especializados</CardDescription>
                  <CardTitle className="text-3xl text-purple-400">{dashboardAgentsLoading ? "—" : dashboardAgentSummary.total}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-xs text-slate-200">
                    {dashboardAgentsLoading
                      ? "A carregar estados dos agentes…"
                      : `Rascunho: ${dashboardAgentSummary.drafts} · Teste: ${dashboardAgentSummary.tests} · Ativos: ${dashboardAgentSummary.active}`}
                  </p>
                </CardContent>
              </Card>
            </div>

            <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 xl:grid-cols-3">
              {brands.map((b) => (
                <Card key={b.id} className="bg-slate-900 border-slate-800">
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-xl" style={{ color: b.colorTheme || '#3b82f6' }}>{b.name}</CardTitle>
                      <Badge variant="outline" className="bg-blue-500/10 text-blue-400 border-blue-500/30">
                        Núcleo GAG
                      </Badge>
                    </div>
                    <CardDescription className="text-slate-200">{b.description}</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div className="text-xs text-slate-200 flex justify-between">
                      <span>Tarefas no Backlog:</span>
                      <span className="font-semibold text-white">{tasks.filter(t => t.brandId === b.id).length}</span>
                    </div>
                    <div className="text-xs text-slate-200 flex justify-between">
                      <span>Documentos de Conhecimento:</span>
                      <span className="font-semibold text-white">{knowledge.filter(k => k.brandId === b.id).length}</span>
                    </div>
                    <div className="text-xs text-slate-200 flex justify-between">
                      <span>Leads Capturados:</span>
                      <span className="font-semibold text-white">{leads.filter(l => l.brandId === b.id).length}</span>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* KNOWLEDGE BASE TAB */}
          <TabsContent value="knowledge" className="space-y-6">
            <Card className="bg-slate-900 border-slate-800">
              <CardHeader>
                <CardTitle>{editingKnowledgeId ? "Rever e atualizar conhecimento oficial" : "Adicionar Conhecimento Oficial (RAG)"}</CardTitle>
                <CardDescription>{editingKnowledgeId ? "Revise título, categoria e conteúdo. A alteração só será guardada com a confirmação abaixo." : "Insira documentos, FAQs ou estratégias. A KIA usa este conteúdo como conhecimento factual adicional."}</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div>
                    <label className="text-xs text-slate-400 mb-1 block">Marca</label>
                    <Select value={kBrandId} onValueChange={setKBrandId}>
                      <SelectTrigger className="bg-slate-800 border-slate-700"><SelectValue /></SelectTrigger>
                      <SelectContent className="bg-slate-800 border-slate-700 text-slate-100">
                        {brands.map(b => <SelectItem key={b.id} value={String(b.id)}>{b.name}</SelectItem>)}
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <label className="text-xs text-slate-400 mb-1 block">Título</label>
                    <Input placeholder="Ex: Tabela de Preços Q1" value={kTitle} onChange={e => setKTitle(e.target.value)} className="bg-slate-800 border-slate-700" />
                  </div>
                  <div>
                    <label className="text-xs text-slate-400 mb-1 block">Categoria</label>
                    <Input placeholder="Ex: Preços / Estratégia" value={kCategory} onChange={e => setKCategory(e.target.value)} className="bg-slate-800 border-slate-700" />
                  </div>
                </div>
                <div>
                  <label className="text-xs text-slate-400 mb-1 block">Conteúdo / Factos</label>
                  <Textarea placeholder="Escreva o conhecimento detalhado..." value={kContent} onChange={e => setKContent(e.target.value)} className="bg-slate-800 border-slate-700 h-28" />
                </div>
                <div className="rounded-xl border border-dashed border-slate-700 bg-slate-950/50 p-3 sm:p-4">
                  <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                    <div className="min-w-0">
                      <p className="flex items-center gap-2 text-sm font-medium text-slate-100"><FileText className="h-4 w-4 text-blue-300" /> Carregar procedimento operacional real</p>
                      <p className="mt-1 text-xs text-slate-400">Aceita TXT, MD, CSV ou JSON até 700 KB. O conteúdo é guardado como conhecimento factual com origem rastreável.</p>
                    </div>
                    <Input type="file" accept=".txt,.md,.csv,.json,text/plain,text/markdown,text/csv,application/json" onChange={(event) => handleProcedureFile(event.target.files?.[0])} className="max-w-full border-slate-700 bg-slate-900 text-xs sm:max-w-xs" aria-label="Selecionar procedimento operacional" />
                  </div>
                  {procedureFile && <p className="mt-3 text-xs text-emerald-300">Ficheiro preparado: {procedureFile.name}. Reveja título, categoria e conteúdo antes de confirmar.</p>}
                </div>
                <div className="flex flex-wrap gap-2">
                  {editingKnowledgeId ? (
                    <>
                      <Button onClick={() => updateKnowledgeMutation.mutate({ id: editingKnowledgeId, title: kTitle, category: kCategory, content: kContent })} disabled={!kTitle.trim() || !kContent.trim() || updateKnowledgeMutation.isPending} className="bg-blue-600 hover:bg-blue-700">
                        <CircleCheckBig className="w-4 h-4 mr-2" /> Confirmar atualização
                      </Button>
                      <Button variant="outline" onClick={() => { setEditingKnowledgeId(null); setProcedureFile(null); setKTitle(""); setKContent(""); setKCategory("Estratégia"); }} className="border-slate-700 text-slate-200 hover:bg-slate-800">Cancelar edição</Button>
                    </>
                  ) : <Button onClick={() => addKnowledgeMutation.mutate({ brandId: Number(kBrandId), title: kTitle, category: kCategory, content: kContent })} disabled={!kTitle.trim() || !kContent.trim() || addKnowledgeMutation.isPending} className="bg-blue-600 hover:bg-blue-700">
                    <Plus className="w-4 h-4 mr-2" /> Guardar conteúdo manual
                  </Button>}
                  {procedureFile && <Button onClick={() => uploadKiaProcedureMutation.mutate({ brandId: Number(kBrandId), title: kTitle, category: kCategory, filename: procedureFile.name, content: kContent })} disabled={!kTitle.trim() || !kContent.trim() || uploadKiaProcedureMutation.isPending} className="bg-emerald-600 text-white hover:bg-emerald-500">
                    {uploadKiaProcedureMutation.isPending ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <FileText className="w-4 h-4 mr-2" />} Carregar procedimento
                  </Button>}
                </div>
              </CardContent>
            </Card>

            <Card className="border-blue-500/30 bg-slate-900">
              <CardHeader>
                <div className="flex flex-wrap items-start justify-between gap-3">
                  <div>
                    <CardTitle className="flex items-center gap-2"><FileText className="h-5 w-5 text-blue-300" /> Document Intelligence</CardTitle>
                    <CardDescription>Analisa documentos fornecidos pelo proprietário. O resultado é um rascunho interno e nunca entra automaticamente na Knowledge Base.</CardDescription>
                  </div>
                  <Badge variant="outline" className="border-amber-500/40 bg-amber-500/10 text-amber-200">REVIEW_REQUIRED</Badge>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex flex-wrap items-center gap-2 rounded-lg border border-slate-700 bg-slate-950/40 p-3" role="group" aria-label="Modo de análise documental">
                  <span className="mr-1 text-xs font-semibold uppercase tracking-wide text-slate-400">Modo</span>
                  <Button type="button" size="sm" variant={documentAnalysisMode === "GENERAL" ? "default" : "outline"} onClick={() => setDocumentAnalysisMode("GENERAL")} className={documentAnalysisMode === "GENERAL" ? "bg-blue-600 hover:bg-blue-700" : "border-slate-600 text-slate-200 hover:bg-slate-800"}>Análise geral</Button>
                  <Button type="button" size="sm" variant={documentAnalysisMode === "SCANNER" ? "default" : "outline"} onClick={() => setDocumentAnalysisMode("SCANNER")} className={documentAnalysisMode === "SCANNER" ? "bg-amber-700 text-white hover:bg-amber-600" : "border-slate-600 text-slate-200 hover:bg-slate-800"}>Scanner de Economia Real GAG</Button>
                  <p className="basis-full text-xs text-slate-400">{documentAnalysisMode === "SCANNER" ? "O Scanner opera apenas com READ, cria rascunho com proveniência e mantém ações externas bloqueadas." : "A análise geral produz apenas um rascunho interno com revisão humana obrigatória."}</p>
                </div>
                <div className="grid gap-4 lg:grid-cols-[minmax(0,1fr)_minmax(0,1.25fr)]">
                  <div>
                    <label className="mb-1 block text-xs text-slate-400">Documento</label>
                    <Input type="file" accept=".pdf,.docx,.xlsx,.csv,.txt,.md,.json,.png,.jpg,.jpeg,.webp,application/pdf,application/vnd.openxmlformats-officedocument.wordprocessingml.document,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet,text/csv,text/plain,text/markdown,application/json,image/png,image/jpeg,image/webp" onChange={(event) => setDocumentFile(event.target.files?.[0] ?? null)} className="border-slate-700 bg-slate-800 text-xs" aria-label="Selecionar documento para análise interna" />
                    <p className="mt-2 text-xs text-slate-400">PDF, DOCX, XLSX, CSV, TXT, MD, JSON e imagens, até 6 MB. Ações externas permanecem bloqueadas.</p>
                    {documentFile && <p className="mt-2 text-xs text-emerald-300">Selecionado: {documentFile.name}</p>}
                  </div>
                  <div>
                    <label className="mb-1 block text-xs text-slate-400">Objetivo da análise</label>
                    <Textarea value={documentIntent} onChange={(event) => setDocumentIntent(event.target.value)} className="min-h-[104px] border-slate-700 bg-slate-800" placeholder="Ex.: extrair valores, resumir, comparar ou organizar para revisão interna" />
                  </div>
                </div>
                {documentAnalysisMode === "SCANNER" && <div className="grid gap-4 rounded-lg border border-amber-500/25 bg-amber-500/5 p-4 md:grid-cols-2">
                  <div><label className="mb-1 block text-xs text-slate-400">Pergunta de análise interna</label><Textarea value={scannerQuestion} onChange={(event) => setScannerQuestion(event.target.value)} className="min-h-[90px] border-slate-700 bg-slate-800" placeholder="Ex.: que factos confirmados e lacunas o documento revela?" /></div>
                  <div><label className="mb-1 block text-xs text-slate-400">Decisão interna a preparar</label><Textarea value={scannerIntendedDecision} onChange={(event) => setScannerIntendedDecision(event.target.value)} className="min-h-[90px] border-slate-700 bg-slate-800" placeholder="Ex.: preparar briefing interno para revisão, sem recomendação financeira." /></div>
                  <div><label className="mb-1 block text-xs text-slate-400">Período</label><Input value={scannerPeriod} onChange={(event) => setScannerPeriod(event.target.value)} className="border-slate-700 bg-slate-800" placeholder="Ex.: Janeiro a Março de 2026" /></div>
                  <div><label className="mb-1 block text-xs text-slate-400">Geografia</label><Input value={scannerGeography} onChange={(event) => setScannerGeography(event.target.value)} className="border-slate-700 bg-slate-800" placeholder="Ex.: Angola" /></div>
                  <p className="md:col-span-2 text-xs text-amber-200">O resultado não é aconselhamento financeiro e não autoriza pagamentos, contactos, publicações ou qualquer ação externa.</p>
                </div>}
                <div className="flex flex-wrap items-center gap-3">
                  <Button onClick={handleDocumentAnalysis} disabled={!documentFile || uploadAndAnalyzeDocumentMutation.isPending || runScannerDocumentAnalysisMutation.isPending} className="bg-blue-600 hover:bg-blue-700">
                    {(uploadAndAnalyzeDocumentMutation.isPending || runScannerDocumentAnalysisMutation.isPending) ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <FileText className="mr-2 h-4 w-4" />} {documentAnalysisMode === "SCANNER" ? "Analisar com Scanner" : "Analisar como rascunho interno"}
                  </Button>
                  <p className="text-xs text-slate-400">Obrigatório: proveniência, factos confirmados, lacunas e aprovação humana.</p>
                </div>
                {scannerReport && <div className="rounded-xl border border-amber-500/25 bg-slate-950/60 p-4">
                  <div className="flex flex-wrap items-center justify-between gap-2"><p className="font-medium text-slate-100">Rascunho do Scanner de Economia Real GAG</p><Badge className="bg-amber-500/15 text-amber-200">REVIEW_REQUIRED</Badge></div>
                  <p className="mt-2 text-sm leading-6 text-slate-300">{scannerReport.documentSummary}</p>
                  <p className="mt-3 text-xs text-slate-500">Documento #{scannerReport.provenance.documentId} · hash preservado · relatório interno sem ações externas.</p>
                </div>}
                {scannerEconomicReportsQuery.data?.length ? <p className="text-xs text-slate-500">Relatórios do Scanner persistidos neste espaço interno: {scannerEconomicReportsQuery.data.length}. Todos permanecem em revisão até decisão humana.</p> : null}
                {documentResult && <div className="space-y-4 rounded-xl border border-amber-500/25 bg-slate-950/60 p-4">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <p className="font-medium text-slate-100">Resultado de análise #{documentResult.analysisId}</p>
                    <Badge className={documentResult.reviewDecision === "APPROVED" ? "bg-emerald-500/15 text-emerald-200" : "bg-amber-500/15 text-amber-200"}>{documentResult.reviewDecision === "APPROVED" ? "Aprovado para exportação interna" : "Revisão humana obrigatória"}</Badge>
                  </div>
                  <p className="text-sm leading-6 text-slate-300">{documentResult.documentSummary}</p>
                  <div className="grid gap-4 md:grid-cols-2">
                    <div><p className="text-xs font-semibold uppercase tracking-wide text-emerald-300">Factos confirmados</p><ul className="mt-2 space-y-2 text-sm text-slate-300">{documentResult.keyInformation.length ? documentResult.keyInformation.map((item, index) => <li key={`${item.sourceReference}-${index}`}>• {item.fact} <span className="text-slate-500">({item.sourceReference})</span></li>) : <li>• Nenhum facto verificável foi extraído.</li>}</ul></div>
                    <div><p className="text-xs font-semibold uppercase tracking-wide text-amber-300">Lacunas e revisão</p><ul className="mt-2 space-y-2 text-sm text-slate-300">{[...documentResult.missingInformation, ...documentResult.reviewReasons].length ? [...documentResult.missingInformation, ...documentResult.reviewReasons].map((item, index) => <li key={`${item}-${index}`}>• {item}</li>) : <li>• Revisão humana obrigatória antes de qualquer utilização.</li>}</ul></div>
                  </div>
                  <div className="space-y-3 border-t border-slate-800 pt-4">
                    <label className="block text-xs font-semibold uppercase tracking-wide text-slate-400">Decisão do proprietário</label>
                    <Textarea value={documentReviewNote} onChange={(event) => setDocumentReviewNote(event.target.value)} className="min-h-[76px] border-slate-700 bg-slate-900" placeholder="Registe a decisão e as condições de uso interno deste resultado." />
                    <div className="flex flex-wrap gap-2">
                      <Button size="sm" onClick={() => reviewDocumentAnalysisMutation.mutate({ analysisId: documentResult.analysisId, decision: "APPROVED", note: documentReviewNote.trim() })} disabled={documentReviewNote.trim().length < 3 || reviewDocumentAnalysisMutation.isPending} className="bg-emerald-700 text-white hover:bg-emerald-600"><CircleCheckBig className="mr-2 h-4 w-4" /> Aprovar para exportação interna</Button>
                      <Button size="sm" variant="outline" onClick={() => reviewDocumentAnalysisMutation.mutate({ analysisId: documentResult.analysisId, decision: "CHANGES_REQUESTED", note: documentReviewNote.trim() })} disabled={documentReviewNote.trim().length < 3 || reviewDocumentAnalysisMutation.isPending} className="border-amber-500/40 text-amber-200 hover:bg-amber-500/10">Pedir correções</Button>
                      <Button size="sm" variant="outline" onClick={() => reviewDocumentAnalysisMutation.mutate({ analysisId: documentResult.analysisId, decision: "REJECTED", note: documentReviewNote.trim() })} disabled={documentReviewNote.trim().length < 3 || reviewDocumentAnalysisMutation.isPending} className="border-red-500/40 text-red-200 hover:bg-red-500/10">Rejeitar</Button>
                      <Button size="sm" variant="outline" onClick={() => exportApprovedDocumentAnalysisMutation.mutate({ analysisId: documentResult.analysisId })} disabled={documentResult.reviewDecision !== "APPROVED" || exportApprovedDocumentAnalysisMutation.isPending} className="border-blue-500/40 text-blue-200 hover:bg-blue-500/10"><FileText className="mr-2 h-4 w-4" /> Exportar relatório PDF</Button>
                    </div>
                    <p className="text-xs text-slate-500">O PDF é o formato padrão de exportação e só é disponibilizado após aprovação explícita. Publicações, envios, contactos e ações externas continuam bloqueados.</p>
                  </div>
                </div>}
                <div className="border-t border-slate-800 pt-4">
                  <div className="flex flex-wrap items-center justify-between gap-3">
                    <div>
                      <p className="text-sm font-medium text-slate-100">Fila de revisão documental</p>
                      <p className="mt-1 text-xs text-slate-500">Filtre as decisões humanas. A fila não altera estados nem desbloqueia ações externas.</p>
                    </div>
                    <Select value={documentReviewFilter} onValueChange={(value) => setDocumentReviewFilter(value as DocumentReviewFilter)}>
                      <SelectTrigger className="w-[205px] border-slate-700 bg-slate-800 text-slate-100" aria-label="Filtrar documentos por estado de revisão"><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="ALL">Todos os estados</SelectItem>
                        <SelectItem value="PENDING">Pendentes</SelectItem>
                        <SelectItem value="APPROVED">Aprovados</SelectItem>
                        <SelectItem value="CHANGES_REQUESTED">Correções pedidas</SelectItem>
                        <SelectItem value="REJECTED">Rejeitados</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  {documentAnalysesQuery.isLoading ? <p className="mt-4 text-xs text-slate-500">A carregar fila documental…</p> : visibleDocumentAnalyses.length ? <div className="mt-4 space-y-2">
                    {visibleDocumentAnalyses.map((analysis) => {
                      const sourceDocument = documentsQuery.data?.find((document) => document.id === analysis.documentId);
                      const badgeStyle = analysis.reviewDecision === "APPROVED" ? "border-emerald-500/40 bg-emerald-500/10 text-emerald-200" : analysis.reviewDecision === "REJECTED" ? "border-red-500/40 bg-red-500/10 text-red-200" : analysis.reviewDecision === "CHANGES_REQUESTED" ? "border-amber-500/40 bg-amber-500/10 text-amber-200" : "border-blue-500/40 bg-blue-500/10 text-blue-200";
                      const label = analysis.reviewDecision === "APPROVED" ? "Aprovado" : analysis.reviewDecision === "REJECTED" ? "Rejeitado" : analysis.reviewDecision === "CHANGES_REQUESTED" ? "Correções pedidas" : "Pendente";
                      return <div key={analysis.id} className="flex flex-col gap-3 rounded-lg border border-slate-800 bg-slate-950/50 p-3 sm:flex-row sm:items-center sm:justify-between">
                        <div className="min-w-0">
                          <p className="truncate text-sm font-medium text-slate-100">{sourceDocument?.filename ?? `Documento #${analysis.documentId}`}</p>
                          <p className="mt-1 text-xs text-slate-500">Análise #{analysis.id} · {new Date(analysis.createdAt).toLocaleString("pt-PT")}</p>
                        </div>
                        <div className="flex flex-wrap items-center gap-2">
                          <Badge variant="outline" className={badgeStyle}>{label}</Badge>
                          <Button size="sm" variant="outline" onClick={() => openDocumentAnalysis(analysis)} className="border-slate-700 text-slate-200 hover:bg-slate-800"><ClipboardCheck className="mr-2 h-4 w-4" /> Ver e rever</Button>
                          {analysis.reviewDecision === "APPROVED" && <Button size="sm" variant="outline" onClick={() => exportApprovedDocumentAnalysisMutation.mutate({ analysisId: analysis.id })} disabled={exportApprovedDocumentAnalysisMutation.isPending} className="border-blue-500/40 text-blue-200 hover:bg-blue-500/10"><FileText className="mr-2 h-4 w-4" /> PDF</Button>}
                        </div>
                      </div>;
                    })}
                  </div> : <p className="mt-4 text-xs text-slate-500">Não existem análises neste estado de revisão.</p>}
                  {documentsQuery.data?.length ? <p className="mt-3 text-xs text-slate-500">Documentos analisados neste espaço interno: {documentsQuery.data.length}. Cada documento permanece isolado por proprietário.</p> : null}
                </div>
              </CardContent>
            </Card>

            <Card className="bg-slate-900 border-slate-800">
              <CardHeader>
                <CardTitle>Conhecimento Carregado na Plataforma</CardTitle>
                <CardDescription>Lista de todos os registos oficiais disponíveis para consulta e IA RAG.</CardDescription>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow className="border-slate-800">
                      <TableHead>ID</TableHead>
                      <TableHead>Título</TableHead>
                      <TableHead>Categoria</TableHead>
                      <TableHead>Origem</TableHead>
                      <TableHead>Estado</TableHead>
                      <TableHead className="text-right">Ações</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {knowledge.map(k => (
                      <TableRow key={k.id} className="border-slate-800">
                        <TableCell>#{k.id}</TableCell>
                        <TableCell className="font-medium">{k.title}</TableCell>
                        <TableCell><Badge variant="outline" className="border-slate-700">{k.category}</Badge></TableCell>
                        <TableCell className="max-w-40 truncate text-xs text-slate-400">{k.sourceFilename || "Conteúdo manual"}</TableCell>
                        <TableCell><Badge className="bg-emerald-900 text-emerald-300">{k.status}</Badge></TableCell>
                        <TableCell className="text-right">
                          {knowledgeDeleteCandidateId === k.id ? <div className="flex flex-wrap justify-end gap-1">
                            <Button size="sm" onClick={() => deleteKnowledgeMutation.mutate({ id: k.id })} className="bg-red-700 text-white hover:bg-red-600">Confirmar</Button>
                            <Button size="sm" variant="outline" onClick={() => setKnowledgeDeleteCandidateId(null)} className="border-slate-700 text-slate-200">Cancelar</Button>
                          </div> : <div className="flex justify-end gap-1">
                            <Button size="sm" variant="ghost" onClick={() => { setEditingKnowledgeId(k.id); setKBrandId(String(k.brandId)); setKTitle(k.title); setKCategory(k.category); setKContent(k.content); setProcedureFile(null); }} className="text-blue-300 hover:text-blue-200"><Pencil className="w-4 h-4" /></Button>
                            <Button size="sm" variant="ghost" onClick={() => setKnowledgeDeleteCandidateId(k.id)} className="text-red-400 hover:text-red-300"><Trash2 className="w-4 h-4" /></Button>
                          </div>}
                        </TableCell>
                      </TableRow>
                    ))}
                    {knowledge.length === 0 && (
                      <TableRow><TableCell colSpan={6} className="text-center text-slate-500 py-6">Nenhum conhecimento carregado ainda.</TableCell></TableRow>
                    )}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>

          {/* CHAT GAG MASTER TAB */}
          <TabsContent value="chat" className="space-y-4 sm:space-y-6">
            <Card className="gag-chat-shell bg-slate-900 border-slate-800 flex min-h-[calc(100dvh-9rem)] flex-col sm:min-h-[620px] lg:min-h-[680px]">
              <CardHeader className="border-b border-slate-800 py-4">
                <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                  <div className="min-w-0">
                    <CardTitle className="flex items-center gap-2 text-base text-slate-100 sm:text-lg">
                      <Bot className="w-5 h-5 text-blue-400" /> KIA (Knowledge Intelligent Agent)
                    </CardTitle>
                    <CardDescription className="text-slate-300">Inteligência nativa, Core Knowledge e contexto factual externo separado. Não inventa informação interna.</CardDescription>
                  </div>
                  <div className="flex w-full flex-col gap-2 sm:w-auto sm:flex-row">
                    <Select value={chatBrandId} onValueChange={setChatBrandId}>
                      <SelectTrigger className="w-full bg-slate-800 border-slate-700 sm:w-44"><SelectValue /></SelectTrigger>
                      <SelectContent className="bg-slate-800 border-slate-700 text-slate-100">
                        <SelectItem value="all">Todas as Marcas</SelectItem>
                        {brands.map(b => <SelectItem key={b.id} value={String(b.id)}>{b.name}</SelectItem>)}
                      </SelectContent>
                    </Select>
                    <Button type="button" variant="outline" onClick={() => clearKiaConversationMutation.mutate()} disabled={chatHistory.length === 0 || clearKiaConversationMutation.isPending} className="border-slate-700 bg-slate-900 text-slate-200 hover:bg-slate-800">
                      <Trash2 className="mr-2 h-4 w-4" /> Limpar contexto
                    </Button>
                  </div>
                </div>
              </CardHeader>
              <div className="px-4 pt-3 flex flex-wrap gap-2" aria-live="polite">
                <Badge className={`border text-slate-100 ${voice.status === "listening" ? "border-blue-400 bg-blue-950 animate-pulse" : voice.status === "processing" ? "border-violet-400 bg-violet-950 animate-pulse" : voice.status === "speaking" ? "border-emerald-400 bg-emerald-950" : "border-slate-700 bg-slate-800 text-slate-200"}`}>
                  {voice.status === "processing" ? <Loader2 className="w-3.5 h-3.5 mr-1.5 animate-spin" /> : <AudioLines className={`w-3.5 h-3.5 mr-1.5 ${voice.status === "listening" ? "animate-pulse" : ""}`} />}
                  {voice.status === "listening" && "A ouvir"}
                  {voice.status === "processing" && "A processar"}
                  {voice.status === "speaking" && "A responder — fale para interromper"}
                  {voice.status === "idle" && "Pronto para texto ou voz"}
                  {voice.status === "unsupported" && "Voz não suportada"}
                  {voice.status === "error" && "Atenção à voz"}
                </Badge>
                {(voice.status === "listening" || voice.status === "processing" || voice.status === "speaking") && <span className="flex items-center gap-1 text-xs text-slate-300"><span className="h-1.5 w-1.5 rounded-full bg-blue-300 animate-pulse" /><span className="h-1.5 w-1.5 rounded-full bg-blue-300 animate-pulse" /><span className="h-1.5 w-1.5 rounded-full bg-blue-300 animate-pulse" />{voice.status === "listening" ? "A captar a sua mensagem" : voice.status === "processing" ? "A interpretar o pedido" : voice.isInterruptionListening ? "A ouvir se quer interromper" : "A preparar escuta para interrupção"}</span>}
                {voice.preferences.conversationMode && <Badge className="bg-blue-950 text-blue-200 border border-blue-800">Modo conversação ativo</Badge>}
              </div>
              <CardContent className="min-h-0 flex-1 space-y-4 overflow-y-auto p-3 sm:p-4">
                {chatHistory.length === 0 && (
                  <div className="h-full flex flex-col items-center justify-center text-center text-slate-500 space-y-2">
                    <Bot className="w-12 h-12 text-slate-700" />
                    <p className="max-w-lg font-medium text-slate-200">Olá, eu sou a Kia, a Knowledge Intelligent Agent do GAG Core. Posso ajudar a compreender pedidos, organizar informação, preparar tarefas autorizadas e coordenar a operação.</p>
                    <p className="text-xs max-w-lg">Pode escrever ou falar naturalmente. Se uma ação alterar dados, a KIA mostra o resumo e pede confirmação antes de gravar.</p>
                    <div className="flex max-w-lg flex-wrap justify-center gap-2 pt-2">
                      <Button type="button" variant="outline" onClick={() => handleSendChat("KIA, o que podes fazer?")} className="border-slate-700 bg-slate-900 text-slate-200 hover:bg-slate-800">O que podes fazer?</Button>
                      <Button type="button" variant="outline" onClick={() => handleSendChat("KIA, organiza as minhas tarefas.")} className="border-slate-700 bg-slate-900 text-slate-200 hover:bg-slate-800">Organizar tarefas</Button>
                      <Button type="button" variant="outline" onClick={() => handleSendChat("KIA, como funciona a Knowledge Base?")} className="border-slate-700 bg-slate-900 text-slate-200 hover:bg-slate-800">Como funciona?</Button>
                    </div>
                  </div>
                )}
                {chatHistory.map((msg) => (
                  <div key={msg.id} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                    <div className={`max-w-[92%] rounded-2xl px-3 py-2.5 text-sm sm:max-w-xl sm:px-4 sm:py-3 ${msg.role === 'user' ? 'bg-blue-600 text-white' : 'bg-slate-800 border border-slate-700 text-slate-200'}`}>
                      {msg.role === 'assistant' && replyMode !== "voice" ? (
                        <div className="break-words [&_p]:my-0 [&_p+p]:mt-3 [&_ul]:my-3 [&_ul]:list-disc [&_ul]:pl-5 [&_ol]:my-3 [&_ol]:list-decimal [&_ol]:pl-5 [&_a]:text-blue-300 [&_a]:underline">
                          <ReactMarkdown>{msg.content}</ReactMarkdown>
                        </div>
                      ) : msg.role === "assistant" ? (
                        <p className="text-xs text-slate-300">Resposta enviada por voz no idioma selecionado.</p>
                      ) : (
                        <p className="whitespace-pre-wrap break-words">{msg.content}</p>
                      )}
                    </div>
                  </div>
                ))}
                {lastKiaRouting && (
                  <div className={`rounded-xl border p-3 text-xs ${lastKiaRouting.status === "BLOCKED" ? "border-rose-700 bg-rose-950/40 text-rose-100" : lastKiaRouting.status === "NOT_IMPLEMENTED" ? "border-slate-600 bg-slate-900 text-slate-100" : lastKiaRouting.status === "CONFIRMATION_REQUIRED" ? "border-amber-700 bg-amber-950/40 text-amber-100" : "border-emerald-700 bg-emerald-950/40 text-emerald-100"}`} role="status" aria-live="polite">
                    <div className="flex flex-wrap items-center gap-2"><Badge className="border border-current bg-transparent text-current">{lastKiaRouting.intent}</Badge><span className="font-semibold">{lastKiaRouting.capabilityLabel}</span><span>{lastKiaRouting.status === "CONFIRMATION_REQUIRED" ? "Confirmação necessária" : lastKiaRouting.status === "NOT_IMPLEMENTED" ? "Não implementado" : lastKiaRouting.status === "BLOCKED" ? "Bloqueado" : "Disponível"}</span></div>
                    <p className="mt-1 leading-relaxed">{lastKiaRouting.summary}</p>
                    {lastKiaOperation && lastKiaRouting.status !== "BLOCKED" && (
                      <Button type="button" variant="outline" size="sm" className="mt-3 border-current bg-transparent text-current hover:bg-white/10" onClick={() => openInternalOperation(lastKiaOperation)}>
                        Abrir {lastKiaOperation.label}
                      </Button>
                    )}
                  </div>
                )}
                <div className="rounded-xl border border-slate-700 bg-slate-950/60 p-3 text-xs text-slate-100">
                  <div className="mb-2 flex items-center gap-2"><ShieldCheck className="h-4 w-4 text-blue-300" /><span className="font-semibold">Operações internas disponíveis</span></div>
                  <div className="flex flex-wrap gap-2">
                    {GAG_INTERNAL_OPERATION_SHORTCUTS.map((operation) => (
                      <Button key={operation.id} type="button" variant="outline" size="sm" className="border-slate-600 bg-slate-900 text-slate-100 hover:bg-slate-800" onClick={() => openInternalOperation(operation)}>
                        {operation.label}
                      </Button>
                    ))}
                  </div>
                  <p className="mt-2 text-slate-300">Os atalhos abrem apenas fluxos persistentes já implementados. A confirmação e a revisão humana continuam obrigatórias quando aplicáveis.</p>
                </div>
              </CardContent>
              {voice.error && <p className="px-4 pb-2 text-sm text-red-300" role="alert">{voice.error}</p>}
              <div className="sticky bottom-0 z-10 flex items-stretch gap-2 border-t border-slate-800 bg-slate-900 p-3 sm:items-center sm:p-4">
                {voice.status === "speaking" ? (
                  <Button onClick={() => voice.startListening(handleVoiceTranscript)} variant="outline" className="border-amber-500 bg-amber-950/50 text-amber-100 hover:bg-amber-900 hover:text-white min-h-12">
                    <Mic className="w-4 h-4 mr-2" /> Interromper
                  </Button>
                ) : voice.status === "listening" || voice.status === "processing" ? (
                  <Button onClick={voice.cancel} variant="outline" className="border-red-700 bg-red-950/40 text-red-200 hover:bg-red-900 hover:text-white min-h-12">
                    <X className="w-4 h-4 mr-2" /> Cancelar
                  </Button>
                ) : (
                  <Button
                    onClick={() => voice.startListening(handleVoiceTranscript)}
                    disabled={!voice.isRecognitionSupported || chatMutation.isPending}
                    variant="outline"
                    className="min-h-12 shrink-0 border-blue-500 bg-blue-950/50 text-blue-100 hover:bg-blue-900 hover:text-white"
                    aria-label="Falar com a KIA"
                  >
                    <Mic className="w-4 h-4 mr-2" /> Falar
                  </Button>
                )}
                <Input
                  placeholder="Escreva a sua mensagem para a KIA..."
                  value={chatMessage}
                  onChange={e => setChatMessage(e.target.value)}
                  onKeyDown={e => e.key === 'Enter' && handleSendChat()}
                  className="min-h-12 min-w-0 flex-1 border-slate-600 bg-slate-950 text-slate-100 caret-blue-300 placeholder:text-slate-400 focus-visible:border-blue-400 focus-visible:ring-2 focus-visible:ring-blue-400"
                />
                <Button onClick={() => handleSendChat()} disabled={!chatMessage.trim() || chatMutation.isPending} className="min-h-12 shrink-0 bg-blue-600 px-4 text-white hover:bg-blue-500 sm:px-5" aria-label="Enviar mensagem">
                  <Send className="w-4 h-4 mr-2" /><span>Enviar</span>
                </Button>
              </div>
              {pendingKiaTask && !pendingInternalExecutionPlan && (
                <div className="mx-3 mb-3 rounded-xl border border-amber-700 bg-amber-950/40 p-3 sm:mx-4 sm:mb-4" role="status">
                  <p className="font-medium text-amber-100">Pré-visualização da tarefa — confirmação necessária</p>
                  <p className="mt-1 text-sm text-amber-50">{pendingKiaTask.title}</p>
                  <p className="mt-1 text-xs text-amber-200">{pendingKiaTask.periodLabel ? `Quando: ${pendingKiaTask.periodLabel}` : "Quando: por definir"}{pendingKiaTask.timeLabel ? ` · ${pendingKiaTask.timeLabel}` : ""} · Prioridade: {pendingKiaTask.priority}</p>
                  <p className="mt-1 text-xs text-amber-200">A KIA não vai gravar esta alteração sem a sua confirmação explícita.</p>
                  {isEditingPendingTask && (
                    <div className="mt-3 grid grid-cols-1 gap-2 sm:grid-cols-2">
                      <Input value={pendingKiaTask.title} onChange={(event) => setPendingKiaTask({ ...pendingKiaTask, title: event.target.value })} className="border-amber-700 bg-slate-950 text-slate-100" aria-label="Título da tarefa preparada" />
                      <Select value={pendingKiaTask.priority} onValueChange={(priority: PendingKiaTask["priority"]) => setPendingKiaTask({ ...pendingKiaTask, priority })}>
                        <SelectTrigger className="border-amber-700 bg-slate-950 text-slate-100"><SelectValue /></SelectTrigger>
                        <SelectContent className="border-amber-700 bg-slate-900 text-slate-100">
                          <SelectItem value="Baixa">Prioridade baixa</SelectItem><SelectItem value="Média">Prioridade média</SelectItem><SelectItem value="Alta">Prioridade alta</SelectItem><SelectItem value="Urgente">Prioridade urgente</SelectItem>
                        </SelectContent>
                      </Select>
                      <Input value={pendingKiaTask.periodLabel ?? ""} onChange={(event) => setPendingKiaTask({ ...pendingKiaTask, periodLabel: event.target.value || null })} placeholder="Quando? Ex.: amanhã" className="border-amber-700 bg-slate-950 text-slate-100" aria-label="Período da tarefa preparada" />
                      <Input value={pendingKiaTask.timeLabel ?? ""} onChange={(event) => setPendingKiaTask({ ...pendingKiaTask, timeLabel: event.target.value || null })} placeholder="Hora. Ex.: 16:00" className="border-amber-700 bg-slate-950 text-slate-100" aria-label="Hora da tarefa preparada" />
                    </div>
                  )}
                  <div className="mt-3 flex flex-wrap gap-2">
                    <Button size="sm" disabled={!pendingKiaTask.title.trim() || prepareKiaInternalTaskPlanMutation.isPending} onClick={preparePendingKiaTaskForKernel} className="bg-amber-600 text-slate-950 hover:bg-amber-500">Preparar confirmação segura</Button>
                    <Button size="sm" variant="outline" onClick={() => setIsEditingPendingTask((current) => !current)} className="border-amber-700 text-amber-100 hover:bg-amber-950">{isEditingPendingTask ? "Concluir edição" : "Alterar"}</Button>
                    <Button size="sm" variant="outline" onClick={cancelPendingKiaTask} className="border-amber-700 text-amber-100 hover:bg-amber-950">Cancelar</Button>
                  </div>
                </div>
              )}
              {pendingInternalExecutionPlan && (
                <div className="mx-3 mb-3 rounded-xl border border-emerald-700 bg-emerald-950/40 p-3 sm:mx-4 sm:mb-4" role="status">
                  <div className="flex flex-wrap items-center gap-2">
                    <p className="flex items-center gap-2 font-medium text-emerald-100"><ShieldCheck className="h-4 w-4" /> Plano interno assinado — confirmação final necessária</p>
                    <Badge className="border border-amber-700 bg-amber-950 text-amber-200">A confirmar</Badge>
                    <Badge className="border border-emerald-700 bg-emerald-950 text-emerald-200">{getInternalExecutionActionLabel(pendingInternalExecutionPlan.action.type)}</Badge>
                    <Badge className="border border-blue-700 bg-blue-950 text-blue-200">Origem: {pendingInternalExecutionPlan.source}</Badge>
                  </div>
                  <p className="mt-1 text-sm text-emerald-50">{pendingInternalExecutionPlan.action.type === "TASK_CREATE" ? pendingInternalExecutionPlan.action.title : `Atualizar prioridade da tarefa #${pendingInternalExecutionPlan.action.taskId}`}</p>
                  <p className="mt-1 text-xs text-emerald-200">Ação: {pendingInternalExecutionPlan.action.type === "TASK_CREATE" ? "criar tarefa interna" : "atualizar prioridade interna"} · Origem: {pendingInternalExecutionPlan.source} · Prioridade: {pendingInternalExecutionPlan.action.priority} · Expira às {new Date(pendingInternalExecutionPlan.expiresAt).toLocaleTimeString("pt-PT", { hour: "2-digit", minute: "2-digit" })}</p>
                  <p className="mt-1 text-xs text-emerald-200">O resumo e o nonce ficam associados a este plano. Uma confirmação cria uma única tarefa, com registo auditável; ações externas continuam bloqueadas.</p>
                  <div className="mt-3 flex flex-wrap gap-2">
                    <Button size="sm" onClick={confirmPendingInternalExecutionPlan} disabled={confirmInternalExecutionPlanMutation.isPending} className="bg-emerald-500 text-slate-950 hover:bg-emerald-400">Confirmar e executar internamente</Button>
                    <Button size="sm" variant="outline" onClick={cancelPendingInternalExecutionPlan} disabled={cancelInternalExecutionPlanMutation.isPending} className="border-emerald-700 text-emerald-100 hover:bg-emerald-950">Cancelar plano</Button>
                  </div>
                </div>
              )}
              {kazOperationalReport && (
                <div className="mx-3 mb-3 rounded-xl border border-blue-700 bg-blue-950/40 p-3 sm:mx-4 sm:mb-4" aria-live="polite">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <p className="flex items-center gap-2 text-sm font-medium text-blue-100"><Bot className="h-4 w-4 text-blue-300" /> Relatório operacional do Kaz</p>
                    <div className="flex flex-wrap items-center gap-2">
                      <Badge className="border border-blue-700 bg-blue-950 text-blue-200">Dados internos atuais</Badge>
                      <Badge className="border border-emerald-700 bg-emerald-950 text-emerald-200">Relatório recebido</Badge>
                      <Badge className={kazOperationalReport.urgent > 0 ? "border border-rose-700 bg-rose-950 text-rose-200" : "border border-emerald-700 bg-emerald-950 text-emerald-200"}>{kazOperationalReport.urgent > 0 ? `${kazOperationalReport.urgent} urgente(s) aberta(s)` : "Sem urgências abertas"}</Badge>
                    </div>
                  </div>
                  <div className="mt-3 grid grid-cols-2 gap-2 sm:grid-cols-3">
                    <div className="rounded-lg border border-blue-900 bg-slate-950/70 p-2"><p className="text-xs text-slate-400">Tarefas</p><p className="text-lg font-semibold text-slate-100">{kazOperationalReport.total}</p></div>
                    <div className="rounded-lg border border-blue-900 bg-slate-950/70 p-2"><p className="text-xs text-slate-400">Pendentes</p><p className="text-lg font-semibold text-amber-200">{kazOperationalReport.pending}</p></div>
                    <div className="rounded-lg border border-blue-900 bg-slate-950/70 p-2"><p className="text-xs text-slate-400">Em curso</p><p className="text-lg font-semibold text-blue-200">{kazOperationalReport.inProgress}</p></div>
                    <div className="rounded-lg border border-blue-900 bg-slate-950/70 p-2"><p className="text-xs text-slate-400">Concluídas</p><p className="text-lg font-semibold text-emerald-200">{kazOperationalReport.completed}</p></div>
                    <div className="rounded-lg border border-blue-900 bg-slate-950/70 p-2"><p className="text-xs text-slate-400">Urgentes abertas</p><p className="text-lg font-semibold text-rose-200">{kazOperationalReport.urgent}</p></div>
                    <div className="rounded-lg border border-blue-900 bg-slate-950/70 p-2"><p className="text-xs text-slate-400">Fontes aprovadas</p><p className="text-lg font-semibold text-slate-100">{kazOperationalReport.approvedKnowledgeCount}</p></div>
                  </div>
                  <p className="mt-3 text-xs text-blue-200">Este quadro é apenas informativo. Não cria nem altera tarefas; qualquer ação continua sujeita ao plano assinado e à confirmação no Kernel.</p>
                </div>
              )}
              {internalExecutionTimelineQuery.data && (
                <div className="mx-3 mb-3 rounded-xl border border-slate-700 bg-slate-950/70 p-3 sm:mx-4 sm:mb-4" aria-live="polite">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <p className="flex items-center gap-2 text-sm font-medium text-slate-100"><ShieldCheck className="h-4 w-4 text-emerald-400" /> Trilho de execução interna</p>
                    <Badge className={internalExecutionAuditQuery.data?.valid ? "border border-emerald-700 bg-emerald-950 text-emerald-200" : "border border-amber-700 bg-amber-950 text-amber-200"}>{internalExecutionAuditQuery.isLoading ? "A verificar integridade…" : internalExecutionAuditQuery.data?.valid ? `Integridade verificada · ${internalExecutionAuditQuery.data.checkedEvents} evento(s)` : "Integridade requer revisão"}</Badge>
                  </div>
                  <div className="mt-3 grid grid-cols-1 gap-2 sm:grid-cols-[minmax(0,1fr)_180px]">
                    <Input value={auditSearch} onChange={(event) => setAuditSearch(event.target.value)} placeholder="Pesquisar por ação, estado ou plano…" className="border-slate-700 bg-slate-900 text-slate-100 placeholder:text-slate-500" aria-label="Pesquisar no histórico de auditoria" />
                    <Select value={auditDateOrder} onValueChange={(value: InternalExecutionAuditDateOrder) => setAuditDateOrder(value)}>
                      <SelectTrigger className="border-slate-700 bg-slate-900 text-slate-100" aria-label="Ordenar histórico por data"><SelectValue /></SelectTrigger>
                      <SelectContent className="border-slate-700 bg-slate-900 text-slate-100">
                        <SelectItem value="newest">Mais recentes primeiro</SelectItem>
                        <SelectItem value="oldest">Mais antigos primeiro</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  {internalExecutionTimelineQuery.data.events.length === 0 ? (
                    <p className="mt-2 text-xs text-slate-400">Ainda não existem planos internos executados ou cancelados.</p>
                  ) : visibleInternalExecutionEvents.length === 0 ? (
                    <p className="mt-2 text-xs text-slate-400">Nenhum evento corresponde à pesquisa atual.</p>
                  ) : (
                    <ul className="mt-2 space-y-2 text-xs text-slate-300">
                      {visibleInternalExecutionEvents.map((event) => <li key={event.id} className="flex flex-wrap items-center justify-between gap-2 rounded-lg border border-slate-800 bg-slate-900/60 p-2"><div className="flex min-w-0 flex-wrap items-center gap-2"><Badge className={getInternalExecutionEventTagClass(event.eventType)}>{getInternalExecutionEventLabel(event.eventType)}</Badge><span className="text-slate-400">Plano #{event.planId}</span></div><span className="text-slate-500">{new Date(event.createdAt).toLocaleString("pt-PT")}</span></li>)}
                    </ul>
                  )}
                </div>
              )}
              {pendingAgentDraft && (
                <div className="mx-3 mb-3 rounded-xl border border-blue-700 bg-blue-950/40 p-3 sm:mx-4 sm:mb-4" role="status">
                  <p className="flex items-center gap-2 font-medium text-blue-100"><ClipboardCheck className="h-4 w-4" /> Especificação do agente — revisão e confirmação obrigatórias</p>
                  <p className="mt-1 text-xs text-blue-200">{pendingAgentDraft.stage === "collecting" ? "A KIA está apenas a recolher requisitos reais. Ainda não existe agente." : "Todos os requisitos foram recolhidos. Reveja antes de criar o rascunho."}</p>
                  <div className="mt-3 grid grid-cols-1 gap-2 sm:grid-cols-2">
                    {AGENT_SPEC_FIELDS.map((field) => <div key={field.key} className="rounded-lg border border-blue-900 bg-slate-950/70 p-2.5">
                      <p className="text-xs font-medium text-blue-200">{field.label}</p>
                      {isEditingAgentDraft || pendingAgentDraft.stage === "collecting" ? (
                        <Textarea value={pendingAgentDraft.values[field.key]} onChange={(event) => setPendingAgentDraft((current) => current ? { ...current, values: { ...current.values, [field.key]: event.target.value } } : current)} placeholder={field.question} className="mt-1 min-h-20 border-blue-800 bg-slate-950 text-slate-100" aria-label={field.label} />
                      ) : <p className="mt-1 whitespace-pre-wrap text-sm text-slate-100">{pendingAgentDraft.values[field.key]}</p>}
                    </div>)}
                  </div>
                  {pendingAgentDraft.stage === "ready" && (
                    <div className="mt-3 rounded-lg border border-blue-800 bg-slate-950/70 p-3">
                      <p className="text-sm font-medium text-blue-100">Autonomia e permissões internas</p>
                      <p className="mt-1 text-xs text-blue-200">O nível define a orientação do agente, não autoriza execução real. EXECUTE, SEND e PUBLISH permanecem bloqueadas.</p>
                      <div className="mt-3 grid grid-cols-1 gap-3 sm:grid-cols-2">
                        <label className="text-xs text-slate-200">Nível de autonomia
                          <Select value={agentAutonomyLevel} onValueChange={(value) => setAgentAutonomyLevel(value as AgentAutonomyLevel)}>
                            <SelectTrigger className="mt-1 border-blue-800 bg-slate-950 text-slate-100"><SelectValue /></SelectTrigger>
                            <SelectContent className="border-blue-800 bg-slate-900 text-slate-100">
                              {AGENT_AUTONOMY_LEVELS.map((level) => <SelectItem key={level} value={level}>{level}</SelectItem>)}
                            </SelectContent>
                          </Select>
                        </label>
                        <div className="space-y-2 text-xs text-slate-200">
                          <p>Permissões internas permitidas</p>
                          <div className="grid grid-cols-2 gap-2">
                            {AGENT_PERMISSION_CAPABILITIES.map((permission) => <label key={permission} className="flex items-center gap-2 rounded border border-slate-700 bg-slate-900 px-2 py-1.5">
                              <input type="checkbox" checked={agentPermissions.includes(permission)} onChange={(event) => setAgentPermissions((current) => event.target.checked ? [...current, permission] : current.filter((item) => item !== permission))} className="h-4 w-4 accent-blue-500" />
                              {permission}
                            </label>)}
                          </div>
                        </div>
                      </div>
                    </div>
                  )}
                  <p className="mt-3 text-xs text-blue-200">O agente será criado apenas como <strong>RASCUNHO</strong>. Não terá ativação, execução autónoma, cliente, integração externa ou ação real nesta etapa.</p>
                  <div className="mt-3 flex flex-wrap gap-2">
                    {pendingAgentDraft.stage === "ready" && <Button size="sm" disabled={!isKiaAgentDraftComplete(pendingAgentDraft) || agentPermissions.length === 0 || createAgentMutation.isPending} onClick={() => createAgentMutation.mutate({ specification: pendingAgentDraft.values, autonomyLevel: agentAutonomyLevel, permissions: agentPermissions })} className="bg-blue-600 text-white hover:bg-blue-500"><CircleCheckBig className="mr-2 h-4 w-4" /> Confirmar criação como rascunho</Button>}
                    {pendingAgentDraft.stage === "ready" && <Button size="sm" variant="outline" onClick={() => setIsEditingAgentDraft((current) => !current)} className="border-blue-700 text-blue-100 hover:bg-blue-950"><Pencil className="mr-2 h-4 w-4" /> {isEditingAgentDraft ? "Concluir edição" : "Editar especificação"}</Button>}
                    <Button size="sm" variant="outline" onClick={() => { setPendingAgentDraft(null); setIsEditingAgentDraft(false); toast.info("Rascunho cancelado. Nenhum agente foi criado."); }} className="border-blue-700 text-blue-100 hover:bg-blue-950">Cancelar</Button>
                  </div>
                </div>
              )}
            </Card>

            <Card className="bg-slate-900 border-slate-800">
              <CardHeader className="p-0">
                <button
                  type="button"
                  onClick={() => setIsVoiceSettingsOpen((current) => getNextVoiceSettingsOpen(current, "toggle"))}
                  aria-expanded={isVoiceSettingsOpen}
                  aria-controls="kia-voice-settings"
                  className="flex w-full items-center justify-between gap-3 p-4 text-left sm:p-5"
                >
                  <span className="min-w-0">
                    <CardTitle className="flex items-center gap-2 text-base text-slate-100"><Volume2 className="w-5 h-5 shrink-0 text-blue-400" /> Configuração de voz</CardTitle>
                    <CardDescription className="mt-1 text-xs text-slate-300 sm:text-sm">Voz, idioma e reprodução. A escuta só começa quando toca em “Falar”.</CardDescription>
                  </span>
                  <ChevronDown className={`h-5 w-5 shrink-0 text-blue-300 ${isVoiceSettingsOpen ? "rotate-180" : ""}`} aria-hidden="true" />
                </button>
              </CardHeader>
              {isVoiceSettingsOpen && <CardContent id="kia-voice-settings" className="grid grid-cols-1 gap-4 border-t border-slate-800 p-4 sm:grid-cols-2 sm:p-5 xl:grid-cols-3">
                <label className="flex items-center gap-3 text-sm text-slate-200">
                  <input type="checkbox" checked={voice.preferences.voiceReplies} onChange={(event) => voice.updatePreferences({ voiceReplies: event.target.checked })} className="h-4 w-4 accent-blue-500" />
                  Ativar resposta por voz
                </label>
                <label className="flex items-center gap-3 text-sm text-slate-200">
                  <input type="checkbox" checked={voice.preferences.autoPlay} onChange={(event) => voice.updatePreferences({ autoPlay: event.target.checked })} className="h-4 w-4 accent-blue-500" />
                  Reprodução automática
                </label>
                <label className="flex items-center gap-3 text-sm text-slate-200">
                  <input type="checkbox" checked={voice.preferences.conversationMode} onChange={(event) => voice.updatePreferences({ conversationMode: event.target.checked })} className="h-4 w-4 accent-blue-500" />
                  Modo conversação
                </label>
                <div className="space-y-2">
                  <label className="text-sm text-slate-200">Modo de resposta</label>
                  <Select value={replyMode} onValueChange={(mode: KiaReplyMode) => setReplyMode(mode)}>
                    <SelectTrigger className="bg-slate-950 border-slate-600 text-slate-100"><SelectValue /></SelectTrigger>
                    <SelectContent className="bg-slate-900 border-slate-700 text-slate-100">
                      <SelectItem value="text">Apenas texto</SelectItem>
                      <SelectItem value="voice">Apenas voz</SelectItem>
                      <SelectItem value="both">Texto e voz</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <label className="text-sm text-slate-200">Voz da Kia</label>
                  <Select value={selectedVoiceOptionId} onValueChange={(optionId) => {
                    const selectedOption = voiceOptions.find((option) => option.id === optionId);
                    if (selectedOption) voice.updatePreferences({ voiceURI: selectedOption.voiceURI });
                  }}>
                    <SelectTrigger className="bg-slate-950 border-slate-600 text-slate-100"><SelectValue placeholder="Escolher voz do dispositivo" /></SelectTrigger>
                    <SelectContent className="bg-slate-900 border-slate-700 text-slate-100">
                      {voiceOptions.length > 0 ? voiceOptions.map((item) => <SelectItem key={item.id} value={item.id}>{item.label}</SelectItem>) : <SelectItem value="unavailable" disabled>Sem vozes carregadas</SelectItem>}
                    </SelectContent>
                  </Select>
                  <Button type="button" variant="outline" onClick={() => voice.speak(`Esta é a amostra de voz da Kia em ${voice.preferences.language}.`, true)} className="border-slate-600 bg-slate-950 text-slate-100 hover:bg-slate-800">
                    <Play className="w-4 h-4 mr-2" /> Ouvir amostra
                  </Button>
                </div>
                <div className="space-y-2">
                  <label className="text-sm text-slate-200">Idioma</label>
                  <Select value={languageMode === "auto" ? "auto" : voice.preferences.language} onValueChange={(language) => {
                    if (language === "auto") {
                      setLanguageMode("auto");
                    } else {
                      setLanguageMode("manual");
                      voice.updatePreferences({ language });
                    }
                  }}>
                    <SelectTrigger className="bg-slate-950 border-slate-600 text-slate-100"><SelectValue /></SelectTrigger>
                    <SelectContent className="bg-slate-900 border-slate-700 text-slate-100">
                      <SelectItem value="auto">Automático pela conversa</SelectItem>
                      <SelectItem value="pt-PT">Português (Portugal)</SelectItem>
                      <SelectItem value="pt-BR">Português (Brasil)</SelectItem>
                      <SelectItem value="en-US">English (United States)</SelectItem>
                      <SelectItem value="fr-FR">Français (France)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-3">
                  <label className="block text-sm text-slate-200">Velocidade: {voice.preferences.rate.toFixed(1)}x</label>
                  <input type="range" min="0.7" max="1.3" step="0.1" value={voice.preferences.rate} onChange={(event) => voice.updatePreferences({ rate: Number(event.target.value) })} className="w-full accent-blue-500" />
                  <label className="block text-sm text-slate-200">Volume: {Math.round(voice.preferences.volume * 100)}%</label>
                  <input type="range" min="0" max="1" step="0.1" value={voice.preferences.volume} onChange={(event) => voice.updatePreferences({ volume: Number(event.target.value) })} className="w-full accent-blue-500" />
                </div>
                <div className="flex items-end sm:col-span-2 xl:col-span-3">
                  <Button type="button" onClick={() => { setIsVoiceSettingsOpen((current) => getNextVoiceSettingsOpen(current, "apply")); toast.success("Configuração de voz aplicada."); }} className="min-h-11 w-full bg-blue-600 text-white hover:bg-blue-500 sm:w-auto">
                    Aplicar e recolher
                  </Button>
                </div>
              </CardContent>}
            </Card>
          </TabsContent>

          {/* TASKS & BACKLOG TAB */}
          <TabsContent value="tasks" className="space-y-6">
            <Card className="bg-slate-900 border-slate-800">
              <CardHeader>
                <CardTitle>{editingTaskId ? "Rever e atualizar tarefa do backlog" : "Adicionar Tarefa ao Backlog Operacional"}</CardTitle>
                <CardDescription>{editingTaskId ? "Revise os dados e confirme a atualização. Nenhuma transição ocorre sem a sua escolha." : "Organize tarefas por trimestre, prioridade e prazo opcional."}</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div>
                    <label className="text-xs text-slate-400 mb-1 block">Marca</label>
                    <Select value={tBrandId} onValueChange={setTBrandId}>
                      <SelectTrigger className="bg-slate-800 border-slate-700"><SelectValue /></SelectTrigger>
                      <SelectContent className="bg-slate-800 border-slate-700 text-slate-100">
                        {brands.map(b => <SelectItem key={b.id} value={String(b.id)}>{b.name}</SelectItem>)}
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <label className="text-xs text-slate-400 mb-1 block">Título da Tarefa</label>
                    <Input placeholder="Ex: Lançar campanha de Meta Ads" value={tTitle} onChange={e => setTTitle(e.target.value)} className="bg-slate-800 border-slate-700" />
                  </div>
                  <div>
                    <label className="text-xs text-slate-400 mb-1 block">Trimestre</label>
                    <Input placeholder="Ex: Q1 2026" value={tQuarter} onChange={e => setTQuarter(e.target.value)} className="bg-slate-800 border-slate-700" />
                  </div>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div>
                    <label className="text-xs text-slate-400 mb-1 block">Status</label>
                    <Select value={tStatus} onValueChange={(v: any) => setTStatus(v)}>
                      <SelectTrigger className="bg-slate-800 border-slate-700"><SelectValue /></SelectTrigger>
                      <SelectContent className="bg-slate-800 border-slate-700 text-slate-100">
                        <SelectItem value="Pendente">Pendente</SelectItem>
                        <SelectItem value="Em Curso">Em Curso</SelectItem>
                        <SelectItem value="Concluído">Concluído</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <label className="text-xs text-slate-400 mb-1 block">Prioridade</label>
                    <Select value={tPriority} onValueChange={(v: any) => setTPriority(v)}>
                      <SelectTrigger className="bg-slate-800 border-slate-700"><SelectValue /></SelectTrigger>
                      <SelectContent className="bg-slate-800 border-slate-700 text-slate-100">
                        <SelectItem value="Baixa">Baixa</SelectItem>
                        <SelectItem value="Média">Média</SelectItem>
                        <SelectItem value="Alta">Alta</SelectItem>
                        <SelectItem value="Urgente">Urgente</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <label className="text-xs text-slate-400 mb-1 block">Prazo (opcional)</label>
                    <Input type="date" value={tDueDate} onChange={e => setTDueDate(e.target.value)} className="bg-slate-800 border-slate-700" />
                  </div>
                </div>
                <div>
                  <label className="text-xs text-slate-400 mb-1 block">Descrição</label>
                  <Textarea placeholder="Detalhes operacionais..." value={tDesc} onChange={e => setTDesc(e.target.value)} className="min-h-20 bg-slate-800 border-slate-700" />
                </div>
                <div className="flex flex-wrap gap-2">
                  <Button onClick={() => addTaskMutation.mutate({ id: editingTaskId ?? undefined, brandId: Number(tBrandId), title: tTitle, description: tDesc, status: tStatus, priority: tPriority, quarter: tQuarter, dueDate: tDueDate || null })} disabled={!tTitle.trim() || addTaskMutation.isPending} className="bg-blue-600 hover:bg-blue-700">
                    {editingTaskId ? <CircleCheckBig className="w-4 h-4 mr-2" /> : <Plus className="w-4 h-4 mr-2" />} {editingTaskId ? "Confirmar atualização" : "Adicionar ao Backlog"}
                  </Button>
                  {editingTaskId && <Button variant="outline" onClick={() => { setEditingTaskId(null); setTTitle(""); setTDesc(""); setTStatus("Pendente"); setTPriority("Média"); setTQuarter(getCurrentQuarter()); setTDueDate(""); }} className="border-slate-700 text-slate-200 hover:bg-slate-800">Cancelar edição</Button>}
                </div>
              </CardContent>
            </Card>

            <Card className="bg-slate-900 border-slate-800">
              <CardHeader>
                <CardTitle>Backlog Geral de Tarefas</CardTitle>
                <CardDescription>Monitorize o progresso das operações em todas as marcas.</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
                  <Select value={taskStatusFilter} onValueChange={(value) => setTaskStatusFilter(value as TaskStatus | "Todas")}>
                    <SelectTrigger className="border-slate-700 bg-slate-800"><SelectValue placeholder="Filtrar por estado" /></SelectTrigger>
                    <SelectContent className="border-slate-700 bg-slate-800 text-slate-100"><SelectItem value="Todas">Todos os estados</SelectItem><SelectItem value="Pendente">Pendente</SelectItem><SelectItem value="Em Curso">Em Curso</SelectItem><SelectItem value="Concluído">Concluído</SelectItem></SelectContent>
                  </Select>
                  <Select value={taskPriorityFilter} onValueChange={(value) => setTaskPriorityFilter(value as TaskPriority | "Todas")}>
                    <SelectTrigger className="border-slate-700 bg-slate-800"><SelectValue placeholder="Filtrar por prioridade" /></SelectTrigger>
                    <SelectContent className="border-slate-700 bg-slate-800 text-slate-100"><SelectItem value="Todas">Todas as prioridades</SelectItem><SelectItem value="Urgente">Urgente</SelectItem><SelectItem value="Alta">Alta</SelectItem><SelectItem value="Média">Média</SelectItem><SelectItem value="Baixa">Baixa</SelectItem></SelectContent>
                  </Select>
                </div>
                <Table>
                  <TableHeader>
                    <TableRow className="border-slate-800">
                      <TableHead>Tarefa</TableHead>
                      <TableHead>Trimestre</TableHead>
                      <TableHead>Prazo</TableHead>
                      <TableHead>Prioridade</TableHead>
                      <TableHead>Estado</TableHead>
                      <TableHead className="text-right">Ações</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {visibleTasks.map(t => (
                      <TableRow key={t.id} className="border-slate-800">
                        <TableCell className="font-medium">{t.title}</TableCell>
                        <TableCell><Badge variant="outline" className="border-slate-700">{t.quarter}</Badge></TableCell>
                        <TableCell className="text-xs text-slate-300">{t.dueDate || "Sem prazo"}</TableCell>
                        <TableCell><Badge className={t.priority === 'Urgente' ? 'bg-red-900 text-red-300' : 'bg-slate-800 text-slate-300'}>{t.priority}</Badge></TableCell>
                        <TableCell><Select value={t.status} onValueChange={(status) => addTaskMutation.mutate({ id: t.id, brandId: t.brandId, title: t.title, description: t.description ?? "", status: status as TaskStatus, priority: t.priority, quarter: t.quarter, dueDate: t.dueDate })}><SelectTrigger className="h-8 w-32 border-slate-700 bg-slate-800 text-xs"><SelectValue /></SelectTrigger><SelectContent className="border-slate-700 bg-slate-800 text-slate-100"><SelectItem value="Pendente">Pendente</SelectItem><SelectItem value="Em Curso">Em Curso</SelectItem><SelectItem value="Concluído">Concluído</SelectItem></SelectContent></Select></TableCell>
                        <TableCell className="text-right">
                          {taskDeleteCandidateId === t.id ? <div className="flex flex-wrap justify-end gap-1"><Button size="sm" onClick={() => deleteTaskMutation.mutate({ id: t.id })} className="bg-red-700 text-white hover:bg-red-600">Confirmar</Button><Button size="sm" variant="outline" onClick={() => setTaskDeleteCandidateId(null)} className="border-slate-700 text-slate-200">Cancelar</Button></div> : <div className="flex justify-end gap-1"><Button size="sm" variant="ghost" onClick={() => { setEditingTaskId(t.id); setTBrandId(String(t.brandId)); setTTitle(t.title); setTDesc(t.description ?? ""); setTStatus(t.status); setTPriority(t.priority); setTQuarter(t.quarter); setTDueDate(t.dueDate ?? ""); }} className="text-blue-300 hover:text-blue-200"><Pencil className="w-4 h-4" /></Button><Button size="sm" variant="ghost" onClick={() => setTaskDeleteCandidateId(t.id)} className="text-red-400 hover:text-red-300"><Trash2 className="w-4 h-4" /></Button></div>}
                        </TableCell>
                      </TableRow>
                    ))}
                    {tasks.length === 0 && (
                      <TableRow><TableCell colSpan={6} className="text-center text-slate-500 py-6">Nenhuma tarefa corresponde aos filtros atuais.</TableCell></TableRow>
                    )}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>

          {/* CALENDAR TAB */}
          <TabsContent value="calendar" className="space-y-6">
            <Card className="bg-slate-900 border-slate-800">
              <CardHeader>
                <CardTitle>Calendário & Produção de Conteúdo</CardTitle>
                <CardDescription>Agende campanhas e publicações recorrentes para as redes sociais.</CardDescription>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow className="border-slate-800">
                      <TableHead>Data</TableHead>
                      <TableHead>Título</TableHead>
                      <TableHead>Tipo</TableHead>
                      <TableHead>Estado</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {calendar.map(c => (
                      <TableRow key={c.id} className="border-slate-800">
                        <TableCell className="font-medium">{c.scheduledDate}</TableCell>
                        <TableCell>{c.title}</TableCell>
                        <TableCell><Badge variant="outline" className="border-slate-700">{c.eventType}</Badge></TableCell>
                        <TableCell><Badge className="bg-blue-900 text-blue-300">{c.status}</Badge></TableCell>
                      </TableRow>
                    ))}
                    {calendar.length === 0 && (
                      <TableRow><TableCell colSpan={4} className="text-center text-slate-500 py-6">Nenhum evento agendado no calendário.</TableCell></TableRow>
                    )}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>

          {/* LEADS TAB */}
          <TabsContent value="leads" className="space-y-6">
            <Card className="border-amber-800/70 bg-slate-900">
              <CardHeader>
                <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
                  <div>
                    <CardTitle className="flex items-center gap-2"><ClipboardCheck className="h-5 w-5 text-amber-300" /> Revisão de workflows e templates</CardTitle>
                    <CardDescription className="mt-1">Selecione apenas os artefactos analisados. Qualquer decisão exige confirmação detalhada, é guardada no histórico e não autoriza ações externas.</CardDescription>
                  </div>
                  <Badge className="w-fit bg-amber-950 text-amber-200 hover:bg-amber-950">{pendingCorpusReviewSummary.total} pendentes</Badge>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
                  <div className="rounded-lg border border-slate-700 bg-slate-950/50 p-3"><p className="text-xs text-slate-400">Workflows</p><p className="mt-1 text-xl font-semibold text-slate-100">{pendingCorpusReviewSummary.workflows}</p></div>
                  <div className="rounded-lg border border-slate-700 bg-slate-950/50 p-3"><p className="text-xs text-slate-400">Templates</p><p className="mt-1 text-xl font-semibold text-slate-100">{pendingCorpusReviewSummary.templates}</p></div>
                  <div className="rounded-lg border border-slate-700 bg-slate-950/50 p-3"><p className="text-xs text-slate-400">Fontes preservadas</p><p className="mt-1 text-xl font-semibold text-slate-100">{pendingCorpusReviewSummary.sourceCount}</p></div>
                </div>
                <div className="flex flex-col gap-3 rounded-lg border border-slate-700 bg-slate-950/40 p-3 sm:flex-row sm:items-center sm:justify-between">
                  <div className="flex items-center gap-3">
                    <Checkbox
                      id="select-all-corpus-artifacts"
                      checked={allPendingCorpusArtifactsSelected}
                      onCheckedChange={(checked) => toggleAllPendingCorpusArtifacts(checked === true)}
                      aria-label="Selecionar todos os artefactos pendentes"
                      disabled={pendingCorpusReviewArtifacts.length === 0}
                    />
                    <label htmlFor="select-all-corpus-artifacts" className="text-sm text-slate-200">Selecionar todos os pendentes</label>
                    <Badge variant="outline" className="border-slate-600 text-slate-300">{selectedCorpusReviewArtifacts.length} selecionado(s)</Badge>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    <Button type="button" size="sm" className="bg-emerald-700 hover:bg-emerald-600" disabled={selectedCorpusReviewArtifacts.length === 0} onClick={() => requestCorpusDecision("APPROVED")}>Aprovar seleção</Button>
                    <Button type="button" size="sm" variant="destructive" disabled={selectedCorpusReviewArtifacts.length === 0} onClick={() => requestCorpusDecision("REJECTED")}>Rejeitar seleção</Button>
                  </div>
                </div>
                <div className="space-y-3">
                  {PENDING_CORPUS_REVIEW_ARTIFACTS.map((artifact) => {
                    const effectiveDecision = corpusReviewDecisionsByArtifact[artifact.id];
                    const isPending = !effectiveDecision;
                    return <div key={artifact.id} className="rounded-lg border border-slate-700 bg-slate-950/50 p-4">
                      <div className="flex flex-col gap-2 sm:flex-row sm:items-start sm:justify-between">
                        <div className="flex min-w-0 gap-3">
                          <Checkbox
                            id={`corpus-review-${artifact.id}`}
                            checked={selectedCorpusArtifactIds.includes(artifact.id)}
                            onCheckedChange={(checked) => toggleCorpusArtifactSelection(artifact.id, checked === true)}
                            disabled={!isPending}
                            aria-label={`Selecionar ${artifact.sourceGroup}`}
                          />
                          <div className="min-w-0">
                            <p className="font-medium text-slate-100">{artifact.sourceGroup}</p>
                            <p className="mt-1 text-sm leading-5 text-slate-300">{artifact.reviewFocus}</p>
                          </div>
                        </div>
                        <div className="flex shrink-0 flex-wrap gap-2">
                          <Badge variant="outline" className="border-blue-800 text-blue-200">{artifact.kind === "WORKFLOW" ? "Workflow" : "Template"}</Badge>
                          <Badge className={isPending ? "bg-amber-950 text-amber-200 hover:bg-amber-950" : effectiveDecision.decision === "APPROVED" ? "bg-emerald-950 text-emerald-200 hover:bg-emerald-950" : "bg-rose-950 text-rose-200 hover:bg-rose-950"}>{isPending ? "REVIEW_REQUIRED" : effectiveDecision.decision === "APPROVED" ? "APROVADO" : "REJEITADO"}</Badge>
                        </div>
                      </div>
                      <p className="mt-3 text-xs text-slate-400">Proveniência: grupo de triagem com {artifact.sourceCount} fonte{artifact.sourceCount === 1 ? "" : "s"}. {isPending ? "Sem criação de agentes e sem ações externas." : `Decisão humana registada: ${effectiveDecision.decision === "APPROVED" ? "aprovação interna" : "rejeição"}.`}</p>
                    </div>;
                  })}
                </div>
                <div className="rounded-lg border border-amber-900/80 bg-amber-950/25 p-3 text-sm text-amber-100">
                  <p className="font-medium">Decisão necessária do proprietário</p>
                  <p className="mt-1 text-xs leading-5 text-amber-200/90">A aprovação confirma somente o uso interno do workflow ou template selecionado. Não cria agentes, não altera a KIA/Kaz, não torna conteúdo incerto em conhecimento institucional e não desbloqueia ações externas.</p>
                </div>
              </CardContent>
            </Card>
            <Card className="bg-slate-900 border-slate-800">
              <CardHeader>
                <CardTitle>Gestão de Leads & Templates WhatsApp</CardTitle>
                <CardDescription>Acompanhe potenciais clientes e utilize templates prontos para follow-up.</CardDescription>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow className="border-slate-800">
                      <TableHead>Nome</TableHead>
                      <TableHead>Contacto</TableHead>
                      <TableHead>Serviço</TableHead>
                      <TableHead>Origem</TableHead>
                      <TableHead>Status</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {leads.map(l => (
                      <TableRow key={l.id} className="border-slate-800">
                        <TableCell className="font-medium">{l.name}</TableCell>
                        <TableCell>{l.contact}</TableCell>
                        <TableCell>{l.service || "Geral"}</TableCell>
                        <TableCell><Badge variant="outline" className="border-slate-700">{l.source}</Badge></TableCell>
                        <TableCell><Badge className="bg-emerald-900 text-emerald-300">{l.status}</Badge></TableCell>
                      </TableRow>
                    ))}
                    {leads.length === 0 && (
                      <TableRow><TableCell colSpan={5} className="text-center text-slate-500 py-6">Nenhum lead registado.</TableCell></TableRow>
                    )}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>

          <Dialog open={corpusDecisionCandidate !== null} onOpenChange={(open) => { if (!open && !decideCorpusReviewArtifactsMutation.isPending) setCorpusDecisionCandidate(null); }}>
            <DialogContent className="max-h-[85vh] overflow-y-auto border-slate-700 bg-slate-950 text-slate-100 sm:max-w-2xl">
              <DialogHeader>
                <DialogTitle>{corpusDecisionCandidate === "APPROVED" ? "Confirmar aprovação interna" : "Confirmar rejeição"}</DialogTitle>
                <DialogDescription className="text-slate-400">Leia o resumo abaixo antes da decisão final. Esta ação será registada no histórico do proprietário.</DialogDescription>
              </DialogHeader>
              <div className="space-y-3">
                <div className={`rounded-lg border p-3 text-sm ${corpusDecisionCandidate === "APPROVED" ? "border-emerald-900 bg-emerald-950/30 text-emerald-100" : "border-rose-900 bg-rose-950/30 text-rose-100"}`}>
                  <p className="font-medium">Impacto da decisão</p>
                  <p className="mt-1 text-xs leading-5">{corpusDecisionCandidate === "APPROVED" ? "Os itens passam a estar aprovados para a biblioteca operacional interna. A KIA, Kaz, permissões e allow-list do Kernel não são alterados." : "Os itens deixam de estar pendentes e ficam rejeitados no histórico. As fontes originais e a proveniência permanecem preservadas."}</p>
                </div>
                <div className="rounded-lg border border-slate-700 bg-slate-900 p-3">
                  <p className="text-sm font-medium">Artefactos selecionados ({selectedCorpusReviewArtifacts.length})</p>
                  <ul className="mt-2 space-y-2 text-xs text-slate-300">
                    {selectedCorpusReviewArtifacts.map((artifact) => <li key={artifact.id} className="rounded border border-slate-800 bg-slate-950/70 p-2"><span className="font-medium text-slate-100">{artifact.sourceGroup}</span> · {artifact.kind === "WORKFLOW" ? "Workflow" : "Template"} · {artifact.sourceCount} fonte(s)<br /><span className="text-slate-400">{artifact.reviewFocus}</span></li>)}
                  </ul>
                </div>
                <div>
                  <label htmlFor="corpus-decision-note" className="text-sm font-medium text-slate-200">Nota de decisão (opcional)</label>
                  <Textarea id="corpus-decision-note" value={corpusDecisionNote} onChange={(event) => setCorpusDecisionNote(event.target.value)} maxLength={4000} placeholder="Indique o motivo ou a condição da decisão, se necessário." className="mt-2 min-h-24 border-slate-700 bg-slate-900 text-slate-100" />
                </div>
              </div>
              <DialogFooter>
                <Button type="button" variant="outline" onClick={() => setCorpusDecisionCandidate(null)} disabled={decideCorpusReviewArtifactsMutation.isPending}>Cancelar</Button>
                <Button type="button" variant={corpusDecisionCandidate === "APPROVED" ? "default" : "destructive"} className={corpusDecisionCandidate === "APPROVED" ? "bg-emerald-700 hover:bg-emerald-600" : ""} onClick={confirmCorpusDecision} disabled={decideCorpusReviewArtifactsMutation.isPending}>
                  {decideCorpusReviewArtifactsMutation.isPending ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
                  {corpusDecisionCandidate === "APPROVED" ? "Confirmar aprovação" : "Confirmar rejeição"}
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>

          {/* AGENT FACTORY TAB */}
          <TabsContent value="agents" className="space-y-6">
            <Card className="bg-slate-900 border-slate-800">
              <CardHeader>
                <CardTitle>Painel de aprovação da Agent Factory</CardTitle>
                  <CardDescription>Valide os critérios abaixo antes de permitir que a KIA prepare um rascunho. O ciclo obrigatório é Rascunho → Em Teste → aprovação humana → Ativo.</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className={`rounded-xl border p-3 sm:p-4 ${kiaApprovalQuery.data?.unlocked ? "border-emerald-700 bg-emerald-950/40" : "border-amber-700 bg-amber-950/40"}`}>
                  <p className="flex items-center gap-2 font-medium text-slate-100"><ShieldCheck className="h-5 w-5 text-blue-300" /> {kiaApprovalQuery.data?.unlocked ? "Aptidão registada para preparar rascunhos" : "Agent Factory bloqueada até validação explícita"}</p>
                  <p className="mt-1 text-xs text-slate-300">{kiaApprovalQuery.data?.unlocked ? "A KIA pode preparar rascunhos independentes; cada agente mantém confirmação, teste e aprovação próprios. Nenhum é ativado automaticamente." : "Marque apenas os critérios que já validou no uso real da KIA."}</p>
                </div>
                <div className="grid grid-cols-1 gap-3 lg:grid-cols-2">
                  {KIA_APPROVAL_CRITERIA.map((criterion) => <label key={criterion.key} className="flex gap-3 rounded-xl border border-slate-700 bg-slate-950/60 p-3 text-sm text-slate-200">
                    <input type="checkbox" checked={approvalDraft[criterion.key]} onChange={(event) => setApprovalDraft((current) => ({ ...current, [criterion.key]: event.target.checked }))} className="mt-0.5 h-4 w-4 shrink-0 accent-blue-500" />
                    <span><span className="flex items-center gap-2 font-medium text-slate-100">{approvalDraft[criterion.key] && <CheckCircle2 className="h-4 w-4 text-emerald-400" />}{criterion.title}</span><span className="mt-1 block text-xs text-slate-400">{criterion.description}</span></span>
                  </label>)}
                </div>
                <div className="flex flex-wrap items-center gap-3">
                  <Button onClick={() => updateKiaApprovalMutation.mutate(approvalDraft)} disabled={!isKiaApprovalEligible(approvalDraft) || updateKiaApprovalMutation.isPending} className="bg-blue-600 text-white hover:bg-blue-500">
                    {updateKiaApprovalMutation.isPending ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <ShieldCheck className="mr-2 h-4 w-4" />} Confirmar critérios e desbloquear rascunhos
                  </Button>
                  {!isKiaApprovalEligible(approvalDraft) && <span className="text-xs text-amber-200">Todos os quatro critérios são necessários para confirmar a aptidão.</span>}
                </div>
              </CardContent>
            </Card>

            <Card className="bg-slate-900 border-slate-800">
              <CardHeader>
                <CardTitle>Agentes Especializados Registados</CardTitle>
                <CardDescription>Controlo de ativação e aprovação pelo proprietário.</CardDescription>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow className="border-slate-800">
                      <TableHead>Nome</TableHead>
                      <TableHead>Objetivo</TableHead>
                      <TableHead>Estado</TableHead>
                      <TableHead>Autonomia</TableHead>
                      <TableHead>Permissões</TableHead>
                      <TableHead className="text-right">Teste / Aprovação</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {agents.map(ag => (
                      <TableRow key={ag.id} className="border-slate-800">
                        <TableCell className="font-medium">{ag.name}</TableCell>
                        <TableCell>{ag.objective}</TableCell>
                        <TableCell><Badge className={ag.status === 'Ativo' ? 'bg-emerald-900 text-emerald-300' : ag.status === 'Em Teste' ? 'bg-blue-900 text-blue-200' : ag.status === 'Rejeitado' ? 'bg-red-950 text-red-200' : 'bg-slate-800 text-slate-300'}>{ag.status}</Badge></TableCell>
                        <TableCell><Badge variant="outline" className="border-blue-800 text-blue-200">{ag.autonomyLevel}</Badge><p className="mt-1 text-[11px] text-slate-400">Externo: bloqueado</p></TableCell>
                        <TableCell className="max-w-40 break-words text-xs text-slate-300">{ag.permissionSet.replace(/[\[\]"]/g, "") || "READ"}</TableCell>
                        <TableCell className="text-right">
                          <div className="flex flex-wrap justify-end gap-2">
                            {ag.status === "Rascunho" && <Button size="sm" onClick={() => { setSelectedTestAgentId(ag.id); updateAgentStatusMutation.mutate({ id: ag.id, status: "Em Teste", testNotes: "Sessão de teste controlado iniciada pelo proprietário." }); }} disabled={updateAgentStatusMutation.isPending} className="bg-blue-600 text-white hover:bg-blue-500"><Play className="mr-1 h-3.5 w-3.5" /> Iniciar teste</Button>}
                            {ag.status === "Em Teste" && activationCandidateId !== ag.id && <>
                              <Button size="sm" variant="outline" onClick={() => updateAgentStatusMutation.mutate({ id: ag.id, status: "Rejeitado", testNotes: "Rejeitado explicitamente pelo proprietário após o teste." })} disabled={updateAgentStatusMutation.isPending} className="border-red-700 text-red-200 hover:bg-red-950">Rejeitar</Button>
                              <Button size="sm" onClick={() => setActivationCandidateId(ag.id)} className="bg-emerald-600 text-white hover:bg-emerald-500">Aprovar e ativar</Button>
                            </>}
                            {ag.status === "Em Teste" && activationCandidateId === ag.id && <>
                              <Button size="sm" onClick={() => updateAgentStatusMutation.mutate({ id: ag.id, status: "Ativo", testNotes: "Ativação confirmada explicitamente pelo proprietário após teste isolado." })} disabled={updateAgentStatusMutation.isPending} className="bg-emerald-600 text-white hover:bg-emerald-500"><ShieldCheck className="mr-1 h-3.5 w-3.5" /> Confirmar ativação</Button>
                              <Button size="sm" variant="outline" onClick={() => setActivationCandidateId(null)} className="border-slate-600 text-slate-200 hover:bg-slate-800">Cancelar</Button>
                            </>}
                            {ag.status === "Ativo" && <Badge variant="outline" className="border-emerald-700 text-emerald-200">Ativado apenas após confirmação</Badge>}
                            {ag.status === "Rejeitado" && <Badge variant="outline" className="border-red-800 text-red-200">Sem ativação</Badge>}
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                    {agents.length === 0 && (
                      <TableRow><TableCell colSpan={6} className="text-center text-slate-500 py-6">Nenhum agente gerado ainda.</TableCell></TableRow>
                    )}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>

            {testableAgents.length > 0 && selectedTestAgent && <Card className="bg-slate-900 border-slate-800">
              <CardHeader>
                <CardTitle>Área isolada de teste</CardTitle>
                <CardDescription>As respostas desta área não executam ferramentas, não criam tarefas, não alteram dados e não utilizam integrações externas. Cada agente mantém o seu próprio histórico de teste.</CardDescription>
              </CardHeader>
              <CardContent className="space-y-3">
                {testableAgents.length > 1 && <Select value={String(selectedTestAgent.id)} onValueChange={(value) => { setSelectedTestAgentId(Number(value)); setAgentTestInput(""); }}>
                  <SelectTrigger className="border-slate-600 bg-slate-950 text-slate-100"><SelectValue placeholder="Selecione o agente em teste" /></SelectTrigger>
                  <SelectContent>
                    {testableAgents.map((agent) => <SelectItem key={agent.id} value={String(agent.id)}>{agent.name} — Em Teste</SelectItem>)}
                  </SelectContent>
                </Select>}
                <div className="max-h-64 space-y-2 overflow-y-auto rounded-lg border border-slate-800 bg-slate-950/60 p-3">
                  {selectedAgentTestHistory.length === 0 && <p className="text-sm text-slate-400">Envie uma pergunta realista para verificar os limites e a utilidade de {selectedTestAgent.name}.</p>}
                  {selectedAgentTestHistory.map((entry, index: number) => <div key={`${selectedTestAgent.id}-${entry.role}-${index}`} className={`rounded-lg p-2.5 text-sm ${entry.role === "owner" ? "ml-6 bg-blue-950 text-blue-100" : "mr-6 bg-slate-800 text-slate-100"}`}><span className="mb-1 block text-xs font-medium text-slate-400">{entry.role === "owner" ? "Proprietário" : selectedTestAgent.name}</span>{entry.content}</div>)}
                </div>
                <div className="flex flex-col gap-2 sm:flex-row">
                  <Input value={agentTestInput} onChange={(event) => setAgentTestInput(event.target.value)} onKeyDown={(event) => event.key === "Enter" && handleAgentTest(selectedTestAgent.id)} placeholder={`Escreva um teste controlado para ${selectedTestAgent.name}...`} className="min-h-11 border-slate-600 bg-slate-950 text-slate-100" />
                  <Button variant="outline" onClick={() => voice.startListening((transcript) => handleAgentTest(selectedTestAgent.id, transcript))} disabled={!voice.isRecognitionSupported || testAgentMutation.isPending} className="border-blue-700 bg-blue-950/40 text-blue-100 hover:bg-blue-900"><Mic className="mr-2 h-4 w-4" /> Falar</Button>
                  <Button onClick={() => handleAgentTest(selectedTestAgent.id)} disabled={!agentTestInput.trim() || testAgentMutation.isPending} className="bg-blue-600 text-white hover:bg-blue-500">{testAgentMutation.isPending ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Send className="mr-2 h-4 w-4" />} Testar</Button>
                </div>
              </CardContent>
            </Card>}
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
}
