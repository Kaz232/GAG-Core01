import { readFile } from "node:fs/promises";
import { createHash } from "node:crypto";
import { and, eq } from "drizzle-orm";
import { getDb } from "../server/db.ts";
import { storagePut } from "../server/storage.ts";
import { analyzeStoredDocument, extractDocumentText } from "../server/documentIntelligence.ts";
import { documentAnalyses, documentRecords } from "../drizzle/schema.ts";

const ownerId = 1;
const brandId = 1;
const filename = "Manual_de_Identidade_Visual_-_GAG_Visual.md";
const sourcePath = "/home/ubuntu/upload/Manual_de_Identidade_Visual_-_GAG_Visual.md";
const buffer = await readFile(sourcePath);
const contentHash = createHash("sha256").update(buffer).digest("hex");
const db = await getDb();
if (!db) throw new Error("Base de dados indisponível para a carga institucional.");

const existing = await db.select({ id: documentRecords.id }).from(documentRecords)
  .where(and(eq(documentRecords.ownerId, ownerId), eq(documentRecords.contentHash, contentHash))).limit(1);
if (existing.length) {
  console.log(JSON.stringify({ status: "already_loaded", documentId: existing[0].id }));
  process.exit(0);
}

const stored = await storagePut(`gag-core/${ownerId}/institutional-documents/${filename}`, buffer, "text/markdown");
const extractedText = await extractDocumentText({ buffer, documentType: "TEXT" });
const intent = "Extrair regras institucionais de identidade visual da GAG para revisão interna; preservar divergências e não oficializar decisões.";
const analysis = await analyzeStoredDocument({ filename, mimeType: "text/markdown", storageKey: stored.key, documentType: "TEXT", extractedText, intent, operation: "ANALYZE" });
const [documentInsert] = await db.insert(documentRecords).values({
  ownerId, brandId, filename, documentType: "TEXT", mimeType: "text/markdown", storageKey: stored.key, storageUrl: stored.url,
  contentHash, sourceOrigin: "GAG_INTERNAL", extractionStatus: "REVIEW_REQUIRED", extractedContent: extractedText,
  reviewReason: "Manual institucional real carregado para revisão. As divergências entre manuais de identidade permanecem REVIEW_REQUIRED.",
});
const documentId = Number(documentInsert.insertId);
const [analysisInsert] = await db.insert(documentAnalyses).values({
  ownerId, documentId, operation: "ANALYZE", requestedIntent: intent, analysisStatus: "REVIEW_REQUIRED", analysisJson: JSON.stringify(analysis),
  summary: analysis.documentSummary, professionalReviewRequired: analysis.professionalReviewRequired ? 1 : 0,
  reviewDecision: "PENDING", reviewNote: "Aguardando revisão humana; conflitos de identidade não podem ser oficializados automaticamente.",
});
console.log(JSON.stringify({ status: "loaded_for_review", documentId, analysisId: Number(analysisInsert.insertId), contentHash }));
