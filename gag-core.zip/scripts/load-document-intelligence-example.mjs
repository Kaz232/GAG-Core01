import { readFile } from "node:fs/promises";
import { createHash } from "node:crypto";
import { and, eq } from "drizzle-orm";
import { getDb } from "../server/db.ts";
import { storagePut } from "../server/storage.ts";
import { analyzeStoredDocument, extractDocumentText } from "../server/documentIntelligence.ts";
import { documentAnalyses, documentRecords } from "../drizzle/schema.ts";

const ownerId = 1;
const brandId = 1;
const filename = "document-intelligence-internal-example-2026-08-19.md";
const sourcePath = new URL("../knowledge-artifacts/workflow-tests/document-intelligence-internal-example-2026-08-19.md", import.meta.url);
const buffer = await readFile(sourcePath);
const contentHash = createHash("sha256").update(buffer).digest("hex");
const db = await getDb();

if (!db) throw new Error("Base de dados indisponível para o teste documental interno.");

const existing = await db
  .select({ id: documentRecords.id })
  .from(documentRecords)
  .where(and(eq(documentRecords.ownerId, ownerId), eq(documentRecords.contentHash, contentHash)))
  .limit(1);

if (existing.length) {
  console.log(JSON.stringify({ status: "already_loaded", documentId: existing[0].id }));
  process.exit(0);
}

const stored = await storagePut(`gag-core/${ownerId}/document-tests/${filename}`, buffer, "text/markdown");
const extractedText = await extractDocumentText({ buffer, documentType: "TEXT" });
const analysis = await analyzeStoredDocument({
  filename,
  mimeType: "text/markdown",
  storageKey: stored.key,
  documentType: "TEXT",
  extractedText,
  intent: "Teste interno controlado de extração e revisão humana; não oficial e sem ação externa.",
  operation: "ANALYZE",
});

const inserted = await db.insert(documentRecords).values({
  ownerId,
  brandId,
  filename,
  documentType: "TEXT",
  mimeType: "text/markdown",
  storageKey: stored.key,
  storageUrl: stored.url,
  contentHash,
  sourceOrigin: "GAG_INTERNAL",
  extractionStatus: "REVIEW_REQUIRED",
  extractedContent: extractedText,
  reviewReason: "Documento de teste não oficial. Requer revisão humana antes de qualquer uso interno.",
});
const documentId = Number(inserted[0].insertId);

const analysisInsert = await db.insert(documentAnalyses).values({
  ownerId,
  documentId,
  operation: "ANALYZE",
  requestedIntent: "Teste interno controlado de extração e revisão humana; não oficial e sem ação externa.",
  analysisStatus: "REVIEW_REQUIRED",
  analysisJson: JSON.stringify(analysis),
  summary: analysis.documentSummary,
  professionalReviewRequired: analysis.professionalReviewRequired ? 1 : 0,
  reviewDecision: "PENDING",
  reviewNote: "Aguardando decisão humana obrigatória; teste não oficial.",
});

console.log(JSON.stringify({ status: "loaded_for_review", documentId, analysisId: Number(analysisInsert[0].insertId), contentHash }));
