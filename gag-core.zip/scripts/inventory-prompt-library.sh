#!/usr/bin/env bash
set -euo pipefail

project_root="/home/ubuntu/gag-core"
upload_root="/home/ubuntu/upload"
input_file="$project_root/PROMPT_LIBRARY_INPUTS_2026-08-19.txt"
output_file="$project_root/PROMPT_LIBRARY_INVENTORY_2026-08-19.tsv"

classify() {
  local lower
  lower="$(printf '%s' "$1" | tr '[:upper:]' '[:lower:]')"
  if [[ "$lower" == *"lista_de_prompts"* || "$lower" == *"prompts_uteis"* || "$lower" == *"150prompts"* || "$lower" == *"prompt_bible"* || "$lower" == *"promptsdeelite"* || "$lower" == *"promptssmart"* ]]; then
    printf '%s' 'REFERENCE;SKILL_CANDIDATE'
  elif [[ "$lower" == *"modelo"* || "$lower" == *"promptoriginal"* || "$lower" == *"mestreprompt"* ]]; then
    printf '%s' 'TEMPLATE;REFERENCE'
  elif [[ "$lower" == *"plano"* || "$lower" == *"curso"* || "$lower" == *"manual"* || "$lower" == *"instrucoes_projeto"* ]]; then
    printf '%s' 'WORKFLOW;KNOWLEDGE'
  elif [[ "$lower" == *"appscript"* || "$lower" == *"crm"* || "$lower" == *"replit"* || "$lower" == *"notebooklm"* || "$lower" == *"gemini"* || "$lower" == *"chat-gpt"* || "$lower" == *"chatgpt"* || "$lower" == *"canva"* ]]; then
    printf '%s' 'TOOL_SPECIFICATION;REFERENCE'
  elif [[ "$lower" == *"roteiro"* || "$lower" == *"video"* || "$lower" == *"infogr"* ]]; then
    printf '%s' 'SKILL_CANDIDATE;TEMPLATE'
  elif [[ "$lower" == *"avaliacao"* || "$lower" == *"checklist"* || "$lower" == *"desafios"* || "$lower" == *"exercicios"* || "$lower" == *"faq"* || "$lower" == *"recursos"* || "$lower" == *"sugestoes"* ]]; then
    printf '%s' 'REFERENCE;TEMPLATE'
  else
    printf '%s' 'REFERENCE'
  fi
}

extract_preview() {
  local file="$1"
  local ext="${file##*.}"
  local raw=""
  case "${ext,,}" in
    md|txt)
      raw="$(sed -n '1,80p' "$file" 2>/dev/null || true)"
      ;;
    pdf)
      raw="$(pdftotext -f 1 -l 3 "$file" - 2>/dev/null | head -c 2400 || true)"
      ;;
    docx)
      raw="$(unzip -p "$file" word/document.xml 2>/dev/null | sed 's/<w:p[^>]*>/\n/g; s/<[^>]*>/ /g' | head -c 2400 || true)"
      ;;
    *)
      raw="[Pré-visualização não extraída automaticamente; classificação baseada no nome e formato do ficheiro.]"
      ;;
  esac
  printf '%s' "$raw" | tr '\t\n\r' ' ' | sed 's/[[:space:]][[:space:]]*/ /g' | cut -c 1-1200
}

printf 'filename\tformat\tsha256\tpreliminary_categories\tpreview\n' > "$output_file"
while IFS= read -r filename; do
  [[ -z "$filename" ]] && continue
  file="$upload_root/$filename"
  ext="${filename##*.}"
  hash="$(sha256sum "$file" | awk '{print $1}')"
  categories="$(classify "$filename")"
  preview="$(extract_preview "$file")"
  printf '%s\t%s\t%s\t%s\t%s\n' "$filename" "$ext" "$hash" "$categories" "$preview" >> "$output_file"
done < "$input_file"

printf 'Inventário criado: %s\n' "$output_file"
