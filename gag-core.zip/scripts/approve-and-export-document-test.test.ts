import { describe, expect, it } from "vitest";
import { getDocumentExportBlockReason, isDocumentExportAllowed } from "../shared/documentApprovalExport";

describe("fluxo de aprovação humana para exportação PDF", () => {
  it("não permite exportar enquanto a análise estiver pendente de revisão", () => {
    expect(isDocumentExportAllowed("PENDING")).toBe(false);
    expect(getDocumentExportBlockReason("PENDING")).toContain("bloqueada");
  });

  it("permite exportação somente depois da aprovação explícita", () => {
    expect(isDocumentExportAllowed("APPROVED")).toBe(true);
    expect(getDocumentExportBlockReason("APPROVED")).toBeNull();
  });
});
