import { and, eq } from "drizzle-orm";
import { getDb } from "../server/db.ts";
import { storagePut } from "../server/storage.ts";
import { createInternalDocumentReportPdf } from "../server/documentReportPdf.ts";
import { buildInternalDocumentReport } from "../shared/documentApprovalExport.ts";
import { documentAnalyses, documentAnalysisExports, documentRecords } from "../drizzle/schema.ts";

const ownerId = 1;
const analysisId = 1;
const reviewedAt = new Date();
const approvalNote = "Aprovado pelo proprietário apenas para validar o fluxo de exportação PDF do documento interno de teste. Não oficializa conteúdo nem autoriza ações externas.";
const db = await getDb();
if (!db) throw new Error("Base de dados indisponível.");

const records = await db.select({ analysis: documentAnalyses, document: documentRecords })
  .from(documentAnalyses)
  .innerJoin(documentRecords, eq(documentAnalyses.documentId, documentRecords.id))
  .where(and(eq(documentAnalyses.id, analysisId), eq(documentAnalyses.ownerId, ownerId), eq(documentRecords.ownerId, ownerId)))
  .limit(1);
const record = records[0];
if (!record) throw new Error("Documento de teste autorizado não encontrado.");

await db.update(documentAnalyses).set({ reviewDecision: "APPROVED", reviewedBy: ownerId, reviewedAt, reviewNote: approvalNote })
  .where(and(eq(documentAnalyses.id, analysisId), eq(documentAnalyses.ownerId, ownerId)));
const reportContent = buildInternalDocumentReport({
  analysisId: record.analysis.id,
  filename: record.document.filename,
  contentHash: record.document.contentHash,
  requestedIntent: record.analysis.requestedIntent,
  summary: record.analysis.summary,
  analysisJson: record.analysis.analysisJson,
  approvedAt: reviewedAt,
  reviewNote: approvalNote,
});
const reportPdf = await createInternalDocumentReportPdf(reportContent);
const stored = await storagePut(`gag-core/${ownerId}/document-reports/analysis-${analysisId}.pdf`, reportPdf, "application/pdf");
const [inserted] = await db.insert(documentAnalysisExports).values({
  ownerId,
  analysisId,
  format: "PDF",
  reportContent: `${reportContent}\n\nPDF auditável: ${stored.key}`,
});
console.log(JSON.stringify({ status: "approved_and_exported", analysisId, exportId: Number(inserted.insertId), filename: `relatorio-interno-analise-${analysisId}.pdf`, storageKey: stored.key }));
